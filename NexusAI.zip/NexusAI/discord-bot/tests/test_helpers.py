import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from helpers import chunk, guild_allowed, parse_ids, redact, tts_text

class T(unittest.TestCase):
    def test_ids(self): self.assertEqual(parse_ids("1, 2 3"), {1, 2, 3}); self.assertEqual(parse_ids(""), set())
    def test_guild(self):
        self.assertTrue(guild_allowed(5, set())); self.assertTrue(guild_allowed(5, {5}))
        self.assertFalse(guild_allowed(6, {5})); self.assertFalse(guild_allowed(None, set()))
    def test_chunk(self): self.assertEqual(len(chunk("a" * 4000)), 3)
    def test_tts(self): self.assertEqual(tts_text("**hi** `x`"), "hi x")
    def test_redact(self): self.assertEqual(redact("tok=abc", "abc", ""), "tok=***")

if __name__ == "__main__": unittest.main()
