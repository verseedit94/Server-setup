"""Nexus Discord bot (discord.py 2.x). Token only from env DISCORD_BOT_TOKEN.

Implemented : /join /leave /ask /stop /status  - /ask answers via Gemini and, if the bot is in
              a voice channel, SPEAKS the answer there (gTTS -> ffmpeg).
NOT implemented: receiving/transcribing users' voice. discord.py has no official voice-receive.
              See README for the experimental options.
"""
import asyncio
import io
import logging
import os
import tempfile

import aiohttp
import discord
from discord import app_commands
from gtts import gTTS

from helpers import chunk, guild_allowed, parse_ids, redact, tts_text

TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "")
GEMINI_KEY = os.environ.get("GEMINI_API_KEY", "")
GROQ_KEY = os.environ.get("GROQ_API_KEY", "")
GROQ_MODEL = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
PROVIDER = os.environ.get("LLM_PROVIDER", "groq" if GROQ_KEY and not GEMINI_KEY else "gemini")
MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
TTS_LANG = os.environ.get("TTS_LANG", "hi")
ALLOWED = parse_ids(os.environ.get("ALLOWED_GUILD_IDS", ""))

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("nexus")
SYSTEM = "You are Nexus, a calm, friendly male voice assistant. Reply briefly in the user's language (Hindi/Hinglish/English). No markdown."

intents = discord.Intents.default()  # slash commands need no privileged intents
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)
last_error = "none"


async def ask_groq(prompt: str) -> str:
    global last_error
    if not GROQ_KEY:
        raise RuntimeError("GROQ_API_KEY set nahi hai.")
    body = {"model": GROQ_MODEL, "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}]}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as s:
        async with s.post("https://api.groq.com/openai/v1/chat/completions", json=body,
                          headers={"Authorization": f"Bearer {GROQ_KEY}"}) as r:
            if r.status != 200:
                last_error = f"Groq HTTP {r.status}"
                raise RuntimeError({401: "Invalid Groq key", 429: "Rate limit"}.get(r.status, last_error))
            data = await r.json()
    try:
        return data["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError):
        raise RuntimeError("Groq ne khali jawab diya.")


async def ask_gemini(prompt: str) -> str:
    global last_error
    if PROVIDER == "groq":
        return await ask_groq(prompt)
    if not GEMINI_KEY:
        raise RuntimeError("GEMINI_API_KEY set nahi hai.")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"
    body = {"systemInstruction": {"parts": [{"text": SYSTEM}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}]}
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as s:
        async with s.post(url, json=body, headers={"x-goog-api-key": GEMINI_KEY}) as r:
            if r.status != 200:
                last_error = f"Gemini HTTP {r.status}"
                raise RuntimeError({400: "Bad request / key", 403: "Invalid API key", 429: "Quota limit"}.get(r.status, last_error))
            data = await r.json()
    try:
        return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"]).strip()
    except (KeyError, IndexError):
        raise RuntimeError("Gemini ne khali/blocked jawab diya.")


def make_tts(text: str) -> str:
    f = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    gTTS(text=text, lang=TTS_LANG).write_to_fp(f)
    f.close()
    return f.name


async def guard(inter: discord.Interaction) -> bool:
    if not guild_allowed(inter.guild_id, ALLOWED):
        await inter.response.send_message("Ye server authorized nahi hai.", ephemeral=True)
        return False
    return True


@tree.command(name="join", description="Apne voice channel me Nexus ko bulao")
async def join(inter: discord.Interaction):
    if not await guard(inter): return
    m = inter.user
    if not isinstance(m, discord.Member) or not m.voice or not m.voice.channel:
        return await inter.response.send_message("Pehle kisi voice channel me jao.", ephemeral=True)
    await inter.response.defer()
    try:
        vc = inter.guild.voice_client
        if vc: await vc.move_to(m.voice.channel)
        else: await m.voice.channel.connect()
        await inter.followup.send(f"Joined **{m.voice.channel.name}** ✅")
    except Exception as e:
        await inter.followup.send(f"Join FAIL: {redact(str(e), TOKEN, GEMINI_KEY, GROQ_KEY)} (Connect/Speak permission check karo)")


@tree.command(name="leave", description="Voice channel chhodo")
async def leave(inter: discord.Interaction):
    if not await guard(inter): return
    vc = inter.guild.voice_client
    if not vc: return await inter.response.send_message("Main kisi voice channel me nahi hoon.", ephemeral=True)
    await vc.disconnect(force=True)
    await inter.response.send_message("Left ✅")


@tree.command(name="stop", description="Bolna band karo")
async def stop(inter: discord.Interaction):
    if not await guard(inter): return
    vc = inter.guild.voice_client
    if vc and vc.is_playing():
        vc.stop(); await inter.response.send_message("Roka ✅")
    else:
        await inter.response.send_message("Abhi kuch nahi bol raha.", ephemeral=True)


@tree.command(name="ask", description="Nexus se kuch poochho")
@app_commands.describe(prompt="Tumhara sawaal")
async def ask(inter: discord.Interaction, prompt: str):
    if not await guard(inter): return
    await inter.response.defer()
    try:
        answer = await ask_gemini(prompt)
    except Exception as e:
        return await inter.followup.send(f"⚠️ {redact(str(e), TOKEN, GEMINI_KEY, GROQ_KEY)}")
    parts = chunk(answer)
    await inter.followup.send(parts[0])
    for p in parts[1:]: await inter.channel.send(p)
    vc = inter.guild.voice_client
    if vc and vc.is_connected():
        try:
            path = await asyncio.get_running_loop().run_in_executor(None, make_tts, tts_text(answer))
            if vc.is_playing(): vc.stop()
            vc.play(discord.FFmpegPCMAudio(path), after=lambda err: (os.remove(path), err and log.error("playback: %s", err)))
        except Exception as e:
            await inter.channel.send(f"🔇 Voice playback FAIL: {redact(str(e), TOKEN, GEMINI_KEY, GROQ_KEY)} (ffmpeg/PyNaCl installed?)")


@tree.command(name="status", description="Bot ki asli haalat")
async def status(inter: discord.Interaction):
    if not await guard(inter): return
    vc = inter.guild.voice_client
    await inter.response.send_message(
        f"Latency {client.latency*1000:.0f} ms | Voice: {vc.channel.name if vc and vc.is_connected() else 'not connected'} | "
        f"AI: {PROVIDER} | key: {'set' if (GROQ_KEY if PROVIDER == 'groq' else GEMINI_KEY) else 'MISSING'} | Model: {GROQ_MODEL if PROVIDER == 'groq' else MODEL} | Last error: {last_error}")


@client.event
async def on_ready():
    await tree.sync()  # global sync can take up to ~1 hour to show; re-invite with applications.commands scope
    log.info("Logged in as %s (%s guilds)", client.user, len(client.guilds))


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_BOT_TOKEN env var set nahi hai. .env dekho (see README).")
    client.run(TOKEN, log_handler=None)
