"""Pure helpers (unit-tested, no Discord import)."""
import re

def parse_ids(value: str) -> set[int]:
    """'123, 456' -> {123, 456}. Empty -> empty set (meaning: no restriction)."""
    return {int(x) for x in re.split(r"[,\s]+", value or "") if x.strip().isdigit()}

def guild_allowed(guild_id: int | None, allowed: set[int]) -> bool:
    return guild_id is not None and (not allowed or guild_id in allowed)

def chunk(text: str, n: int = 1900) -> list[str]:
    """Discord messages max 2000 chars."""
    text = text or "(empty)"
    return [text[i:i + n] for i in range(0, len(text), n)]

def tts_text(text: str, limit: int = 600) -> str:
    """Strip markdown-ish chars and trim for speech."""
    t = re.sub(r"[*_`#>]", "", text)
    return t[:limit]

def redact(text: str, *secrets: str) -> str:
    for s in secrets:
        if s:
            text = text.replace(s, "***")
    return text
