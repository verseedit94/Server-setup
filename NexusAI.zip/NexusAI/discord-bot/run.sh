#!/usr/bin/env bash
# Loads .env (never commit it) and starts the bot.
cd "$(dirname "$0")"
set -a; [ -f .env ] && . ./.env; set +a
[ -d .venv ] && . .venv/bin/activate
exec python bot.py
