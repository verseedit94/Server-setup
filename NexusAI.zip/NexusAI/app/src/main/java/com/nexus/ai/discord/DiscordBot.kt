package com.nexus.ai.discord

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Minimal Discord bot: REST + Gateway WebSocket, slash commands /ask /status /ping.
 * TEXT ONLY - Discord voice needs native Opus/ffmpeg, so voice stays in the Python bot (discord-bot/).
 */
class DiscordBot(
    private val token: String,
    private val allowedGuilds: Set<String>,
    private val ask: suspend (String) -> String,
    private val onStatus: (String) -> Unit,
    private val onInvite: (String) -> Unit,
    private val onFatal: () -> Unit
) {
    private val restClient = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
    private val wsClient = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var ws: WebSocket? = null
    private var hb: Job? = null
    private var seq: Int? = null
    private var appId = ""
    private var attempts = 0
    @Volatile private var stopped = false

    fun start() { scope.launch { boot() } }

    fun stop() {
        stopped = true
        hb?.cancel()
        ws?.close(1000, "bye")
        scope.cancel()
    }

    private suspend fun boot() {
        try {
            onStatus("Token check ho raha hai…")
            val me = JSONObject(rest("GET", "/users/@me", null))
            appId = me.getString("id")
            rest("PUT", "/applications/$appId/commands", commands())
            onInvite("https://discord.com/oauth2/authorize?client_id=$appId&scope=bot%20applications.commands&permissions=2048")
            connect()
        } catch (e: Exception) {
            onStatus("FAIL: ${e.message}")
            onFatal()
        }
    }

    private fun commands(): JSONArray = JSONArray()
        .put(JSONObject().put("name", "ask").put("type", 1).put("description", "Nexus se kuch poochho")
            .put("options", JSONArray().put(JSONObject().put("type", 3).put("name", "prompt").put("description", "Tumhara sawaal").put("required", true))))
        .put(JSONObject().put("name", "status").put("type", 1).put("description", "Bot ki haalat"))
        .put(JSONObject().put("name", "ping").put("type", 1).put("description", "Ping"))

    private fun rest(method: String, path: String, body: Any?, auth: Boolean = true): String {
        val rb = body?.toString()?.toRequestBody("application/json".toMediaType())
            ?: if (method == "GET") null else "".toRequestBody(null)
        val req = Request.Builder().url("https://discord.com/api/v10$path").method(method, rb)
            .header("User-Agent", "DiscordBot (nexus-android, 1.0)")
            .apply { if (auth) header("Authorization", "Bot $token") }
            .build()
        restClient.newCall(req).execute().use { r ->
            val t = r.body?.string() ?: ""
            if (!r.isSuccessful) throw IOException(when (r.code) {
                401 -> "Token galat hai (401)."
                403 -> "Permission nahi (403)."
                429 -> "Discord rate limit (429)."
                else -> "Discord HTTP ${r.code}: ${t.take(120)}"
            })
            return t
        }
    }

    private fun connect() {
        if (stopped) return
        onStatus("Gateway se jud raha hai…")
        ws = wsClient.newWebSocket(Request.Builder().url("wss://gateway.discord.gg/?v=10&encoding=json").build(), object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try { handle(webSocket, JSONObject(text)) } catch (e: Exception) { onStatus("Parse error: ${e.message}") }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (code in listOf(4004, 4010, 4011, 4012, 4013, 4014)) {
                    stopped = true; onStatus("Discord ne reject kiya (code $code). Token check karo."); onFatal()
                } else reconnect("Gateway band ($code)")
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                reconnect("Network: ${t.message}")
            }
        })
    }

    private fun reconnect(why: String) {
        hb?.cancel()
        if (stopped) return
        attempts++
        onStatus("$why - dobara try (#$attempts)")
        scope.launch { delay(minOf(30_000L, 3_000L * attempts)); connect() }
    }

    private fun hbPayload(): String = JSONObject().put("op", 1).put("d", seq ?: JSONObject.NULL).toString()

    private fun handle(w: WebSocket, m: JSONObject) {
        if (!m.isNull("s")) seq = m.getInt("s")
        when (m.getInt("op")) {
            10 -> {
                val iv = m.getJSONObject("d").getLong("heartbeat_interval")
                hb?.cancel()
                hb = scope.launch { delay((iv * Math.random()).toLong()); while (isActive) { w.send(hbPayload()); delay(iv) } }
                w.send(JSONObject().put("op", 2).put("d", JSONObject()
                    .put("token", token).put("intents", 0)
                    .put("properties", JSONObject().put("os", "android").put("browser", "nexus").put("device", "nexus"))).toString())
            }
            1 -> w.send(hbPayload())
            7, 9 -> w.close(4000, "reconnect")
            0 -> when (m.getString("t")) {
                "READY" -> {
                    attempts = 0
                    val u = m.getJSONObject("d").optJSONObject("user")?.optString("username", "") ?: ""
                    onStatus("Online ✅ $u")
                }
                "INTERACTION_CREATE" -> { val d = m.getJSONObject("d"); scope.launch { interaction(d) } }
            }
        }
    }

    private fun noMentions() = JSONObject().put("parse", JSONArray())

    private fun callback(id: String, itok: String, type: Int, content: String?, ephemeral: Boolean = false) {
        val data = JSONObject().put("allowed_mentions", noMentions())
        if (content != null) data.put("content", content)
        if (ephemeral) data.put("flags", 64)
        rest("POST", "/interactions/$id/$itok/callback", JSONObject().put("type", type).put("data", data), false)
    }

    private suspend fun interaction(d: JSONObject) {
        if (d.optInt("type") != 2) return
        val id = d.getString("id"); val itok = d.getString("token")
        val guild = d.optString("guild_id", "")
        val data = d.getJSONObject("data")
        try {
            if (allowedGuilds.isNotEmpty() && guild !in allowedGuilds) {
                callback(id, itok, 4, "Ye server authorized nahi hai.", true); return
            }
            when (data.getString("name")) {
                "ping" -> callback(id, itok, 4, "Pong 🏓")
                "status" -> callback(id, itok, 4, "Nexus online ✅ (Android app se chal raha hai, text-only)")
                "ask" -> {
                    val prompt = data.getJSONArray("options").getJSONObject(0).getString("value")
                    callback(id, itok, 5, null)
                    val ans = try { ask(prompt).ifBlank { "(khali jawab)" } } catch (e: Exception) { "⚠️ ${e.message}" }
                    val parts = ans.chunked(1900)
                    rest("PATCH", "/webhooks/$appId/$itok/messages/@original",
                        JSONObject().put("content", parts[0]).put("allowed_mentions", noMentions()), false)
                    for (p in parts.drop(1)) rest("POST", "/webhooks/$appId/$itok",
                        JSONObject().put("content", p).put("allowed_mentions", noMentions()), false)
                }
            }
        } catch (e: Exception) {
            onStatus("Reply FAIL: ${e.message}")
        }
    }
}
