package com.nexus.ai.ai

import java.util.Locale

/** Exact arithmetic tool (no LLM guessing): + - * / % ^ ( ) sqrt() pi, unary minus. */
object Calc {
    fun eval(src: String): Double {
        val s = src.replace(" ", "").replace("×", "*").replace("÷", "/").lowercase()
        val p = Parser(s)
        val v = p.expr()
        if (p.pos != s.length) throw IllegalArgumentException("Expression samajh nahi aaya: '$src'")
        return v
    }

    fun format(d: Double): String =
        if (d % 1.0 == 0.0 && Math.abs(d) < 1e15) d.toLong().toString()
        else String.format(Locale.US, "%.6f", d).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var pos = 0
        private fun peek(): Char? = if (pos < s.length) s[pos] else null
        private fun expect(c: Char) { if (peek() != c) throw IllegalArgumentException("'$c' missing"); pos++ }

        fun expr(): Double {
            var v = term()
            while (true) {
                val c = peek()
                if (c == '+') { pos++; v += term() }
                else if (c == '-') { pos++; v -= term() }
                else return v
            }
        }
        private fun term(): Double {
            var v = factor()
            while (true) {
                val c = peek()
                if (c == '*') { pos++; v *= factor() }
                else if (c == '/' || c == '%') {
                    pos++
                    val r = factor()
                    if (r == 0.0) throw ArithmeticException("Zero se divide nahi hota")
                    v = if (c == '/') v / r else v % r
                } else return v
            }
        }
        private fun factor(): Double {
            val b = unary()
            if (peek() == '^') { pos++; return Math.pow(b, factor()) }
            return b
        }
        private fun unary(): Double {
            val c = peek()
            if (c == '-') { pos++; return -unary() }
            if (c == '+') { pos++; return unary() }
            return primary()
        }
        private fun primary(): Double {
            if (peek() == '(') { pos++; val v = expr(); expect(')'); return v }
            if (s.startsWith("sqrt", pos)) {
                pos += 4; expect('('); val v = expr(); expect(')')
                if (v < 0) throw ArithmeticException("Negative number ka sqrt nahi hota")
                return Math.sqrt(v)
            }
            if (s.startsWith("pi", pos)) { pos += 2; return Math.PI }
            val st = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (st == pos) throw IllegalArgumentException("Number chahiye")
            return s.substring(st, pos).toDouble()
        }
    }
}
