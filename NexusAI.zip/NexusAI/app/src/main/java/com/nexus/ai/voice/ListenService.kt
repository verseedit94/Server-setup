package com.nexus.ai.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import com.nexus.ai.NexusViewModel

/**
 * Foreground service (type microphone) that keeps the process alive while hands-free mode is ON,
 * so "Hey Nexus" keeps working after you leave the app. Must be started while the app is visible.
 * The listening loop itself lives in NexusViewModel (process-wide singleton).
 */
class ListenService : Service() {
    companion object {
        const val ACTION_STOP = "com.nexus.ai.STOP_LISTEN"
        private const val CH = "nexus_listen"
    }
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            NexusViewModel.get(application).switchHandsFree(false)
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Nexus hands-free", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Nexus sun raha hai 🎙")
            .setContentText("'Hey Nexus' bolo. Band: 'Stop Nexus' ya Stop button")
            .setSmallIcon(android.R.drawable.stat_notify_voicemail)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Stop", stopPi).build())
            .build()
        ServiceCompat.startForeground(this, 2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        if (wl == null) {
            wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nexus:listen")
            wl?.acquire()
        }
        // Resume hands-free after reboot / process restart (no-op when started from the UI switch).
        val vm = NexusViewModel.get(application)
        if (!vm.handsFree && vm.store.autoHandsFree) vm.switchHandsFree(true)
        return START_STICKY
    }

    override fun onDestroy() {
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
