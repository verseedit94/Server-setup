package com.nexus.ai.device

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.provider.AlarmClock
import com.nexus.ai.ai.Calc
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Official-API-only device control. Every call returns the REAL result string
 * (success or the reason it failed). Nothing here bypasses Android permission prompts.
 * Dial opens the dialer only (user must press call). No SMS sending, no payments.
 */
class DeviceAgent(private val ctx: Context) {

    fun execute(name: String, arg: String): String = try {
        when (name) {
            "open_app" -> openApp(arg)
            "volume_up" -> vol(AudioManager.ADJUST_RAISE, "badhayi")
            "volume_down" -> vol(AudioManager.ADJUST_LOWER, "kam ki")
            "battery" -> battery()
            "network" -> network()
            "time" -> "Abhi: " + SimpleDateFormat("EEE dd MMM, hh:mm a", Locale.getDefault()).format(Date())
            "timer" -> timer(arg)
            "alarm" -> alarm(arg)
            "dial" -> launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + arg.filter { it.isDigit() || it == '+' })), "Dialer khula (call aap press karoge)")
            "web" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse(if (arg.startsWith("http")) arg else "https://www.google.com/search?q=" + Uri.encode(arg))), "Browser khula")
            "settings" -> launch(Intent(Settings.ACTION_SETTINGS), "Settings khuli")
            "calc" -> try { "= " + Calc.format(Calc.eval(arg)) } catch (e: Exception) { "Calc FAIL: ${e.message}" }
            "torch_on" -> torch(true)
            "torch_off" -> torch(false)
            "wifi" -> launch(Intent(Settings.ACTION_WIFI_SETTINGS), "WiFi settings khuli")
            "bluetooth" -> launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth settings khuli")
            "maps" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(arg))), "Maps khula")
            "youtube" -> launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(arg))), "YouTube search khula")
            "sms_draft" -> smsDraft(arg)
            else -> "Unknown action: $name"
        }
    } catch (e: Exception) { "$name FAIL: ${e.message}" }

    private fun torch(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return "Is phone me flash nahi mila"
        cm.setTorchMode(id, on)
        return "Torch " + (if (on) "on" else "off")
    }

    /** Opens the SMS composer with text prefilled; the user must press send. */
    private fun smsDraft(arg: String): String {
        val parts = arg.split("|", limit = 2)
        val num = parts[0].filter { it.isDigit() || it == '+' }
        val body = parts.getOrElse(1) { "" }
        return launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", body), "SMS draft khula (send aap khud dabaoge)")
    }

    private fun launch(i: Intent, ok: String): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i); return ok
    }

    private fun openApp(label: String): String {
        val pm = ctx.packageManager
        val q = label.trim().lowercase()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "App '$label' nahi mila."
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "App launch intent nahi mila."
        return launch(i, "${hit.loadLabel(pm)} khul gaya")
    }

    private fun vol(dir: Int, word: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return "Volume $word (ab ${am.getStreamVolume(AudioManager.STREAM_MUSIC)}/${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)})"
    }

    private fun battery(): String {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return "Battery ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%" + if (bm.isCharging) " (charging)" else ""
    }

    private fun network(): String {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Offline"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Online (WiFi)"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Online (Mobile data)"
            else -> "Online"
        }
    }

    private fun timer(arg: String): String {
        val s = arg.filter { it.isDigit() }.toIntOrNull() ?: return "Timer seconds samajh nahi aaye: '$arg'"
        return launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, false), "Timer ${s}s ka set screen khula")
    }

    /** arg = "HH:MM" 24h */
    private fun alarm(arg: String): String {
        val p = arg.split(":")
        val h = p.getOrNull(0)?.trim()?.toIntOrNull(); val m = p.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
        if (h == null || h !in 0..23 || m !in 0..59) return "Alarm time galat: '$arg' (HH:MM chahiye)"
        return launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "Nexus"), "Alarm %02d:%02d ke liye clock app khula".format(h, m))
    }
}
