package com.nexus.ai.data

/**
 * Built-in fallback key, used only when the user leaves the Groq key field empty in Settings.
 * WARNING: anything inside an APK can be extracted by whoever gets the APK. Share the APK only with people you trust,
 * keep the GitHub repo PRIVATE, and rotate this key at console.groq.com if it ever leaks.
 */
object DefaultKeys {
    const val GROQ = "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"
}
