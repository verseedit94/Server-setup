package com.nexus.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/** Official Gemini REST API, streaming via Server-Sent Events (streamGenerateContent?alt=sse). */
class GeminiClient(private val apiKey: () -> String, private val model: () -> String) {

    fun stream(history: List<Pair<String, String>>, system: String): Flow<String> = flow {
        val key = apiKey()
        if (key.isBlank()) throw IOException("Gemini API key set nahi hai. Settings me daalo.")
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            put("contents", JSONArray().also { arr ->
                history.forEach { (role, text) ->
                    arr.put(JSONObject().put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text))))
                }
            })
        }
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${model()}:streamGenerateContent?alt=sse")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key) // header, so the key never appears in URLs/logs
            c.doOutput = true
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                throw IOException(when (code) {
                    400 -> "Request/API key galat hai (400)."
                    401, 403 -> "API key invalid ya permission nahi (HTTP $code)."
                    404 -> "Model '${model()}' nahi mila (404). Settings me model check karo."
                    429 -> "Quota/rate limit khatam (429). Thodi der baad try karo."
                    else -> "Gemini server error (HTTP $code)."
                })
            }
            val reader = c.inputStream.bufferedReader()
            while (true) {
                val line = reader.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val json = line.removePrefix("data:").trim()
                if (json.isEmpty() || json == "[DONE]") continue
                val parts = JSONObject(json).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (i in 0 until parts.length()) {
                    val t = parts.optJSONObject(i)?.optString("text", "") ?: ""
                    if (t.isNotEmpty()) emit(t)
                }
            }
        } catch (e: UnknownHostException) {
            throw IOException("Internet nahi hai (offline).")
        } catch (e: SocketTimeoutException) {
            throw IOException("Network timeout. Dobara try karo.")
        } finally {
            c.disconnect()
        }
    }.flowOn(Dispatchers.IO)
}
