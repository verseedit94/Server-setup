package com.nexus.ai.discord

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.ServiceCompat
import com.nexus.ai.ai.Brain
import com.nexus.ai.data.SecureStore

/** Observable state for the Settings screen. */
object BotHub {
    var status by mutableStateOf("Off")
    var running by mutableStateOf(false)
    var invite by mutableStateOf("")
    internal var bot: DiscordBot? = null
}

/** Foreground service so the bot keeps running while the app is in background. */
class BotService : Service() {
    companion object {
        const val ACTION_STOP = "com.nexus.ai.STOP_BOT"
        private const val CH = "nexus_bot"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(true); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Nexus Discord bot", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, BotService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, CH)
            .setContentTitle("Nexus Discord bot")
            .setContentText("Chal raha hai (text commands)")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(0, "Stop", stopPi).build())
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        val store = SecureStore(this)
        val token = store.discordToken
        if (token.isBlank()) { BotHub.status = "Token khali hai"; shutdown(false); return START_NOT_STICKY }
        BotHub.bot?.stop()
        val brain = Brain(store)
        val guilds = store.discordGuilds.split(",", " ").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        BotHub.running = true
        BotHub.invite = ""
        BotHub.bot = DiscordBot(token, guilds, { brain.answer(it) }, { BotHub.status = it }, { BotHub.invite = it }, { shutdown(false) })
            .also { it.start() }
        return START_NOT_STICKY
    }

    private fun shutdown(resetStatus: Boolean) {
        BotHub.bot?.stop(); BotHub.bot = null
        BotHub.running = false
        if (resetStatus) BotHub.status = "Off"
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { BotHub.bot?.stop(); BotHub.bot = null; BotHub.running = false; super.onDestroy() }
}
