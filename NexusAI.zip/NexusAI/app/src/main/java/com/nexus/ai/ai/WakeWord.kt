package com.nexus.ai.ai

/** Pure-Kotlin wake / stop phrase matching ("Hey Nexus" / "Stop Nexus"). Tolerant of common speech-to-text mishearings. */
object WakeWord {
    private const val NEX = "(?:nexus|nexas|nexis|nexes|nexxus|next us|nekshas|नेक्सस|नेक्सेस|नेक्सस|नेक्स)"
    private val wake = Regex("""(?<![A-Za-z])(?:hey|hay|hei|hi|he|ae|हे|हेय|है)[\s,.!-]*$NEX""", RegexOption.IGNORE_CASE)
    private val stopA = Regex("""(?<![A-Za-z])(?:stop|stock|stap|stup|स्टॉप|स्टोप|स्टाप)[\s,.!-]*$NEX""", RegexOption.IGNORE_CASE)
    private val stopB = Regex("""$NEX[\s,.!-]*(?:stop|band|bandh|bund|बंद|बन्द|chup|चुप|ruk|रुक)""", RegexOption.IGNORE_CASE)

    fun isStop(text: String) = stopA.containsMatchIn(text) || stopB.containsMatchIn(text)
    fun isWake(text: String) = !isStop(text) && wake.containsMatchIn(text)

    /** Text spoken after "hey nexus" in the same breath ("hey nexus time kya hai" -> "time kya hai"). */
    fun afterWake(text: String): String {
        val m = wake.find(text) ?: return text.trim()
        return text.substring(m.range.last + 1).trim(' ', ',', '.', '!')
    }
}
