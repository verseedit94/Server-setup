package com.nexus.ai.ai

data class Action(val name: String, val arg: String)

/** Parses [[ACTION:name|arg]] tags that Gemini emits (see system prompt). Pure Kotlin, unit-tested. */
object ActionParser {
    private val re = Regex("""\[\[ACTION:([a-z_]+)\|?([^\]]*)\]\]""")
    fun parse(text: String): List<Action> =
        re.findAll(text).map { Action(it.groupValues[1], it.groupValues[2].trim()) }.toList()
    fun strip(text: String): String =
        text.replace(re, "").replace(Regex("""\[\[ACTION:[^\]]*$"""), "").trim()
}
