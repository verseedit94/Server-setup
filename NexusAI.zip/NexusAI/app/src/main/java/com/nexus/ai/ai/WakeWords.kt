package com.nexus.ai.ai

/** Pure-Kotlin wake / stop phrase matching on speech-recognizer text (tolerates common mishearings). */
object WakeWords {
    private val nexus = listOf("nexuss", "nexus", "nexes", "nexas", "next us", "नेक्सस", "नेक्स्स", "नेक्सेस", "नैक्सस", "नेकसस")
    private val stop = setOf("stop", "stock", "stap", "band", "bandh", "ruko", "बंद", "स्टॉप", "स्टॉक", "रुको")

    fun norm(t: String): String =
        t.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    fun hasNexus(t: String): Boolean { val n = norm(t); return nexus.any { n.contains(it) } }

    /** "stop nexus", "stock nexus", "nexus band karo"; or a very short bare "stop"/"band". */
    fun isStop(t: String): Boolean {
        val n = norm(t)
        val words = n.split(" ").filter { it.isNotEmpty() }
        val hasStop = words.any { it in stop }
        return hasStop && (hasNexus(t) || words.size <= 2)
    }

    /** Text after the wake word: "Hey Nexus YouTube kholo" -> "youtube kholo". */
    fun afterWake(t: String): String {
        val n = norm(t)
        var best = -1; var len = 0
        for (k in nexus) {
            val i = n.indexOf(k)
            if (i >= 0 && (best < 0 || i < best)) { best = i; len = k.length }
        }
        return if (best < 0) n else n.substring(best + len).trim()
    }
}
