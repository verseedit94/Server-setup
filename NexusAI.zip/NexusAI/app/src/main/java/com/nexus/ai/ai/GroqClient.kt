package com.nexus.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/** Groq (OpenAI-compatible chat completions, streaming SSE). Same stream() shape as GeminiClient. */
class GroqClient(private val apiKey: () -> String, private val model: () -> String) {

    fun stream(history: List<Pair<String, String>>, system: String): Flow<String> = flow {
        val key = apiKey()
        if (key.isBlank()) throw IOException("Groq API key set nahi hai. Settings me daalo.")
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.forEach { (role, text) ->
            msgs.put(JSONObject().put("role", if (role == "model") "assistant" else "user").put("content", text))
        }
        val body = JSONObject().put("model", model()).put("messages", msgs).put("stream", true)
        if (model().startsWith("openai/gpt-oss")) {
            val coding = Regex("(?i)code|program|script|function|bug|error|debug|class|kotlin|python|java|html|sql|likho|banao").containsMatchIn(history.lastOrNull()?.second ?: "")
            body.put("reasoning_effort", if (coding) "medium" else "low")
        }
        val c = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer $key")
            c.doOutput = true
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            if (code != 200) {
                throw IOException(when (code) {
                    400 -> "Request galat hai ya model '${model()}' sahi nahi (400)."
                    401, 403 -> "Groq API key invalid (HTTP $code)."
                    404 -> "Model '${model()}' nahi mila (404). Groq ne hata diya ho sakta hai; console.groq.com/docs/models se naya naam Settings me daalo."
                    429 -> "Groq rate limit (429). Thodi der baad try karo."
                    else -> "Groq server error (HTTP $code)."
                })
            }
            val reader = c.inputStream.bufferedReader()
            while (true) {
                val line = reader.readLine() ?: break
                if (!line.startsWith("data:")) continue
                val json = line.removePrefix("data:").trim()
                if (json.isEmpty() || json == "[DONE]") continue
                val delta = JSONObject(json).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta") ?: continue
                if (delta.isNull("content")) continue
                val t = delta.optString("content", "")
                if (t.isNotEmpty()) emit(t)
            }
        } catch (e: UnknownHostException) {
            throw IOException("Internet nahi hai (offline).")
        } catch (e: SocketTimeoutException) {
            throw IOException("Network timeout. Dobara try karo.")
        } finally {
            c.disconnect()
        }
    }.flowOn(Dispatchers.IO)
}
