package com.nexus.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.os.Handler
import android.os.Looper
import java.util.Locale

/** Android TextToSpeech + SpeechRecognizer. Voices depend on what is installed on the device. */
class VoiceEngine(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    fun init(onReady: () -> Unit = {}) {
        tts = TextToSpeech(ctx) { status -> ready = status == TextToSpeech.SUCCESS; main.post(onReady) }
    }

    /** All installed voices (user picks one in Settings; we cannot assume a male voice exists). */
    fun voices(): List<Voice> = try { tts?.voices?.sortedBy { it.name }?.toList() ?: emptyList() } catch (e: Exception) { emptyList() }

    fun speak(text: String, lang: String, voiceName: String, rate: Float, pitch: Float, finished: () -> Unit) {
        val t = tts
        if (!ready || t == null) { finished(); return }
        val loc = Locale.forLanguageTag(lang)
        t.language = loc
        voices().firstOrNull { it.name == voiceName }?.let { t.voice = it }
        t.setSpeechRate(rate); t.setPitch(pitch)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post(finished) }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post(finished) }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexus")
    }
    fun stopSpeaking() { tts?.stop() }

    fun available() = SpeechRecognizer.isRecognitionAvailable(ctx)

    /** Push-to-talk: call listen() on press; result delivered once. Needs RECORD_AUDIO granted. */
    fun listen(lang: String, onPartial: (String) -> Unit, onResult: (String) -> Unit, onFail: (String) -> Unit) {
        if (!available()) { onFail("Is phone par speech recognition service nahi hai."); return }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) onFail("Kuch sunai nahi diya.") else onResult(t)
            }
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
            }
            override fun onError(e: Int) { onFail("Mic error code $e") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        })
    }
    fun stopListening() { recognizer?.stopListening() }
    fun shutdown() { recognizer?.destroy(); tts?.stop(); tts?.shutdown() }
}
