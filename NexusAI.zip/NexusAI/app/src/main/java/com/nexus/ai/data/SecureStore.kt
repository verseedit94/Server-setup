package com.nexus.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.nexus.ai.BuildConfig

/** Settings + secrets, encrypted with an Android Keystore-backed master key. */
class SecureStore(ctx: Context) {
    companion object { const val DEFAULT_GROQ = "openai/gpt-oss-120b" }
    private val p: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "nexus_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    var apiKey: String get() = p.getString("apiKey", "") ?: ""; set(v) = p.edit().putString("apiKey", v.trim()).apply()
    var model: String get() = p.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"; set(v) = p.edit().putString("model", v.trim()).apply()
    var provider: String get() = p.getString("provider", "groq") ?: "groq"; set(v) = p.edit().putString("provider", v).apply()
    var groqKey: String get() = (p.getString("groqKey", "") ?: "").ifBlank { BuildConfig.GROQ_DEFAULT_KEY }; set(v) = p.edit().putString("groqKey", v.trim()).apply()
    var groqModel: String get() = p.getString("groqModel", DEFAULT_GROQ) ?.let { if (it == "llama-3.3-70b-versatile") DEFAULT_GROQ else it } ?: DEFAULT_GROQ; set(v) = p.edit().putString("groqModel", v.trim()).apply()
    var lang: String get() = p.getString("lang", "hi-IN") ?: "hi-IN"; set(v) = p.edit().putString("lang", v).apply()
    var voiceName: String get() = p.getString("voice", "") ?: ""; set(v) = p.edit().putString("voice", v).apply()
    var rate: Float get() = p.getFloat("rate", 1.0f); set(v) = p.edit().putFloat("rate", v).apply()
    var pitch: Float get() = p.getFloat("pitch", 0.8f); set(v) = p.edit().putFloat("pitch", v).apply() // lower pitch = deeper voice
    var autoSpeak: Boolean get() = p.getBoolean("autoSpeak", true); set(v) = p.edit().putBoolean("autoSpeak", v).apply()
    var wakeEnabled: Boolean get() = p.getBoolean("wake", true); set(v) = p.edit().putBoolean("wake", v).apply()
    var reduceMotion: Boolean get() = p.getBoolean("reduceMotion", false); set(v) = p.edit().putBoolean("reduceMotion", v).apply()
}
