package com.nexus.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.nexus.ai.AState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val Navy = Color(0xFF050A18)

/**
 * Procedural holographic avatar drawn on a Compose Canvas (NOT a glTF model - see README).
 * Pseudo-3D: head orb with radial shading, head sway, rotating orbit rings, blinking visor eyes
 * that track a drifting point, and a mouth that animates while SPEAKING.
 * reduceMotion = true renders a static frame.
 */
@Composable
fun Avatar(state: AState, reduceMotion: Boolean, modifier: Modifier = Modifier) {
    val t by rememberInfiniteTransition(label = "av").animateFloat(
        0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val speed = when (state) { AState.THINKING -> 3f; AState.LISTENING -> 1.5f; AState.EXECUTING -> 4f; else -> 1f }
    val phase = if (reduceMotion) 0f else t
    val accent = when (state) { AState.LISTENING -> Color(0xFF69F0AE); AState.THINKING -> Color(0xFFFFD740); AState.EXECUTING -> Color(0xFFFF6E40); else -> Cyan }

    Canvas(modifier) {
        val c = center
        val r = size.minDimension * 0.30f
        val ang = phase * 2 * PI.toFloat()
        // glow
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.35f), Color.Transparent), c, r * 2.2f), r * 2.2f, c)
        // orbit rings (rotating arcs, tilted by squashing vertically)
        for (i in 0..2) {
            val rr = r * (1.35f + i * 0.22f)
            val rot = ang * speed * (if (i % 2 == 0) 1 else -1) * 360f / (2 * PI.toFloat())
            val sq = 0.35f + 0.2f * i
            androidx.compose.ui.graphics.drawscope.withTransform({ rotate(rot, c); scale(1f, sq, c) }) {
                drawArc(accent.copy(alpha = 0.8f - i * 0.2f), 0f, 250f, false, Offset(c.x - rr, c.y - rr), Size(rr * 2, rr * 2), style = Stroke(3f))
            }
        }
        // head sway
        val sway = if (reduceMotion) 0f else sin(ang * speed) * r * 0.04f
        val hc = Offset(c.x + sway, c.y + (if (reduceMotion) 0f else cos(ang * 2) * r * 0.02f))
        drawCircle(Brush.radialGradient(listOf(Blue.copy(alpha = 0.9f), Color(0xFF0A1B3D), Navy), hc - Offset(r * 0.3f, r * 0.35f), r * 1.4f), r, hc)
        drawCircle(accent, r, hc, style = Stroke(2.5f))
        // visor
        val vy = hc.y - r * 0.1f
        drawRoundRect(Color.Black.copy(alpha = 0.55f), Offset(hc.x - r * 0.72f, vy - r * 0.2f), Size(r * 1.44f, r * 0.4f), androidx.compose.ui.geometry.CornerRadius(r * 0.2f))
        val blink = if (!reduceMotion && (t * 8f) % 1f > 0.94f) 0.15f else 1f
        val look = if (reduceMotion) 0f else sin(ang * 3) * r * 0.06f
        for (s in listOf(-1f, 1f)) {
            drawOval(accent, Offset(hc.x + s * r * 0.33f - r * 0.12f + look, vy - r * 0.07f * blink), Size(r * 0.24f, r * 0.14f * blink))
        }
        // mouth
        val open = if (state == AState.SPEAKING && !reduceMotion) (0.5f + 0.5f * sin(ang * 40f)) else 0f
        drawRoundRect(accent, Offset(hc.x - r * 0.25f, hc.y + r * 0.42f - open * r * 0.06f), Size(r * 0.5f, r * (0.04f + open * 0.14f)), androidx.compose.ui.geometry.CornerRadius(r * 0.05f))
        // listening ring pulse / particles
        if (!reduceMotion) for (i in 0 until 14) {
            val a = ang + i * (2 * PI.toFloat() / 14)
            val d = r * (1.9f + 0.12f * sin(ang * 2 + i))
            drawCircle(accent.copy(alpha = 0.5f), 2.5f, Offset(c.x + cos(a) * d, c.y + sin(a) * d * 0.9f))
        }
    }
}
