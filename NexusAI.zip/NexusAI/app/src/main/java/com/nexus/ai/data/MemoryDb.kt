package com.nexus.ai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

data class MemoryItem(val id: Long, val text: String, val source: String, val created: Long)

/**
 * Local SQLite store (survives restarts/updates; removed by Android on uninstall / clear-data).
 * Search is keyword (LIKE) based - no embeddings in this version.
 */
class MemoryDb(ctx: Context) : SQLiteOpenHelper(ctx, "nexus.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, source TEXT NOT NULL, created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, text TEXT NOT NULL, created INTEGER NOT NULL)")
    }
    // Future versions: add ALTER TABLE steps here, never drop tables.
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    /** Returns a human-readable save status (never claims success on failure). */
    fun addMemory(text: String, source: String = "chat"): String = try {
        val t = text.trim()
        if (t.isEmpty()) "Khali memory save nahi hui."
        else if (all().any { it.text.equals(t, ignoreCase = true) }) "Pehle se saved hai (duplicate skip)."
        else {
            val id = writableDatabase.insertOrThrow("memories", null, ContentValues().apply {
                put("text", t); put("source", source); put("created", System.currentTimeMillis())
            })
            "Memory saved ✓ (#$id)"
        }
    } catch (e: Exception) { "Memory save FAIL: ${e.message}" }

    fun all(query: String = ""): List<MemoryItem> {
        val out = mutableListOf<MemoryItem>()
        val c = if (query.isBlank()) readableDatabase.rawQuery("SELECT id,text,source,created FROM memories ORDER BY id DESC", null)
        else readableDatabase.rawQuery("SELECT id,text,source,created FROM memories WHERE text LIKE ? ORDER BY id DESC", arrayOf("%$query%"))
        c.use { while (it.moveToNext()) out.add(MemoryItem(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3))) }
        return out
    }
    fun update(id: Long, text: String) { writableDatabase.update("memories", ContentValues().apply { put("text", text.trim()) }, "id=?", arrayOf(id.toString())) }
    fun delete(id: Long) { writableDatabase.delete("memories", "id=?", arrayOf(id.toString())) }

    fun addMessage(role: String, text: String) {
        writableDatabase.insert("messages", null, ContentValues().apply { put("role", role); put("text", text); put("created", System.currentTimeMillis()) })
    }
    fun recentMessages(n: Int = 50): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        readableDatabase.rawQuery("SELECT role,text FROM messages ORDER BY id DESC LIMIT $n", null)
            .use { while (it.moveToNext()) out.add(it.getString(0) to it.getString(1)) }
        return out.reversed()
    }
    fun clearMessages() { writableDatabase.delete("messages", null, null) }

    fun exportJson(): String {
        val arr = JSONArray()
        all().forEach { arr.put(JSONObject().put("text", it.text).put("source", it.source).put("created", it.created)) }
        return JSONObject().put("version", 1).put("memories", arr).toString(2)
    }
    /** Merges (never wipes). Returns number of newly imported entries. */
    fun importJson(json: String): Int {
        val arr = JSONObject(json).getJSONArray("memories")
        var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (addMemory(o.getString("text"), o.optString("source", "import")).startsWith("Memory saved")) n++
        }
        return n
    }
}
