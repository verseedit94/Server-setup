package com.nexus.ai

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexus.ai.ai.Action
import com.nexus.ai.ai.ActionParser
import com.nexus.ai.ai.GeminiClient
import com.nexus.ai.data.MemoryDb
import com.nexus.ai.data.MemoryItem
import com.nexus.ai.data.SecureStore
import com.nexus.ai.device.DeviceAgent
import com.nexus.ai.voice.VoiceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class AState { IDLE, LISTENING, THINKING, SPEAKING, EXECUTING }
data class Msg(val role: String, val text: String) // role: "user" | "model"

class NexusViewModel(app: Application) : AndroidViewModel(app) {
    val store = SecureStore(app)
    val db = MemoryDb(app)
    val voice = VoiceEngine(app)
    private val device = DeviceAgent(app)
    private val gemini = GeminiClient({ store.apiKey }, { store.model })

    val messages = mutableStateListOf<Msg>()
    var state by mutableStateOf(AState.IDLE)
    var status by mutableStateOf("")
    var partial by mutableStateOf("")
    var memories by mutableStateOf(listOf<MemoryItem>())
    var voiceNames by mutableStateOf(listOf<String>())
    private var job: Job? = null

    init {
        db.recentMessages().forEach { messages.add(Msg(it.first, it.second)) }
        refreshMemories()
        voice.init { voiceNames = voice.voices().map { it.name } }
    }

    fun refreshMemories(q: String = "") { memories = db.all(q) }

    private fun systemPrompt(): String {
        val mem = db.all().take(30).joinToString("\n") { "- ${it.text}" }
        return """You are Nexus, a calm, confident, friendly male voice assistant (JARVIS-style). Reply in the user's language (Hindi, Hinglish or English). Be concise; replies are spoken aloud, so avoid markdown.
You can control the phone ONLY by appending tags at the very end of your reply. Tags: 
[[ACTION:open_app|App Name]] [[ACTION:volume_up]] [[ACTION:volume_down]] [[ACTION:battery]] [[ACTION:network]] [[ACTION:time]] [[ACTION:timer|seconds]] [[ACTION:alarm|HH:MM]] [[ACTION:dial|number]] [[ACTION:web|query or url]] [[ACTION:settings]] [[ACTION:remember|fact to remember]].
Use remember only when the user asks you to remember something. Never claim an action succeeded; the app reports the real result. You cannot send SMS, make payments or delete data.
Known facts about the user:
${mem.ifBlank { "(none yet)" }}"""
    }

    fun send(text: String) {
        if (text.isBlank() || job?.isActive == true) return
        voice.stopSpeaking()
        val t = text.trim()
        messages.add(Msg("user", t)); db.addMessage("user", t)
        messages.add(Msg("model", ""))
        val idx = messages.lastIndex
        state = AState.THINKING; status = ""
        job = viewModelScope.launch {
            val sb = StringBuilder()
            try {
                val hist = messages.take(idx)
                    .filter { it.text.isNotBlank() && !it.text.startsWith("⚠️") }
                    .takeLast(20).dropWhile { it.role != "user" }
                    .map { it.role to it.text }
                gemini.stream(hist, systemPrompt()).collect {
                    sb.append(it); messages[idx] = Msg("model", ActionParser.strip(sb.toString()))
                }
                val full = sb.toString()
                val clean = ActionParser.strip(full)
                messages[idx] = Msg("model", clean.ifBlank { "(khali jawab)" })
                if (clean.isNotBlank()) db.addMessage("model", clean)
                val actions = ActionParser.parse(full)
                if (actions.isNotEmpty()) {
                    state = AState.EXECUTING
                    status = actions.joinToString(" | ") { run(it) }
                }
                if (store.autoSpeak && clean.isNotBlank()) {
                    state = AState.SPEAKING
                    voice.speak(clean, store.lang, store.voiceName, store.rate, store.pitch) { state = AState.IDLE }
                } else state = AState.IDLE
            } catch (e: CancellationException) {
                messages[idx] = Msg("model", ActionParser.strip(sb.toString()).ifBlank { "(roka gaya)" })
                state = AState.IDLE; throw e
            } catch (e: Exception) {
                messages[idx] = Msg("model", "⚠️ ${e.message ?: e.javaClass.simpleName}")
                state = AState.IDLE
            }
        }
    }

    private fun run(a: Action): String = if (a.name == "remember") db.addMemory(a.arg).also { refreshMemories() } else device.execute(a.name, a.arg)

    /** Emergency stop: cancels generation, speech, mic. */
    fun stopAll() { job?.cancel(); voice.stopSpeaking(); voice.stopListening(); state = AState.IDLE; partial = "" }

    fun startListening() {
        voice.stopSpeaking(); state = AState.LISTENING; partial = ""
        voice.listen(store.lang, { partial = it }, { partial = ""; send(it) }, { status = it; partial = ""; state = AState.IDLE })
    }

    fun clearChat() { messages.clear(); db.clearMessages() }
    override fun onCleared() { voice.shutdown() }
}
