package com.nexus.ai

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.content.Intent
import androidx.core.content.ContextCompat
import com.nexus.ai.ai.Action
import com.nexus.ai.ai.ActionParser
import com.nexus.ai.ai.GeminiClient
import com.nexus.ai.ai.GroqClient
import com.nexus.ai.ai.WakeWords
import com.nexus.ai.data.MemoryDb
import com.nexus.ai.data.MemoryItem
import com.nexus.ai.data.SecureStore
import com.nexus.ai.device.DeviceAgent
import com.nexus.ai.voice.ListenService
import com.nexus.ai.voice.VoiceEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AState { IDLE, LISTENING, THINKING, SPEAKING, EXECUTING }
data class Msg(val role: String, val text: String) // role: "user" | "model"

/**
 * Process-wide singleton (not tied to the Activity) so hands-free listening keeps running
 * while the Activity is closed, as long as ListenService keeps the process alive.
 */
class NexusViewModel private constructor(private val app: Application) {
    companion object {
        @Volatile private var inst: NexusViewModel? = null
        fun get(app: Application): NexusViewModel =
            inst ?: synchronized(this) { inst ?: NexusViewModel(app).also { inst = it } }
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val store = SecureStore(app)
    val db = MemoryDb(app)
    val voice = VoiceEngine(app)
    private val device = DeviceAgent(app)
    private val gemini = GeminiClient({ store.apiKey }, { store.model })
    private val groq = GroqClient({ store.groqKey }, { store.groqModel })

    val messages = mutableStateListOf<Msg>()
    var state by mutableStateOf(AState.IDLE)
    var status by mutableStateOf("")
    var partial by mutableStateOf("")
    var memories by mutableStateOf(listOf<MemoryItem>())
    var voiceNames by mutableStateOf(listOf<String>())

    /** Hands-free: handsFree = mic loop on; awake = conversation active (after "Hey Nexus"). */
    var handsFree by mutableStateOf(false)
    var awake by mutableStateOf(false)
    var pendingHandsFree = false
    private var job: Job? = null

    init {
        db.recentMessages().forEach { messages.add(Msg(it.first, it.second)) }
        refreshMemories()
        voice.init { voiceNames = voice.voices().map { it.name } }
    }

    fun refreshMemories(q: String = "") { memories = db.all(q) }

    private fun systemPrompt(): String {
        val mem = db.all().take(30).joinToString("\n") { "- ${it.text}" }
        return """You are Nexus, a calm, confident, friendly male voice assistant (JARVIS-style). Reply in the user's language (Hindi, Hinglish or English). Keep normal answers concise because they are spoken aloud; outside code blocks avoid markdown.
For coding requests act as an expert programmer: give complete, correct, runnable code in fenced ``` blocks with the file name and a short explanation; when debugging, reason from the exact error/log given; if details are missing, state a sensible assumption and continue.
Owner rule: if anyone asks who made, owns or created you or this app, answer only that your owner and creator is verseedit.
You can control the phone ONLY by appending tags at the very end of your reply. Tags:
[[ACTION:open_app|App Name]] [[ACTION:volume_up]] [[ACTION:volume_down]] [[ACTION:battery]] [[ACTION:network]] [[ACTION:time]] [[ACTION:timer|seconds]] [[ACTION:alarm|HH:MM]] [[ACTION:dial|number]] [[ACTION:sms_draft|number|text]] [[ACTION:web|query or url]] [[ACTION:youtube|search text]] [[ACTION:maps|place]] [[ACTION:calc|expression]] [[ACTION:torch_on]] [[ACTION:torch_off]] [[ACTION:wifi]] [[ACTION:bluetooth]] [[ACTION:settings]] [[ACTION:remember|fact to remember]].
For any arithmetic also append the calc tag so the app shows the exact value. Use remember only when the user asks you to remember something. Never claim an action succeeded; the app reports the real result. You cannot send SMS, make payments or delete data (sms_draft only opens a draft).
Known facts about the user:
${mem.ifBlank { "(none yet)" }}"""
    }

    fun send(text: String) {
        if (text.isBlank() || job?.isActive == true) return
        voice.stopSpeaking()
        val t = text.trim()
        messages.add(Msg("user", t)); db.addMessage("user", t)
        messages.add(Msg("model", ""))
        val idx = messages.lastIndex
        state = AState.THINKING; status = ""
        job = scope.launch {
            val sb = StringBuilder()
            try {
                val hist = messages.take(idx)
                    .filter { it.text.isNotBlank() && !it.text.startsWith("⚠️") }
                    .takeLast(20).dropWhile { it.role != "user" }
                    .map { it.role to it.text }
                val sys = systemPrompt()
                (if (store.provider == "groq") groq.stream(hist, sys) else gemini.stream(hist, sys)).collect {
                    sb.append(it); messages[idx] = Msg("model", ActionParser.strip(sb.toString()))
                }
                val full = sb.toString()
                val clean = ActionParser.strip(full)
                messages[idx] = Msg("model", clean.ifBlank { "(khali jawab)" })
                if (clean.isNotBlank()) db.addMessage("model", clean)
                val actions = ActionParser.parse(full)
                if (actions.isNotEmpty()) {
                    state = AState.EXECUTING
                    status = actions.joinToString(" | ") { run(it) }
                }
                val spoken = speakable(clean)
                if ((store.autoSpeak || handsFree) && spoken.isNotBlank()) {
                    state = AState.SPEAKING
                    voice.speak(spoken, store.lang, store.voiceName, store.rate, store.pitch) { finishTurn() }
                } else finishTurn()
            } catch (e: CancellationException) {
                messages[idx] = Msg("model", ActionParser.strip(sb.toString()).ifBlank { "(roka gaya)" })
                state = AState.IDLE; throw e
            } catch (e: Exception) {
                messages[idx] = Msg("model", "⚠️ ${e.message ?: e.javaClass.simpleName}")
                finishTurn()
            }
        }
    }

    /** Code blocks are shown on screen, not read aloud. */
    private fun speakable(t: String): String =
        t.replace(Regex("```[\\s\\S]*?```"), " Code screen par likha hai. ")
            .replace(Regex("[*_`#>]"), "").replace(Regex("\\s+"), " ").trim().take(3500)

    private fun run(a: Action): String = if (a.name == "remember") db.addMemory(a.arg).also { refreshMemories() } else device.execute(a.name, a.arg)

    /** Emergency stop: cancels generation, speech, mic and hands-free mode. */
    fun stopAll() {
        setHandsFree(false)
        job?.cancel(); voice.stopSpeaking(); voice.stopListening(); state = AState.IDLE; partial = ""
    }

    // ---------- push-to-talk ----------
    fun startListening() {
        voice.stopSpeaking(); state = AState.LISTENING; partial = ""
        voice.listen(store.lang, { partial = it }, { partial = ""; send(it) }, { status = it; partial = ""; state = AState.IDLE })
    }

    // ---------- hands-free: "Hey Nexus" ... "Stop Nexus" ----------
    fun setHandsFree(on: Boolean) {
        handsFree = on; awake = false
        store.autoHandsFree = on   // remembered so it can resume after reboot / process restart
        if (on) {
            status = ""
            try { ContextCompat.startForegroundService(app, Intent(app, ListenService::class.java)) }
            catch (e: Exception) { status = "Background service start FAIL: ${e.message} (app khula rakhna padega)" }
            listenLoop()
        } else {
            voice.stopListening(); voice.stopSpeaking(); state = AState.IDLE; partial = ""
            app.stopService(Intent(app, ListenService::class.java))
        }
    }

    private fun finishTurn() {
        state = AState.IDLE
        if (handsFree) scope.launch { delay(400); listenLoop() }
    }

    private fun listenLoop() {
        if (!handsFree || job?.isActive == true) return
        if (state == AState.SPEAKING || state == AState.THINKING || state == AState.EXECUTING) return
        state = if (awake) AState.LISTENING else AState.IDLE
        partial = ""
        voice.listen(store.lang, { partial = it }, { onHeard(it) }, { onListenFail(it) })
    }

    private fun onHeard(text: String) {
        partial = ""
        if (!handsFree) return
        when {
            WakeWords.isStop(text) && (awake || WakeWords.hasNexus(text)) -> {
                awake = false
                say("Theek hai, conversation band.")
            }
            !awake -> {
                if (WakeWords.hasNexus(text)) {
                    awake = true
                    val rest = WakeWords.afterWake(text)
                    if (rest.isBlank()) say("Haan, boliye?") else send(rest)
                } else relisten(300)
            }
            else -> send(text)
        }
    }

    private fun onListenFail(err: String) {
        partial = ""
        if (err.contains("code 9")) { setHandsFree(false); status = "Mic permission nahi mili - hands-free band."; return }
        if (!handsFree) { status = err; state = AState.IDLE; return }
        relisten(if (err.contains("code 8")) 1500 else 500)
    }

    private fun relisten(ms: Long) { scope.launch { delay(ms); listenLoop() } }

    private fun say(msg: String) {
        state = AState.SPEAKING
        voice.speak(msg, store.lang, store.voiceName, store.rate, store.pitch) { finishTurn() }
    }

    fun clearChat() { messages.clear(); db.clearMessages() }
}
