package com.nexus.ai.voice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.nexus.ai.data.SecureStore

/**
 * Restarts hands-free after phone reboot if it was ON before.
 * Only on Android 10 and below: Android 11+ blocks starting a microphone service from boot.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Build.VERSION.SDK_INT >= 30) return
        try {
            if (SecureStore(ctx).autoHandsFree) ContextCompat.startForegroundService(ctx, Intent(ctx, ListenService::class.java))
        } catch (_: Exception) { /* nothing else we can do at boot */ }
    }
}
