package com.nexus.ai.service

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.nexus.ai.ai.*
import com.nexus.ai.data.MemoryDb
import com.nexus.ai.data.SecureStore
import com.nexus.ai.device.DeviceAgent
import com.nexus.ai.voice.VoiceEngine
import kotlinx.coroutines.*

/**
 * Background "Hey Nexus" assistant. Foreground service (microphone) that keeps a speech-recognition loop running.
 *  WAKE mode: waits for "Hey Nexus" (optionally followed by a question in the same sentence).
 *  CHAT mode: every sentence is answered (by voice + saved to chat history) until you say "Stop Nexus".
 * Works with the app closed. NOT a true hardware wake-word engine: it uses Android SpeechRecognizer (needs internet on most phones).
 */
class NexusService : Service() {
    companion object {
        const val ACTION_STOP = "com.nexus.ai.STOP_SERVICE"
        const val ACTION_PAUSE = "com.nexus.ai.PAUSE_MIC"
        const val ACTION_RESUME = "com.nexus.ai.RESUME_MIC"
        private const val CH = "nexus_wake"
        private const val NID = 7
        @Volatile var running = false

        fun start(ctx: Context) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
            ContextCompat.startForegroundService(ctx, Intent(ctx, NexusService::class.java))
        }
        fun stop(ctx: Context) { ctx.startService(Intent(ctx, NexusService::class.java).setAction(ACTION_STOP)) }
        fun pause(ctx: Context) { if (running) ctx.startService(Intent(ctx, NexusService::class.java).setAction(ACTION_PAUSE)) }
        fun resume(ctx: Context) { if (running) ctx.startService(Intent(ctx, NexusService::class.java).setAction(ACTION_RESUME)) }
    }

    private enum class Mode { WAKE, CHAT }

    private lateinit var store: SecureStore
    private lateinit var db: MemoryDb
    private lateinit var voice: VoiceEngine
    private lateinit var device: DeviceAgent
    private lateinit var gemini: GeminiClient
    private lateinit var groq: GroqClient
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var mode = Mode.WAKE
    private var thinking = false
    private var speaking = false
    private var paused = false
    private var job: Job? = null
    private val history = mutableListOf<Pair<String, String>>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = SecureStore(this); db = MemoryDb(this); device = DeviceAgent(this)
        voice = VoiceEngine(this).also { it.init() }
        gemini = GeminiClient({ store.apiKey }, { store.model })
        groq = GroqClient({ store.groqKey }, { store.groqModel })
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nexus:wake").apply { setReferenceCounted(false); acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_PAUSE -> { paused = true; main.removeCallbacksAndMessages(null); killRecognizer(); return START_STICKY }
            ACTION_RESUME -> { paused = false; startListening(); return START_STICKY }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        goForeground()
        running = true
        startListening()
        return START_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Nexus listening", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1, Intent(this, NexusService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Nexus").setContentText("\"Hey Nexus\" bolo  •  \"Stop Nexus\" se band")
            .setOngoing(true).addAction(0, "Band karo", stopPi).build()
        ServiceCompat.startForeground(this, NID, n, if (Build.VERSION.SDK_INT >= 30) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
    }

    // ---------------- listening loop ----------------
    private fun killRecognizer() { try { recognizer?.destroy() } catch (_: Exception) {}; recognizer = null }

    private fun startListening(delayMs: Long = 0) {
        main.removeCallbacksAndMessages(null)
        main.postDelayed({
            if (!running || paused) return@postDelayed
            killRecognizer()
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return@postDelayed
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (t.isNotBlank()) onHeard(t, final = true)
                    if (recognizer === r) startListening(200)
                }
                override fun onPartialResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (t.isNotBlank()) onHeard(t, final = false)
                }
                override fun onError(e: Int) {
                    if (recognizer !== r) return
                    when (e) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> shutdown()
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> startListening(1500)
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> startListening(200)
                        else -> startListening(1000)
                    }
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, store.lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            })
        }, delayMs)
    }

    // ---------------- logic ----------------
    private fun onHeard(text: String, final: Boolean) {
        // "Stop Nexus" works anytime, even mid-reply, and on partial text for speed.
        if (WakeWord.isStop(text)) { endChat(); return }
        if (!final) {
            // bare "Hey Nexus" -> switch on immediately, do not wait for the pause
            if (mode == Mode.WAKE && WakeWord.isWake(text) && WakeWord.afterWake(text).isBlank()) activate()
            return
        }
        when (mode) {
            Mode.WAKE -> if (WakeWord.isWake(text)) {
                val rest = WakeWord.afterWake(text)
                if (rest.isNotBlank()) { setMode(Mode.CHAT); ask(rest) } else activate()
            }
            Mode.CHAT -> {
                if (thinking || speaking) return          // ignore echo of own voice
                val q = if (WakeWord.isWake(text)) WakeWord.afterWake(text) else text.trim()
                if (q.isNotBlank()) ask(q)
            }
        }
    }

    private fun activate() { setMode(Mode.CHAT); say("Haan boliye.") }

    private fun setMode(m: Mode) {
        mode = m
        val text = if (m == Mode.CHAT) "Chat ON — bolo, jawab milega  •  \"Stop Nexus\" se band" else "\"Hey Nexus\" bolo  •  \"Stop Nexus\" se band"
        val n = NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Nexus").setContentText(text).setOngoing(true).build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, n)
    }

    private fun endChat() {
        job?.cancel(); thinking = false
        voice.stopSpeaking(); speaking = false
        val was = mode; setMode(Mode.WAKE)
        if (was == Mode.CHAT) say("Theek hai, band.", keepMode = true)
        startListening(300)
    }

    private fun ask(q: String) {
        thinking = true
        db.addMessage("user", q); history.add("user" to q)
        job?.cancel()
        job = scope.launch {
            val sb = StringBuilder()
            try {
                val h = history.takeLast(20).dropWhile { it.first != "user" }
                val sys = Persona.system(db.all().map { it.text })
                val flow = if (store.provider == "groq") groq.stream(h, sys) else gemini.stream(h, sys)
                flow.collect { sb.append(it) }
                val full = sb.toString()
                val clean = ActionParser.strip(full).ifBlank { "(khali jawab)" }
                val results = ActionParser.parse(full).map { a ->
                    if (a.name == "remember") db.addMemory(a.arg) else device.execute(a.name, a.arg)
                }
                db.addMessage("model", clean); history.add("model" to clean)
                thinking = false
                val spoken = Persona.speakable(clean)
                say(if (results.isNotEmpty()) (spoken + " " + results.joinToString(". ")).trim() else spoken)
            } catch (e: CancellationException) { thinking = false; throw e }
            catch (e: Exception) { thinking = false; say(e.message ?: "Error aaya.") }
        }
    }

    private fun say(text: String, keepMode: Boolean = true) {
        if (text.isBlank()) return
        speaking = true
        voice.speak(text.take(1500), store.lang, store.voiceName, store.rate, store.pitch) {
            speaking = false
            startListening(500)  // fresh recognizer so it does not transcribe our own voice
        }
    }

    private fun shutdown() {
        running = false
        main.removeCallbacksAndMessages(null)
        job?.cancel(); killRecognizer(); voice.shutdown()
        try { wakeLock?.release() } catch (_: Exception) {}
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        scope.cancel(); killRecognizer()
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
