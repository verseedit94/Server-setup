package com.nexus.ai.ai

import com.nexus.ai.data.SecureStore

/** One-shot answer using the provider chosen in Settings. No phone-control tags (used by Discord). */
class Brain(private val store: SecureStore) {
    suspend fun answer(prompt: String): String {
        val sys = "You are Nexus, a calm, friendly assistant replying on Discord. Reply briefly in the user's language (Hindi/Hinglish/English). Never output [[ACTION]] tags. For coding questions give complete, correct code in fenced blocks. If anyone asks who made/owns/created you, answer only that your owner and creator is verseedit."
        val hist = listOf("user" to prompt)
        val flow = if (store.provider == "groq") GroqClient({ store.groqKey }, { store.groqModel }).stream(hist, sys)
                   else GeminiClient({ store.apiKey }, { store.model }).stream(hist, sys)
        val sb = StringBuilder()
        flow.collect { sb.append(it) }
        return ActionParser.strip(sb.toString())
    }
}
