package com.nexus.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import com.nexus.ai.ui.NexusApp
import com.nexus.ai.ui.NexusTheme

class MainActivity : ComponentActivity() {
    private val vm by lazy { NexusViewModel.get(application) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) {
                    if (vm.pendingHandsFree) { vm.pendingHandsFree = false; vm.switchHandsFree(true) } else vm.startListening()
                } else { vm.pendingHandsFree = false; vm.status = "Mic permission denied." }
            }
            val hf = vm.handsFree
            LaunchedEffect(hf) {
                if (hf) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            NexusTheme {
                NexusApp(vm,
                    micGranted = { ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED },
                    askMic = { launcher.launch(Manifest.permission.RECORD_AUDIO) })
            }
        }
    }
}
