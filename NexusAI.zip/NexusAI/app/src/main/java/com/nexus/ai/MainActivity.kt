package com.nexus.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.nexus.ai.ui.NexusApp
import com.nexus.ai.ui.NexusTheme

class MainActivity : ComponentActivity() {
    private val vm: NexusViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) vm.startListening() else vm.status = "Mic permission denied."
            }
            NexusTheme {
                NexusApp(vm,
                    micGranted = { ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED },
                    askMic = { launcher.launch(Manifest.permission.RECORD_AUDIO) })
            }
        }
    }
}
