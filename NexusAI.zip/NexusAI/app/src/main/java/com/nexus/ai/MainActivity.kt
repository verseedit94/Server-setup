package com.nexus.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import com.nexus.ai.service.NexusService
import com.nexus.ai.ui.NexusApp
import com.nexus.ai.ui.NexusTheme

class MainActivity : ComponentActivity() {
    private val vm: NexusViewModel by viewModels()
    private fun micOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                if (ok) vm.startListening() else vm.status = "Mic permission denied."
            }
            // First launch: ask mic (+ notifications on Android 13+) and start "Hey Nexus" background listening.
            val startupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                if (micOk() && vm.store.wakeEnabled) NexusService.start(this)
            }
            LaunchedEffect(Unit) {
                val need = mutableListOf<String>()
                if (!micOk()) need += Manifest.permission.RECORD_AUDIO
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    need += Manifest.permission.POST_NOTIFICATIONS
                if (need.isNotEmpty()) startupLauncher.launch(need.toTypedArray())
                else if (vm.store.wakeEnabled && !NexusService.running) NexusService.start(this@MainActivity)
            }
            NexusTheme {
                NexusApp(vm,
                    micGranted = { micOk() },
                    askMic = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) })
            }
        }
    }
}
