@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.nexus.ai.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nexus.ai.AState
import com.nexus.ai.NexusViewModel

@Composable
fun NexusTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Cyan, secondary = Blue, background = Navy, surface = Color(0xFF0B1426), onPrimary = Color.Black),
    content = content
)

@Composable
fun NexusApp(vm: NexusViewModel, micGranted: () -> Boolean, askMic: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Home", "Memory", "Device", "Settings")
    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B1426)) {
                tabs.forEachIndexed { i, n ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, label = { Text(n) },
                        icon = { Text(listOf("◉", "🧠", "📱", "⚙")[i]) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(Navy)) {
            when (tab) {
                0 -> HomeScreen(vm, micGranted, askMic)
                1 -> MemoryScreen(vm)
                2 -> DeviceScreen(vm)
                else -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
fun HomeScreen(vm: NexusViewModel, micGranted: () -> Boolean, askMic: () -> Unit) {
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text) { if (vm.messages.isNotEmpty()) list.animateScrollToItem(vm.messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(12.dp).imePadding()) {
        Avatar(vm.state, vm.store.reduceMotion, Modifier.fillMaxWidth().height(230.dp))
        Text(
            when (vm.state) { AState.IDLE -> "Ready"; AState.LISTENING -> "Sun raha hoon… ${vm.partial}"; AState.THINKING -> "Soch raha hoon…"
                AState.SPEAKING -> "Bol raha hoon…"; AState.EXECUTING -> "Task chal raha hai…" },
            color = Cyan, modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        if (vm.status.isNotBlank()) Text(vm.status, color = Color(0xFFB0BEC5), modifier = Modifier.align(Alignment.CenterHorizontally))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (vm.messages.isEmpty()) item { Text("Kuch bolo ya likho. Pehle Settings me Gemini API key daalo.", color = Color.Gray) }
            items(vm.messages.size) { i ->
                val m = vm.messages[i]; val me = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (me) Color(0xFF12305F) else Color(0xFF0F1D36)) {
                        Text(m.text.ifBlank { "…" }, Modifier.padding(10.dp), color = Color.White)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message Nexus…") }, maxLines = 3)
            if (vm.state != AState.IDLE) Button(onClick = { vm.stopAll() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))) { Text("STOP") }
            else {
                Button(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank()) { Text("➤") }
                Button(onClick = { if (micGranted()) vm.startListening() else askMic() }) { Text("🎤") }
            }
        }
    }
}

@Composable
fun MemoryScreen(vm: NexusViewModel) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var newText by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf<Long?>(null) }
    var editText by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) msg = try { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(vm.db.exportJson().toByteArray()) }; "Export ho gaya ✓" } catch (e: Exception) { "Export FAIL: ${e.message}" }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) msg = try { val n = vm.db.importJson(ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()); vm.refreshMemories(q); "$n nayi memories import hui ✓" } catch (e: Exception) { "Import FAIL: ${e.message}" }
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Memory", style = MaterialTheme.typography.titleLarge, color = Cyan)
        OutlinedTextField(q, { q = it; vm.refreshMemories(it) }, Modifier.fillMaxWidth(), placeholder = { Text("Search") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(newText, { newText = it }, Modifier.weight(1f), placeholder = { Text("Naya fact yaad rakhao") }, singleLine = true)
            Button(onClick = { msg = vm.db.addMemory(newText, "manual"); newText = ""; vm.refreshMemories(q) }) { Text("Save") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { exporter.launch("nexus-memory-backup.json") }) { Text("Export") }
            OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "*/*")) }) { Text("Import") }
        }
        if (msg.isNotBlank()) Text(msg, color = Cyan)
        Text("Note: app uninstall / clear-data par memory delete ho jati hai. Export se backup rakho.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        if (vm.memories.isEmpty()) Text("Koi memory nahi mili.", color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.memories, key = { it.id }) { m ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1D36))) {
                    Column(Modifier.padding(10.dp)) {
                        if (editId == m.id) {
                            OutlinedTextField(editText, { editText = it }, Modifier.fillMaxWidth())
                            Row { TextButton(onClick = { vm.db.update(m.id, editText); editId = null; vm.refreshMemories(q) }) { Text("Save") }
                                TextButton(onClick = { editId = null }) { Text("Cancel") } }
                        } else {
                            Text(m.text, color = Color.White)
                            Row { TextButton(onClick = { editId = m.id; editText = m.text }) { Text("Edit") }
                                TextButton(onClick = { vm.db.delete(m.id); vm.refreshMemories(q) }) { Text("Delete", color = Color(0xFFFF5252)) } }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeviceScreen(vm: NexusViewModel) {
    val ctx = LocalContext.current
    val mic = androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Device & Permissions", style = MaterialTheme.typography.titleLarge, color = Cyan)
        fun row(n: String, ok: Boolean, note: String) = "${if (ok) "✅" else "❌"} $n — $note"
        listOf(
            row("Microphone", mic, if (mic) "granted" else "denied (mic button dabao to prompt aayega)"),
            row("Speech recognition", vm.voice.available(), if (vm.voice.available()) "available" else "unavailable on this phone"),
            row("TTS voices", vm.voiceNames.isNotEmpty(), "${vm.voiceNames.size} installed"),
            row("Accessibility control", false, "is version me implement nahi (see README)"),
            row("Discord bot", false, "alag Python process (discord-bot/), app se connected nahi")
        ).forEach { Text(it, color = Color.White) }
        Text("Quick actions", color = Cyan)
        listOf("Battery" to "battery bata", "Network" to "network status bata", "Volume +" to "volume badhao", "Volume −" to "volume kam karo", "Time" to "abhi time kya hai").chunked(3).forEach { r ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { r.forEach { (l, p) -> OutlinedButton(onClick = { vm.send(p) }) { Text(l) } } }
        }
        Text("Sab actions Gemini ke through chalte hain aur asli result Home screen par dikhta hai. SMS/payment/delete support nahi hai.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SettingsScreen(vm: NexusViewModel) {
    val s = vm.store
    var key by remember { mutableStateOf(s.apiKey) }
    var model by remember { mutableStateOf(s.model) }
    var provider by remember { mutableStateOf(s.provider) }
    var groqKey by remember { mutableStateOf(s.groqKey) }
    var groqModel by remember { mutableStateOf(s.groqModel) }
    var rate by remember { mutableFloatStateOf(s.rate) }
    var pitch by remember { mutableFloatStateOf(s.pitch) }
    var auto by remember { mutableStateOf(s.autoSpeak) }
    var reduce by remember { mutableStateOf(s.reduceMotion) }
    var lang by remember { mutableStateOf(s.lang) }
    var voice by remember { mutableStateOf(s.voiceName) }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Settings", style = MaterialTheme.typography.titleLarge, color = Cyan) }
        item { Text("AI provider", color = Cyan) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = provider == "gemini", onClick = { provider = "gemini"; s.provider = "gemini" }, label = { Text("Gemini") })
            FilterChip(selected = provider == "groq", onClick = { provider = "groq"; s.provider = "groq" }, label = { Text("Groq") }) } }
        item {
            if (provider == "gemini") Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(key, { key = it; s.apiKey = it }, Modifier.fillMaxWidth(), label = { Text("Gemini API key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(model, { model = it; s.model = it }, Modifier.fillMaxWidth(), label = { Text("Gemini model") }, singleLine = true)
            } else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(groqKey, { groqKey = it; s.groqKey = it }, Modifier.fillMaxWidth(), label = { Text("Groq API key (gsk_...)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(groqModel, { groqModel = it; s.groqModel = it }, Modifier.fillMaxWidth(), label = { Text("Groq model") }, singleLine = true)
            }
        }
        item { Text("Keys Android Keystore se encrypted store hoti hain.", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
        item { Text("Language (voice in/out)", color = Cyan) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("hi-IN" to "Hindi", "en-IN" to "English IN", "en-US" to "English US").forEach { (c, n) ->
                FilterChip(selected = lang == c, onClick = { lang = c; s.lang = c }, label = { Text(n) }) } } }
        item { Text("Speed ${"%.1f".format(rate)}") }
        item { Slider(rate, { rate = it; s.rate = it }, valueRange = 0.5f..2f) }
        item { Text("Pitch ${"%.1f".format(pitch)} (kam = bhari awaaz)") }
        item { Slider(pitch, { pitch = it; s.pitch = it }, valueRange = 0.5f..1.5f) }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Switch(auto, { auto = it; s.autoSpeak = it }); Spacer(Modifier.width(8.dp)); Text("Replies automatically bolo") } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Switch(reduce, { reduce = it; s.reduceMotion = it }); Spacer(Modifier.width(8.dp)); Text("Reduce motion (static avatar)") } }
        item { Text("TTS voice (apni pasand ki male voice chuno)", color = Cyan) }
        item { OutlinedButton(onClick = { voice = ""; s.voiceName = "" }) { Text(if (voice.isEmpty()) "✓ Default voice" else "Default voice") } }
        val filtered = vm.voiceNames.filter { it.lowercase().startsWith(lang.substringBefore('-').lowercase()) }
        items(filtered) { n ->
            OutlinedButton(onClick = { voice = n; s.voiceName = n; vm.voice.speak("Namaste, main Nexus hoon.", lang, n, rate, pitch) {} }, modifier = Modifier.fillMaxWidth()) {
                Text(if (voice == n) "✓ $n" else n) }
        }
        if (filtered.isEmpty()) item { Text("Is language ki koi voice installed nahi. Phone Settings > TTS se voice data download karo.", color = Color.Gray) }
        item { OutlinedButton(onClick = { vm.clearChat() }) { Text("Chat history clear karo") } }
    }
}
