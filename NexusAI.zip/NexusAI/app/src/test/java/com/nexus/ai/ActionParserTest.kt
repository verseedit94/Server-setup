package com.nexus.ai

import com.nexus.ai.ai.ActionParser
import org.junit.Assert.assertEquals
import org.junit.Test

class ActionParserTest {
    @Test fun parsesActionsWithAndWithoutArgs() {
        val a = ActionParser.parse("Theek hai [[ACTION:open_app|YouTube]] [[ACTION:volume_down]]")
        assertEquals(2, a.size)
        assertEquals("open_app", a[0].name); assertEquals("YouTube", a[0].arg)
        assertEquals("volume_down", a[1].name); assertEquals("", a[1].arg)
    }
    @Test fun stripRemovesTagsAndPartialTag() {
        assertEquals("Done", ActionParser.strip("Done [[ACTION:timer|60]]"))
        assertEquals("Hello", ActionParser.strip("Hello [[ACTION:open_a"))
    }
}
