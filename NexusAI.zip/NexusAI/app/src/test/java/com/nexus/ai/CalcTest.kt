package com.nexus.ai

import com.nexus.ai.ai.Calc
import org.junit.Assert.assertEquals
import org.junit.Test

class CalcTest {
    @Test fun precedence() { assertEquals(14.0, Calc.eval("2+3*4"), 1e-9); assertEquals(20.0, Calc.eval("(2+3)*4"), 1e-9) }
    @Test fun powerIsRightAssociative() { assertEquals(512.0, Calc.eval("2^3^2"), 1e-9) }
    @Test fun unaryAndSqrt() { assertEquals(2.0, Calc.eval("-3+5"), 1e-9); assertEquals(4.0, Calc.eval("sqrt(16)"), 1e-9) }
    @Test fun division() { assertEquals(2.5, Calc.eval("10/4"), 1e-9) }
    @Test fun formatting() { assertEquals("14", Calc.format(14.0)); assertEquals("2.5", Calc.format(2.5)) }
    @Test(expected = ArithmeticException::class) fun divideByZero() { Calc.eval("1/0") }
}
