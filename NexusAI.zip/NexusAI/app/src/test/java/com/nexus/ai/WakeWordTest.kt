package com.nexus.ai

import com.nexus.ai.ai.Persona
import com.nexus.ai.ai.WakeWord
import org.junit.Assert.*
import org.junit.Test

class WakeWordTest {
    @Test fun wake() {
        assertTrue(WakeWord.isWake("Hey Nexus"))
        assertTrue(WakeWord.isWake("hey nexus time kya hai"))
        assertTrue(WakeWord.isWake("हे नेक्सस"))
        assertFalse(WakeWord.isWake("kya haal hai"))
        assertEquals("time kya hai", WakeWord.afterWake("hey nexus, time kya hai"))
        assertEquals("", WakeWord.afterWake("Hey Nexus"))
    }
    @Test fun stop() {
        assertTrue(WakeWord.isStop("stop nexus"))
        assertTrue(WakeWord.isStop("Stock Nexus"))
        assertTrue(WakeWord.isStop("nexus band karo"))
        assertFalse(WakeWord.isWake("stop nexus"))
        assertFalse(WakeWord.isStop("hey nexus"))
    }
    @Test fun speakableDropsCode() {
        assertEquals("Ye lo. Ho gaya", Persona.speakable("Ye lo.\n```python\nprint(1)\n```\nHo gaya"))
    }
}
