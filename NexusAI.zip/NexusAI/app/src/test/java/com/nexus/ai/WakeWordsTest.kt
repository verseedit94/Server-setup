package com.nexus.ai

import com.nexus.ai.ai.WakeWords
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WakeWordsTest {
    @Test fun detectsNexus() {
        assertTrue(WakeWords.hasNexus("Hey Nexus!"))
        assertFalse(WakeWords.hasNexus("hello there"))
    }
    @Test fun stopPhrases() {
        assertTrue(WakeWords.isStop("Stop Nexus"))
        assertTrue(WakeWords.isStop("stock nexus"))
        assertTrue(WakeWords.isStop("stop"))
        assertFalse(WakeWords.isStop("Nexus, volume badhao"))
        assertFalse(WakeWords.isStop("what is the time today"))
    }
    @Test fun afterWake() {
        assertEquals("youtube kholo", WakeWords.afterWake("Hey Nexus, YouTube kholo"))
        assertEquals("", WakeWords.afterWake("hey nexus"))
    }
}
