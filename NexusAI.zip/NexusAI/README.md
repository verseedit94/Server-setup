# NEXUS AI (v1.0 core)

Android assistant (Kotlin + Jetpack Compose) with a Gemini brain, voice in/out, local memory, phone actions,
plus a separate Python Discord bot. Package: `com.nexus.ai`.

> **Honesty note:** I wrote this code in an environment with no internet/Android SDK, so it has **NOT been compiled or run**.
> Only the Python helper tests were run (5 passed). Expect to fix a few build errors on first compile - paste the log to Gemini/Claude.

## What works (by design)
- Chat with streaming Gemini replies (Hindi/Hinglish/English), history saved in SQLite.
- Gemini API key stored with Android Keystore-backed EncryptedSharedPreferences. Never hardcoded.
  (A key inside any APK-run app can still be extracted from a rooted/modified phone; for production use a backend proxy.)
- Voice: push-to-talk speech recognition + Android TTS, speed/pitch sliders, voice picker, STOP button (interrupts speech/generation/mic).
  Not every phone has a male voice: lower pitch + pick a voice in Settings.
- Memory: add/search/edit/delete, duplicate skip, export/import JSON (you choose location). Keyword search only.
  Uninstall / clear-data deletes it -> export backups regularly.
- Phone actions via official APIs: open app, volume, battery, network, time, timer, alarm (opens Clock app), dial (opens dialer only), web search, settings.
  Real result is shown on Home; failures are reported as failures.
- Avatar: procedural holographic head on Compose Canvas (idle/listening/thinking/speaking states, blinking, eye movement, mouth motion, particles). Reduce-motion = static.
- Discord bot: /join /leave /ask /stop /status, answers by Gemini and speaks in the voice channel.

## NOT included (be aware)
- Real 3D model (glTF/Filament) + audio lip-sync: avatar is pseudo-3D Canvas art.
- Accessibility Service control (tap/scroll/read screen), wake word, foreground service, Room/embeddings, code editor/terminal panel, backend API, encrypted backup, setup wizard, light theme.
- Discord **voice receive** (listening to users). discord.py has no official support; experimental libs exist (e.g. discord-ext-voice-recv) - verify before using.
- Android app <-> Discord bot link: they are independent.

## 1) Build the APK in Termux
```bash
pkg update && pkg upgrade
pkg install openjdk-17 gradle aapt2 git unzip wget
termux-setup-storage
```
Android SDK (only platform + build-tools needed):
```bash
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
# download "commandlinetools-linux-*_latest.zip" from developer.android.com/studio#command-tools
unzip commandlinetools-linux-*.zip && mv cmdline-tools latest
export ANDROID_HOME=$HOME/android-sdk
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"
```
Project:
```bash
unzip NexusAI.zip -d ~/ && cd ~/NexusAI
echo "sdk.dir=$HOME/android-sdk" > local.properties
# edit gradle.properties: uncomment the android.aapt2FromMavenOverride line
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`
Install: `cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/` then open it from Files (allow "install unknown apps").

**Caveat:** Google's SDK tools are built for x86 Linux; on ARM Termux the Termux `aapt2` override is the known workaround but varies by phone/Android version. If it fails, use the fallback:
push this folder to a GitHub repo -> Actions -> "Build debug APK" (workflow included) -> download the APK artifact. Source stays editable from Termux.

Release signing: `keytool -genkey -v -keystore nexus.jks -alias nexus -keyalg RSA -keysize 2048 -validity 10000`, then add a `signingConfigs` block to app/build.gradle.kts reading passwords from env vars (never commit the keystore), and run `gradle :app:assembleRelease`.

Common errors: `SDK location not found` -> local.properties; `aapt2 ... Syntax error / exec format` -> aapt2 override; `Out of memory` -> lower `-Xmx` in gradle.properties; `License not accepted` -> rerun `sdkmanager --licenses`.

## 2) Use the app
Settings -> paste Gemini API key (aistudio.google.com) -> Home -> type or press the mic.
Try: "YouTube kholo", "volume kam karo", "5 minute ka timer", "yaad rakho ki mera naam Rahul hai".

## 3) Discord bot
1. discord.com/developers -> New Application -> Bot -> copy token. Invite with scopes `bot applications.commands`, permissions Connect + Speak + Send Messages.
2. Termux:
```bash
pkg install python ffmpeg libsodium clang make binutils
cd ~/NexusAI/discord-bot
python -m venv .venv && . .venv/bin/activate
SODIUM_INSTALL=system pip install -r requirements.txt
cp ../.env.example .env && chmod 600 .env && nano .env   # fill DISCORD_BOT_TOKEN, GEMINI_API_KEY
python -m unittest discover -s tests
./run.sh            # start (Ctrl+C stops)
```
Background: `termux-wake-lock` + `nohup ./run.sh > bot.log 2>&1 &` ; stop: `pkill -f bot.py`. Android may kill Termux; for 24/7 use a Linux VPS with the same commands (or systemd).
Use `/join` inside a voice channel, then `/ask`. `/status` shows real state. Set `ALLOWED_GUILD_IDS` to restrict servers.
Slash commands can take a while to appear after first start. Bots cannot join personal/DM calls - only server voice channels.

## Security
No secrets in source. `.env` is git-ignored. Bot redacts tokens from error messages. Actions never send SMS/payments or delete data.

---
## v1.3 additions (not compiled/run by the author - verify with the GitHub build)
- **Hands-free "Hey Nexus" / "Stop Nexus"**: Home tab switch. Starts a microphone foreground service so it keeps listening after you press Home
  or swipe the app away. After "Hey Nexus" the conversation stays ON (every reply is spoken) until you say "Stop Nexus" (then it waits for the next
  "Hey Nexus"). Full off: switch / notification Stop / STOP button.
  Limits: you must open the app once and enable the switch (Android blocks starting the mic from nothing / after reboot); some phones (Xiaomi/Redmi etc.)
  kill background apps - set battery to "No restrictions" + Autostart; speech recognition may need internet; uses battery; mic indicator is always shown by Android.
- **Open apps from background** needs "Display over other apps" (Device tab button).
- **Discord bot inside the app** (Settings > Discord bot): token + START. Text slash commands /ask /status /ping only (voice stays in discord-bot/ Python).
  Runs as a foreground service; Android may limit such services (e.g. ~6h/day for dataSync on Android 15 - verify) -> VPS for 24/7.
- **Groq** provider with a built-in default key (DefaultKeys.kt). Keep the repo private; rotate the key if leaked.
- New tools: exact calculator, torch, wifi/bluetooth settings, maps, YouTube search, SMS draft (never sends). Coding replies are shown as code on screen (not read aloud) and can be long-pressed to copy.
- Owner question -> assistant answers "verseedit".

### Android 10 notes
Android 10 does not restrict background microphone use (that started with Android 11), so hands-free is most reliable there.
Background app-launch IS restricted from Android 10 -> grant "Display over other apps" (Device tab).
After reboot, hands-free resumes automatically if it was ON (BootReceiver, Android 10 and below only). MIUI/Redmi: enable Autostart + battery "No restrictions".
