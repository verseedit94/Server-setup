import 'package:flutter/material.dart';

import '../theme.dart';

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 22,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: NX.card.withOpacity(0.72),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NX.violet.withOpacity(0.28)),
        boxShadow: [
          BoxShadow(color: NX.violet.withOpacity(0.12), blurRadius: 30, spreadRadius: 1),
        ],
      ),
      child: child,
    );
  }
}

class GradientButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool busy;
  final IconData? icon;
  const GradientButton({
    super.key,
    required this.label,
    required this.onTap,
    this.busy = false,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? 0.6 : 1,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: busy ? null : onTap,
          child: Ink(
            height: 54,
            decoration: BoxDecoration(
              gradient: NX.gradient,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [BoxShadow(color: NX.violet.withOpacity(0.45), blurRadius: 20, offset: const Offset(0, 6))],
            ),
            child: Center(
              child: busy
                  ? const SizedBox(
                      width: 22, height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (icon != null) ...[Icon(icon, size: 18), const SizedBox(width: 8)],
                        Text(label,
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, letterSpacing: 1.4, fontSize: 14)),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}
