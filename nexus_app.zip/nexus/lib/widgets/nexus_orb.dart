import 'dart:math';

import 'package:flutter/material.dart';

import '../models.dart';
import '../theme.dart';

/// The central animated orb: logo + pulsing rings + waveform ring.
class NexusOrb extends StatefulWidget {
  final AssistantStatus status;
  final double size;
  final VoidCallback? onTap;
  const NexusOrb({super.key, required this.status, this.size = 260, this.onTap});

  @override
  State<NexusOrb> createState() => _NexusOrbState();
}

class _NexusOrbState extends State<NexusOrb> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Color get _color {
    switch (widget.status) {
      case AssistantStatus.listening:
        return NX.cyan;
      case AssistantStatus.thinking:
        return NX.pink;
      case AssistantStatus.speaking:
        return NX.violet;
      case AssistantStatus.standby:
        return NX.blue;
    }
  }

  double get _energy {
    switch (widget.status) {
      case AssistantStatus.listening:
        return 1.0;
      case AssistantStatus.speaking:
        return 0.85;
      case AssistantStatus.thinking:
        return 0.55;
      case AssistantStatus.standby:
        return 0.2;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: s,
        height: s,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) => CustomPaint(
            painter: _OrbPainter(_c.value, _color, _energy),
            child: Center(
              child: Container(
                width: s * 0.52,
                height: s * 0.52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _color.withOpacity(0.8), width: 2),
                  boxShadow: [BoxShadow(color: _color.withOpacity(0.5), blurRadius: 28, spreadRadius: 2)],
                ),
                child: ClipOval(
                  child: Image.asset('assets/images/logo.png', fit: BoxFit.cover, alignment: const Alignment(0, -0.35)),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final double t;
  final Color color;
  final double energy;
  _OrbPainter(this.t, this.color, this.energy);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final base = size.width * 0.31;

    // expanding rings
    for (var i = 0; i < 3; i++) {
      final p = (t + i / 3) % 1.0;
      final r = base + p * size.width * 0.19;
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = color.withOpacity((1 - p) * 0.45),
      );
    }

    // waveform ring
    const bars = 72;
    final inner = base + 4;
    final paint = Paint()
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 2.6
      ..color = color.withOpacity(0.9);
    for (var i = 0; i < bars; i++) {
      final a = i / bars * 2 * pi;
      final wave = (sin(a * 5 + t * 2 * pi * 2) + sin(a * 9 - t * 2 * pi * 3)) / 2;
      final len = 3 + (wave.abs() * 16 + 2) * energy;
      final p1 = c + Offset(cos(a), sin(a)) * inner;
      final p2 = c + Offset(cos(a), sin(a)) * (inner + len);
      canvas.drawLine(p1, p2, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) =>
      old.t != t || old.color != color || old.energy != energy;
}
