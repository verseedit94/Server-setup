import 'dart:math';

import 'package:flutter/material.dart';

import '../theme.dart';

/// Animated twinkling stars + soft nebula glows used as the app background.
class Starfield extends StatefulWidget {
  final Widget child;
  const Starfield({super.key, required this.child});

  @override
  State<Starfield> createState() => _StarfieldState();
}

class _StarfieldState extends State<Starfield> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();
  late final List<_Star> _stars = () {
    final r = Random(7);
    return List.generate(
      70,
      (_) => _Star(r.nextDouble(), r.nextDouble(), r.nextDouble() * 1.6 + 0.4, r.nextDouble()),
    );
  }();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF0B0626), NX.bg],
            ),
          ),
        ),
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(painter: _StarPainter(_stars, _c.value)),
          ),
        ),
        widget.child,
      ],
    );
  }
}

class _Star {
  final double x, y, size, phase;
  _Star(this.x, this.y, this.size, this.phase);
}

class _StarPainter extends CustomPainter {
  final List<_Star> stars;
  final double t;
  _StarPainter(this.stars, this.t);

  @override
  void paint(Canvas canvas, Size size) {
    // nebula glows
    void glow(Offset c, double r, Color col) {
      final p = Paint()
        ..shader = RadialGradient(colors: [col.withOpacity(0.22), col.withOpacity(0)])
            .createShader(Rect.fromCircle(center: c, radius: r));
      canvas.drawCircle(c, r, p);
    }

    glow(Offset(size.width * 0.15, size.height * 0.12), size.width * 0.7, NX.violet);
    glow(Offset(size.width * 0.95, size.height * 0.85), size.width * 0.8, NX.blue);

    final paint = Paint();
    for (final s in stars) {
      final tw = 0.35 + 0.65 * (0.5 + 0.5 * sin((t + s.phase) * 2 * pi));
      paint.color = Colors.white.withOpacity(0.15 + 0.6 * tw);
      canvas.drawCircle(Offset(s.x * size.width, s.y * size.height), s.size * (0.7 + 0.3 * tw), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _StarPainter old) => old.t != t;
}
