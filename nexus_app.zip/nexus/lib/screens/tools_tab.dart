import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/glass_card.dart';

class ToolsTab extends StatelessWidget {
  final void Function(int) goTo;
  const ToolsTab({super.key, required this.goTo});

  static const _colors = [NX.blue, NX.ok, NX.cyan, NX.pink, NX.violet, Color(0xFFF59E0B)];

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        const Text('All Tools', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text('Mode chuniye - Nexus usi ke hisaab se jawab dega.',
            style: TextStyle(color: NX.muted, fontSize: 13)),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.05,
          children: [
            for (var i = 0; i < kTools.length; i++)
              _ToolCard(
                tool: kTools[i],
                color: _colors[i % _colors.length],
                selected: app.tool.id == kTools[i].id,
                onTap: () {
                  app.setTool(kTools[i]);
                  goTo(1);
                },
              ),
          ],
        ),
      ],
    );
  }
}

class _ToolCard extends StatelessWidget {
  final ToolMode tool;
  final Color color;
  final bool selected;
  final VoidCallback onTap;
  const _ToolCard({required this.tool, required this.color, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: GlassCard(
        radius: 20,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: color.withOpacity(0.2),
                border: Border.all(color: color.withOpacity(selected ? 1 : 0.5), width: selected ? 2 : 1),
              ),
              child: Icon(tool.icon, color: color),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tool.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
                const SizedBox(height: 2),
                Text(tool.subtitle, style: const TextStyle(color: NX.muted, fontSize: 11.5)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
