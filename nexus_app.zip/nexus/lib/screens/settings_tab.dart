import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/license_service.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/glass_card.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  late final TextEditingController _gKey, _gModel, _orKey, _orModel;
  bool _showG = false, _showOr = false;

  @override
  void initState() {
    super.initState();
    final a = context.read<AppState>();
    _gKey = TextEditingController(text: a.geminiKey);
    _gModel = TextEditingController(text: a.geminiModel);
    _orKey = TextEditingController(text: a.openRouterKey);
    _orModel = TextEditingController(text: a.openRouterModel);
  }

  @override
  void dispose() {
    _gKey.dispose();
    _gModel.dispose();
    _orKey.dispose();
    _orModel.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    await context.read<AppState>().saveBrain(
          gKey: _gKey.text,
          gModel: _gModel.text,
          orKey: _orKey.text,
          orModel: _orModel.text,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved')));
  }

  InputDecoration _dec(String label, {Widget? suffix}) => InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: NX.muted),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFF0B0724),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF2A2260))),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: NX.violet, width: 1.6)),
      );

  Widget _title(String t, IconData i) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 10),
        child: Row(children: [
          Icon(i, size: 18, color: NX.violet),
          const SizedBox(width: 8),
          Text(t, style: const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.2, fontSize: 13)),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        const Text('Settings', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),

        _title('BRAIN', Icons.psychology_rounded),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                width: double.infinity,
                child: SegmentedButton<BrainMode>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: BrainMode.auto, label: Text('Auto')),
                    ButtonSegment(value: BrainMode.gemini, label: Text('Gemini')),
                    ButtonSegment(value: BrainMode.openrouter, label: Text('OpenRouter')),
                  ],
                  selected: {app.brainMode},
                  onSelectionChanged: (s) => app.saveBrain(mode: s.first),
                ),
              ),
              const SizedBox(height: 6),
              const Text('Auto = pehle Gemini, fail ho to OpenRouter.',
                  style: TextStyle(color: NX.muted, fontSize: 12)),
              const SizedBox(height: 16),
              TextField(
                controller: _gKey,
                obscureText: !_showG,
                autocorrect: false,
                enableSuggestions: false,
                decoration: _dec('Gemini API key',
                    suffix: IconButton(
                      icon: Icon(_showG ? Icons.visibility_off : Icons.visibility, size: 20, color: NX.muted),
                      onPressed: () => setState(() => _showG = !_showG),
                    )),
              ),
              const SizedBox(height: 10),
              TextField(controller: _gModel, autocorrect: false, decoration: _dec('Gemini model')),
              const SizedBox(height: 16),
              TextField(
                controller: _orKey,
                obscureText: !_showOr,
                autocorrect: false,
                enableSuggestions: false,
                decoration: _dec('OpenRouter API key',
                    suffix: IconButton(
                      icon: Icon(_showOr ? Icons.visibility_off : Icons.visibility, size: 20, color: NX.muted),
                      onPressed: () => setState(() => _showOr = !_showOr),
                    )),
              ),
              const SizedBox(height: 10),
              TextField(controller: _orModel, autocorrect: false, decoration: _dec('OpenRouter model')),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 0,
                children: [
                  for (final m in const [
                    'google/gemini-2.5-flash',
                    'openai/gpt-4o-mini',
                    'anthropic/claude-sonnet-4.5',
                    'meta-llama/llama-3.3-70b-instruct:free',
                  ])
                    ActionChip(
                      label: Text(m, style: const TextStyle(fontSize: 11)),
                      onPressed: () => setState(() => _orModel.text = m),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                      backgroundColor: NX.violet, padding: const EdgeInsets.symmetric(vertical: 14)),
                  onPressed: _save,
                  icon: const Icon(Icons.save_rounded, size: 18),
                  label: const Text('Save keys & models'),
                ),
              ),
            ],
          ),
        ),

        _title('VOICE', Icons.record_voice_over_rounded),
        GlassCard(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Column(children: [
            SwitchListTile(
              value: app.female,
              onChanged: app.setFemale,
              title: const Text('Female voice'),
              subtitle: const Text('Off = male voice', style: TextStyle(color: NX.muted, fontSize: 12)),
              activeColor: NX.violet,
            ),
            SwitchListTile(
              value: app.autoSpeak,
              onChanged: app.setAutoSpeak,
              title: const Text('Auto-speak replies'),
              activeColor: NX.violet,
            ),
            ListTile(
              title: const Text('Language'),
              trailing: DropdownButton<String>(
                value: app.lang,
                underline: const SizedBox(),
                dropdownColor: NX.card,
                items: const [
                  DropdownMenuItem(value: 'en-IN', child: Text('English (India)')),
                  DropdownMenuItem(value: 'hi-IN', child: Text('Hindi')),
                  DropdownMenuItem(value: 'en-US', child: Text('English (US)')),
                  DropdownMenuItem(value: 'en-GB', child: Text('English (UK)')),
                ],
                onChanged: (v) {
                  if (v != null) app.setLang(v);
                },
              ),
            ),
          ]),
        ),

        _title('ACCOUNT', Icons.person_rounded),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(app.userName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: app.messages.isEmpty ? null : app.clearChat,
                    icon: const Icon(Icons.delete_outline_rounded, size: 18),
                    label: const Text('Clear chat'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(foregroundColor: NX.danger),
                    onPressed: app.logout,
                    icon: const Icon(Icons.logout_rounded, size: 18),
                    label: const Text('Logout'),
                  ),
                ),
              ]),
            ],
          ),
        ),
        _title('LICENSE', Icons.vpn_key_rounded),
        GlassCard(
          child: Row(children: [
            const Icon(Icons.verified_rounded, color: NX.ok),
            const SizedBox(width: 10),
            Expanded(
              child: Text('Activated  -  ${LicenseService.mask(app.licenseKey)}',
                  style: const TextStyle(fontSize: 13.5)),
            ),
          ]),
        ),
        const SizedBox(height: 20),
        const Center(child: Text('Nexus v1.0.0', style: TextStyle(color: NX.muted, fontSize: 12))),
      ],
    );
  }
}
