import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../services/license_service.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/glass_card.dart';
import 'auth_shell.dart';

/// Shown on first launch until a valid activation key is entered.
class ActivationScreen extends StatefulWidget {
  const ActivationScreen({super.key});

  @override
  State<ActivationScreen> createState() => _ActivationScreenState();
}

class _ActivationScreenState extends State<ActivationScreen> {
  final _ctl = TextEditingController();
  bool _busy = false;
  String? _error;
  int _fails = 0;
  DateTime? _lockUntil;

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  Future<void> _activate() async {
    FocusScope.of(context).unfocus();
    final now = DateTime.now();
    if (_lockUntil != null && now.isBefore(_lockUntil!)) {
      final s = _lockUntil!.difference(now).inSeconds + 1;
      setState(() => _error = '$s second baad dobara try karein.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final app = context.read<AppState>();
    await Future.delayed(const Duration(milliseconds: 500));
    final ok = await app.activate(_ctl.text);
    if (!mounted) return;
    if (!ok) {
      _fails++;
      if (_fails >= 5) {
        _lockUntil = DateTime.now().add(const Duration(seconds: 30));
        _fails = 0;
      }
    }
    setState(() {
      _busy = false;
      _error = ok ? null : 'Invalid activation key.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return AuthShell(
      heading: 'ACTIVATION REQUIRED',
      form: Column(
        children: [
          const Text(
            'Nexus use karne ke liye apni activation key daalein.',
            textAlign: TextAlign.center,
            style: TextStyle(color: NX.muted, fontSize: 13),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _ctl,
            autocorrect: false,
            enableSuggestions: false,
            textCapitalization: TextCapitalization.characters,
            inputFormatters: [
              FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9\-]')),
              LengthLimitingTextInputFormatter(23),
              _UpperCase(),
            ],
            onSubmitted: (_) => _activate(),
            style: const TextStyle(letterSpacing: 1.5, fontWeight: FontWeight.w600),
            decoration: NX.field('NXS-XXXX-XXXX-XXXX-XXXX', Icons.vpn_key_rounded),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: const TextStyle(color: NX.danger, fontSize: 13)),
          ],
          const SizedBox(height: 20),
          GradientButton(label: 'ACTIVATE', icon: Icons.bolt_rounded, busy: _busy, onTap: _activate),
        ],
      ),
      footer: const Text(
        'Key nahi hai? Developer se contact karke key kharidein.',
        textAlign: TextAlign.center,
        style: TextStyle(color: NX.muted, fontSize: 12),
      ),
    );
  }
}

class _UpperCase extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue o, TextEditingValue n) =>
      n.copyWith(text: n.text.toUpperCase());
}
