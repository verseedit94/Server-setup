import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/glass_card.dart';
import '../widgets/starfield.dart';

/// Shared layout for Login and Register screens.
class AuthShell extends StatelessWidget {
  final String heading;
  final Widget form;
  final Widget footer;
  const AuthShell({super.key, required this.heading, required this.form, required this.footer});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Starfield(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 18, 22, 18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 104,
                    height: 104,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: [BoxShadow(color: NX.violet.withOpacity(0.6), blurRadius: 36)],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(28),
                      child: Image.asset('assets/images/logo.png', fit: BoxFit.cover),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ShaderMask(
                    shaderCallback: (r) => NX.gradient.createShader(r),
                    child: const Text('NEXUS',
                        style: TextStyle(
                            fontSize: 34, fontWeight: FontWeight.w800, letterSpacing: 8, color: Colors.white)),
                  ),
                  const SizedBox(height: 4),
                  const Text('AI VOICE ASSISTANT',
                      style: TextStyle(fontSize: 11, letterSpacing: 4, color: NX.muted)),
                  const SizedBox(height: 26),
                  GlassCard(
                    padding: const EdgeInsets.fromLTRB(20, 22, 20, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(heading,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                fontSize: 12, letterSpacing: 4, color: NX.muted, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 18),
                        form,
                        const SizedBox(height: 14),
                        footer,
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text('Powered by Gemini & OpenRouter',
                      style: TextStyle(fontSize: 11, color: NX.muted)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
