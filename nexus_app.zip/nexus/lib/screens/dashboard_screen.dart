import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../widgets/starfield.dart';
import 'chat_tab.dart';
import 'home_tab.dart';
import 'settings_tab.dart';
import 'tools_tab.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _index = 0;

  void _go(int i) => setState(() => _index = i);

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();

    if (app.notice != null) {
      final msg = app.notice!;
      app.consumeNotice();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(msg)));
      });
    }

    final pages = <Widget>[
      HomeTab(goTo: _go),
      const ChatTab(),
      ToolsTab(goTo: _go),
      const SettingsTab(),
    ];

    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Starfield(child: SafeArea(bottom: false, child: IndexedStack(index: _index, children: pages))),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _go,
        height: 66,
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.blur_circular_rounded), label: 'Nexus'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline_rounded), label: 'Chat'),
          NavigationDestination(icon: Icon(Icons.apps_rounded), label: 'Tools'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }
}
