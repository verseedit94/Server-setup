import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/glass_card.dart';
import 'auth_shell.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pw = TextEditingController();
  final _pw2 = TextEditingController();
  bool _hide = true, _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _pw.dispose();
    _pw2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!_form.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final app = context.read<AppState>();
    final nav = Navigator.of(context);
    final err = await app.register(_name.text, _email.text, _pw.text);
    if (!mounted) return;
    if (err == null) {
      nav.popUntil((r) => r.isFirst); // main.dart swaps to dashboard
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthShell(
      heading: 'CREATE YOUR ACCOUNT',
      form: Form(
        key: _form,
        child: Column(
          children: [
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.next,
              decoration: NX.field('Full name', Icons.person_outline_rounded),
              validator: (v) => (v ?? '').trim().length < 2 ? 'Naam daalein' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.next,
              decoration: NX.field('Email address', Icons.mail_outline_rounded),
              validator: (v) =>
                  RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch((v ?? '').trim()) ? null : 'Sahi email daalein',
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _pw,
              obscureText: _hide,
              textInputAction: TextInputAction.next,
              decoration: NX.field(
                'Password (min 6)',
                Icons.lock_outline_rounded,
                suffix: IconButton(
                  icon: Icon(_hide ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                      size: 20, color: NX.muted),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
              validator: (v) => (v ?? '').length < 6 ? 'Kam se kam 6 characters' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _pw2,
              obscureText: _hide,
              onFieldSubmitted: (_) => _submit(),
              decoration: NX.field('Confirm password', Icons.verified_user_outlined),
              validator: (v) => v != _pw.text ? 'Password match nahi ho raha' : null,
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              Text(_error!, style: const TextStyle(color: NX.danger, fontSize: 13)),
            ],
            const SizedBox(height: 20),
            GradientButton(label: 'REGISTER', icon: Icons.rocket_launch_rounded, busy: _busy, onTap: _submit),
          ],
        ),
      ),
      footer: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('Pehle se account hai? ', style: TextStyle(color: NX.muted, fontSize: 13)),
          GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: const Text('Login',
                style: TextStyle(color: NX.cyan, fontSize: 13, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}
