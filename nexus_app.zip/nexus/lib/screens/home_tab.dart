import 'dart:async';

import 'package:battery_plus/battery_plus.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';
import '../widgets/glass_card.dart';
import '../widgets/nexus_orb.dart';

class HomeTab extends StatefulWidget {
  final void Function(int) goTo;
  const HomeTab({super.key, required this.goTo});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final _battery = Battery();
  int? _level;
  DateTime _now = DateTime.now();
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _readBattery();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) {
      if (!mounted) return;
      setState(() => _now = DateTime.now());
      _readBattery();
    });
  }

  Future<void> _readBattery() async {
    try {
      final l = await _battery.batteryLevel;
      if (mounted) setState(() => _level = l);
    } catch (_) {}
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String get _time {
    final h = _now.hour % 12 == 0 ? 12 : _now.hour % 12;
    final m = _now.minute.toString().padLeft(2, '0');
    return '$h:$m ${_now.hour >= 12 ? 'PM' : 'AM'}';
  }

  String _statusLabel(AssistantStatus s) {
    switch (s) {
      case AssistantStatus.listening:
        return 'LISTENING...';
      case AssistantStatus.thinking:
        return 'THINKING...';
      case AssistantStatus.speaking:
        return 'SPEAKING';
      case AssistantStatus.standby:
        return 'STANDBY';
    }
  }

  void _pickBrain(AppState app) {
    showModalBottomSheet(
      context: context,
      backgroundColor: NX.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('Choose Brain', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          for (final o in const [
            [BrainMode.auto, 'Auto', 'Gemini pehle, fail ho to OpenRouter'],
            [BrainMode.gemini, 'Gemini', 'Sirf Gemini'],
            [BrainMode.openrouter, 'OpenRouter', 'Sirf OpenRouter'],
          ])
            ListTile(
              leading: Icon(
                app.brainMode == o[0] ? Icons.radio_button_checked : Icons.radio_button_off,
                color: NX.violet,
              ),
              title: Text(o[1] as String),
              subtitle: Text(o[2] as String, style: const TextStyle(color: NX.muted, fontSize: 12)),
              onTap: () {
                app.saveBrain(mode: o[0] as BrainMode);
                Navigator.pop(ctx);
                if (!app.hasKey) widget.goTo(3);
              },
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  String _brainLabel(AppState a) {
    switch (a.brainMode) {
      case BrainMode.auto:
        return 'Auto';
      case BrainMode.gemini:
        return 'Gemini';
      case BrainMode.openrouter:
        return 'OpenRouter';
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final listening = app.status == AssistantStatus.listening;
    final caption = listening && app.partialSpeech.isNotEmpty
        ? app.partialSpeech
        : (app.lastReply.isNotEmpty
            ? app.lastReply
            : (app.hasKey ? 'Mic dabayein aur bolein, ${app.userName}.' : 'Settings me API key daalein.'));

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Hello,', style: TextStyle(color: NX.muted, fontSize: 12)),
                    Text(app.userName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              _Chip(
                icon: Icons.psychology_rounded,
                label: _brainLabel(app),
                color: NX.violet,
                onTap: () => _pickBrain(app),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: GlassCard(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            radius: 18,
            child: Row(
              children: [
                _Stat(Icons.battery_charging_full_rounded, 'Battery', _level == null ? '--' : '$_level%', NX.ok),
                _Stat(Icons.access_time_rounded, 'Time', _time, NX.cyan),
                _Stat(Icons.record_voice_over_rounded, 'Voice', app.female ? 'Female' : 'Male', NX.pink),
              ],
            ),
          ),
        ),
        Expanded(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              NexusOrb(
                status: app.status,
                size: 270,
                onTap: app.startListening,
              ),
              const SizedBox(height: 6),
              Text(_statusLabel(app.status),
                  style: const TextStyle(letterSpacing: 5, fontSize: 12, color: NX.cyan, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 84),
                  child: SingleChildScrollView(
                    child: Text(
                      caption,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: listening ? NX.text : NX.muted, fontSize: 14, height: 1.35),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _RoundBtn(
                icon: app.muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                label: app.muted ? 'Muted' : 'Sound',
                color: app.muted ? NX.danger : NX.blue,
                onTap: app.toggleMute,
              ),
              _RoundBtn(
                icon: listening ? Icons.stop_rounded : Icons.mic_rounded,
                label: listening ? 'Stop' : 'Speak',
                color: NX.violet,
                big: true,
                onTap: app.startListening,
              ),
              _RoundBtn(
                icon: Icons.photo_camera_rounded,
                label: 'Vision',
                color: NX.cyan,
                onTap: () async {
                  app.setTool(kTools.firstWhere((t) => t.id == 'vision'));
                  await app.pickImage(camera: true);
                  if (app.pendingImage != null) widget.goTo(1);
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _Chip({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 6),
          Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12)),
        ]),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final IconData icon;
  final String label, value;
  final Color color;
  const _Stat(this.icon, this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          Text(label, style: const TextStyle(color: NX.muted, fontSize: 11)),
        ],
      ),
    );
  }
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final bool big;
  final VoidCallback onTap;
  const _RoundBtn({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
    this.big = false,
  });

  @override
  Widget build(BuildContext context) {
    final d = big ? 76.0 : 58.0;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: onTap,
          child: Container(
            width: d,
            height: d,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: big
                  ? NX.gradient
                  : null,
              color: big ? null : color.withOpacity(0.18),
              border: big ? null : Border.all(color: color.withOpacity(0.55)),
              boxShadow: [BoxShadow(color: color.withOpacity(big ? 0.55 : 0.25), blurRadius: big ? 26 : 14)],
            ),
            child: Icon(icon, size: big ? 34 : 26, color: big ? Colors.white : color),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(color: NX.muted, fontSize: 11)),
      ],
    );
  }
}
