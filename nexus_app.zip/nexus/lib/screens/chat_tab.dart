import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../state/app_state.dart';
import '../theme.dart';

class ChatTab extends StatefulWidget {
  const ChatTab({super.key});

  @override
  State<ChatTab> createState() => _ChatTabState();
}

class _ChatTabState extends State<ChatTab> {
  final _ctl = TextEditingController();
  final _scroll = ScrollController();
  int _lastCount = 0;

  @override
  void dispose() {
    _ctl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent + 120,
            duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  void _send(AppState app) {
    final t = _ctl.text;
    _ctl.clear();
    app.send(t);
  }

  void _attach(AppState app) {
    showModalBottomSheet(
      context: context,
      backgroundColor: NX.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_camera_rounded, color: NX.cyan),
            title: const Text('Camera'),
            onTap: () {
              Navigator.pop(context);
              app.pickImage(camera: true);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_rounded, color: NX.violet),
            title: const Text('Gallery'),
            onTap: () {
              Navigator.pop(context);
              app.pickImage(camera: false);
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (app.messages.length != _lastCount) {
      _lastCount = app.messages.length;
      _scrollDown();
    }
    final thinking = app.status == AssistantStatus.thinking;
    final listening = app.status == AssistantStatus.listening;

    return Column(
      children: [
        // header
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 8),
          child: Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: NX.violet.withOpacity(0.25),
                child: Icon(app.tool.icon, size: 18, color: NX.violet),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(app.tool.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  Text(thinking ? 'typing...' : app.tool.subtitle,
                      style: const TextStyle(color: NX.muted, fontSize: 11)),
                ]),
              ),
              if (app.tool.id != 'general')
                TextButton(
                  onPressed: () => app.setTool(kDefaultTool),
                  child: const Text('Reset mode', style: TextStyle(fontSize: 12)),
                ),
              IconButton(
                tooltip: 'Clear chat',
                icon: const Icon(Icons.delete_sweep_outlined, color: NX.muted),
                onPressed: app.messages.isEmpty ? null : app.clearChat,
              ),
            ],
          ),
        ),
        const Divider(height: 1, color: Color(0xFF241C57)),
        Expanded(
          child: app.messages.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text('Kuch bhi poochiye - type karein, bolein ya photo bhejein.',
                        textAlign: TextAlign.center, style: TextStyle(color: NX.muted)),
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
                  itemCount: app.messages.length + (thinking ? 1 : 0),
                  itemBuilder: (_, i) {
                    if (i == app.messages.length) return const _Typing();
                    return _Bubble(app.messages[i]);
                  },
                ),
        ),
        if (app.pendingImage != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 6, 14, 0),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.memory(app.pendingImage!, height: 74, width: 74, fit: BoxFit.cover),
                  ),
                  Positioned(
                    right: -8,
                    top: -8,
                    child: GestureDetector(
                      onTap: app.clearImage,
                      child: const CircleAvatar(
                          radius: 11, backgroundColor: NX.danger, child: Icon(Icons.close, size: 14)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        if (listening && app.partialSpeech.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 6, 18, 0),
            child: Text(app.partialSpeech, style: const TextStyle(color: NX.cyan, fontSize: 13)),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              IconButton(
                onPressed: () => _attach(app),
                icon: const Icon(Icons.add_photo_alternate_outlined, color: NX.muted),
              ),
              Expanded(
                child: TextField(
                  controller: _ctl,
                  minLines: 1,
                  maxLines: 4,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => _send(app),
                  decoration: InputDecoration(
                    hintText: 'Message Nexus...',
                    hintStyle: const TextStyle(color: NX.muted),
                    filled: true,
                    fillColor: const Color(0xFF0F0A2C),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              GestureDetector(
                onTap: app.startListening,
                child: CircleAvatar(
                  radius: 22,
                  backgroundColor: listening ? NX.cyan : NX.card,
                  child: Icon(listening ? Icons.stop_rounded : Icons.mic_rounded,
                      color: listening ? NX.bg : NX.cyan),
                ),
              ),
              const SizedBox(width: 6),
              GestureDetector(
                onTap: () => _send(app),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: const BoxDecoration(shape: BoxShape.circle, gradient: NX.gradient),
                  child: const Icon(Icons.send_rounded, size: 20),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Bubble extends StatelessWidget {
  final ChatMessage m;
  const _Bubble(this.m);

  @override
  Widget build(BuildContext context) {
    final user = m.fromUser;
    final bg = m.isError
        ? NX.danger.withOpacity(0.18)
        : user
            ? NX.violet.withOpacity(0.35)
            : NX.card;
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: GestureDetector(
        onLongPress: () {
          Clipboard.setData(ClipboardData(text: m.text));
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('Copied'), duration: Duration(seconds: 1)));
        },
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.all(12),
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(18),
              topRight: const Radius.circular(18),
              bottomLeft: Radius.circular(user ? 18 : 4),
              bottomRight: Radius.circular(user ? 4 : 18),
            ),
            border: Border.all(
                color: m.isError ? NX.danger.withOpacity(0.6) : NX.violet.withOpacity(user ? 0.5 : 0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (m.image != null)
                Padding(
                  padding: EdgeInsets.only(bottom: m.text.isEmpty ? 0 : 8),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.memory(m.image!, height: 150, fit: BoxFit.cover),
                  ),
                ),
              if (m.text.isNotEmpty)
                SelectableText(m.text, style: const TextStyle(fontSize: 14.5, height: 1.4)),
            ],
          ),
        ),
      ),
    );
  }
}

class _Typing extends StatelessWidget {
  const _Typing();

  @override
  Widget build(BuildContext context) {
    return const Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        child: SizedBox(
          width: 34,
          height: 14,
          child: LinearProgressIndicator(color: NX.violet, backgroundColor: Color(0xFF241C57)),
        ),
      ),
    );
  }
}
