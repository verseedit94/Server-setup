import 'dart:convert';

import 'package:crypto/crypto.dart';

/// Offline activation keys: NXS-XXXX-XXXX-XXXX-XXXX
/// First 8 chars = random id, last 8 chars = HMAC-SHA256(secret, id).
/// Generate keys with tool/keygen.py using the SAME secret.
class LicenseService {
  static const _alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  // Default secret. Better: set GitHub secret NEXUS_LICENSE_SECRET (workflow passes it in).
  static const _defaultSecret = '68fbb022c5806094070f14a808768a78';
  static const _envSecret = String.fromEnvironment('NEXUS_SECRET');
  static String get _secret => _envSecret.isEmpty ? _defaultSecret : _envSecret;

  /// Key ids (first 8 chars after NXS) you want to block, e.g. refunded/leaked keys.
  static const Set<String> revoked = {};

  static String? _body(String input) {
    final c = input.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    if (!c.startsWith('NXS') || c.length != 19) return null;
    return c.substring(3);
  }

  static String _tag(String id) {
    final h = Hmac(sha256, utf8.encode(_secret)).convert(utf8.encode(id)).bytes;
    return List.generate(8, (i) => _alphabet[h[i] % 32]).join();
  }

  static bool isValid(String input) {
    final b = _body(input);
    if (b == null) return false;
    final id = b.substring(0, 8);
    if (revoked.contains(id)) return false;
    return _tag(id) == b.substring(8);
  }

  static String format(String input) {
    final b = _body(input) ?? '';
    if (b.length != 16) return input;
    return 'NXS-${b.substring(0, 4)}-${b.substring(4, 8)}-${b.substring(8, 12)}-${b.substring(12)}';
  }

  static String mask(String key) {
    final f = format(key);
    return f.length < 10 ? f : '${f.substring(0, 8)}-XXXX-XXXX-XXXX';
  }
}
