import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../models.dart';

class BrainConfig {
  final BrainMode mode;
  final String geminiKey;
  final String geminiModel;
  final String openRouterKey;
  final String openRouterModel;
  const BrainConfig({
    required this.mode,
    required this.geminiKey,
    required this.geminiModel,
    required this.openRouterKey,
    required this.openRouterModel,
  });
}

class BrainException implements Exception {
  final String message;
  BrainException(this.message);
  @override
  String toString() => message;
}

/// The "brain": Gemini (primary) + OpenRouter (fallback or standalone).
class BrainService {
  static const _timeout = Duration(seconds: 60);

  static Future<String> ask({
    required BrainConfig cfg,
    required List<ChatMessage> history,
    required String systemPrompt,
  }) async {
    final msgs = history.length > 20 ? history.sublist(history.length - 20) : history;
    final hasGemini = cfg.geminiKey.trim().isNotEmpty;
    final hasOr = cfg.openRouterKey.trim().isNotEmpty;

    switch (cfg.mode) {
      case BrainMode.gemini:
        if (!hasGemini) throw BrainException('Settings me Gemini API key daalein.');
        return _gemini(cfg, msgs, systemPrompt);
      case BrainMode.openrouter:
        if (!hasOr) throw BrainException('Settings me OpenRouter API key daalein.');
        return _openRouter(cfg, msgs, systemPrompt);
      case BrainMode.auto:
        if (!hasGemini && !hasOr) {
          throw BrainException('Settings me kam se kam ek API key (Gemini ya OpenRouter) daalein.');
        }
        if (hasGemini) {
          try {
            return await _gemini(cfg, msgs, systemPrompt);
          } catch (e) {
            if (!hasOr) rethrow;
          }
        }
        return _openRouter(cfg, msgs, systemPrompt);
    }
  }

  // ---------------- Gemini ----------------
  static Future<String> _gemini(
      BrainConfig cfg, List<ChatMessage> msgs, String system) async {
    final lastIdx = msgs.length - 1;
    final contents = <Map<String, dynamic>>[];
    for (var i = 0; i < msgs.length; i++) {
      final m = msgs[i];
      final parts = <Map<String, dynamic>>[];
      if (m.text.isNotEmpty) parts.add({'text': m.text});
      if (i == lastIdx && m.image != null) {
        parts.add({
          'inlineData': {'mimeType': 'image/jpeg', 'data': base64Encode(m.image!)}
        });
      }
      if (parts.isEmpty) continue;
      contents.add({'role': m.fromUser ? 'user' : 'model', 'parts': parts});
    }
    final uri = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/${cfg.geminiModel.trim()}:generateContent');
    final res = await http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'x-goog-api-key': cfg.geminiKey.trim(),
          },
          body: jsonEncode({
            'systemInstruction': {
              'parts': [
                {'text': system}
              ]
            },
            'contents': contents,
          }),
        )
        .timeout(_timeout);

    final body = _decode(res.bodyBytes);
    if (res.statusCode != 200) {
      throw BrainException('Gemini: ${body['error']?['message'] ?? 'HTTP ${res.statusCode}'}');
    }
    final parts = (body['candidates']?[0]?['content']?['parts'] as List?) ?? const [];
    final text = parts.map((p) => p['text'] ?? '').join().toString().trim();
    if (text.isEmpty) throw BrainException('Gemini ne khaali jawab diya.');
    return text;
  }

  // ---------------- OpenRouter ----------------
  static Future<String> _openRouter(
      BrainConfig cfg, List<ChatMessage> msgs, String system) async {
    final lastIdx = msgs.length - 1;
    final messages = <Map<String, dynamic>>[
      {'role': 'system', 'content': system},
    ];
    for (var i = 0; i < msgs.length; i++) {
      final m = msgs[i];
      final role = m.fromUser ? 'user' : 'assistant';
      if (i == lastIdx && m.image != null) {
        messages.add({
          'role': role,
          'content': [
            {'type': 'text', 'text': m.text.isEmpty ? 'Describe this image.' : m.text},
            {
              'type': 'image_url',
              'image_url': {'url': 'data:image/jpeg;base64,${base64Encode(m.image!)}'}
            },
          ],
        });
      } else {
        messages.add({'role': role, 'content': m.text});
      }
    }
    final res = await http
        .post(
          Uri.parse('https://openrouter.ai/api/v1/chat/completions'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${cfg.openRouterKey.trim()}',
            'X-Title': 'Nexus',
          },
          body: jsonEncode({'model': cfg.openRouterModel.trim(), 'messages': messages}),
        )
        .timeout(_timeout);

    final body = _decode(res.bodyBytes);
    if (res.statusCode != 200) {
      throw BrainException('OpenRouter: ${body['error']?['message'] ?? 'HTTP ${res.statusCode}'}');
    }
    final text = (body['choices']?[0]?['message']?['content'] ?? '').toString().trim();
    if (text.isEmpty) throw BrainException('OpenRouter ne khaali jawab diya.');
    return text;
  }

  static Map<String, dynamic> _decode(Uint8List bytes) {
    try {
      final d = jsonDecode(utf8.decode(bytes));
      return d is Map<String, dynamic> ? d : {};
    } catch (_) {
      return {};
    }
  }
}
