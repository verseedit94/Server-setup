import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final SpeechToText _stt = SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _sttReady = false;
  void Function(String status)? onStatus;

  Future<void> init() async {
    try {
      await _tts.awaitSpeakCompletion(true);
    } catch (_) {}
  }

  Future<bool> _ensureStt(void Function(String) onError) async {
    if (_sttReady) return true;
    _sttReady = await _stt.initialize(
      onError: (e) => onError(e.errorMsg),
      onStatus: (st) => onStatus?.call(st),
    );
    return _sttReady;
  }

  bool get isListening => _stt.isListening;

  /// Starts listening. [onFinal] is called once with the recognised text.
  Future<bool> listen({
    required String locale,
    required void Function(String partial) onPartial,
    required void Function(String text) onFinal,
    required void Function() onDone,
    required void Function(String) onError,
  }) async {
    if (!await _ensureStt(onError)) return false;
    var delivered = false;
    await _stt.listen(
      localeId: locale,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      listenOptions: SpeechListenOptions(partialResults: true, cancelOnError: true),
      onResult: (r) {
        if (r.finalResult) {
          if (!delivered) {
            delivered = true;
            onFinal(r.recognizedWords);
          }
        } else {
          onPartial(r.recognizedWords);
        }
      },
    );
    return true;
  }

  Future<void> stopListening() => _stt.stop();

  Future<void> speak(String text, {required String lang, required bool female}) async {
    final clean = text
        .replaceAll(RegExp(r'```[\s\S]*?```'), ' code block. ')
        .replaceAll(RegExp(r'[*_#`>~]'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    if (clean.isEmpty) return;
    try {
      await _tts.setLanguage(lang);
      await _tts.setPitch(female ? 1.25 : 0.8);
      await _tts.setSpeechRate(0.5);
      await _tts.speak(clean);
    } catch (_) {}
  }

  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
