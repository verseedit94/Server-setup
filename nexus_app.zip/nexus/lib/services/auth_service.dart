import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Simple on-device accounts. Passwords are salted + SHA-256 hashed.
/// Swap this class with Firebase/Supabase later if you want cloud sync.
class AuthService {
  static const _usersKey = 'nx_users';
  static const _sessionKey = 'nx_session';

  final SharedPreferences _p;
  AuthService(this._p);

  Map<String, dynamic> _users() {
    final raw = _p.getString(_usersKey);
    if (raw == null) return {};
    try {
      return Map<String, dynamic>.from(jsonDecode(raw));
    } catch (_) {
      return {};
    }
  }

  String _hash(String password, String salt) =>
      sha256.convert(utf8.encode('$salt:$password')).toString();

  String _salt() {
    final r = Random.secure();
    return base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
  }

  String? get sessionEmail => _p.getString(_sessionKey);

  String? nameOf(String email) {
    final u = _users()[email.toLowerCase()];
    return u == null ? null : u['name'] as String?;
  }

  /// Returns an error message, or null on success.
  Future<String?> register(String name, String email, String password) async {
    final e = email.trim().toLowerCase();
    final users = _users();
    if (users.containsKey(e)) return 'Is email se account pehle se hai.';
    final salt = _salt();
    users[e] = {'name': name.trim(), 'salt': salt, 'hash': _hash(password, salt)};
    await _p.setString(_usersKey, jsonEncode(users));
    await _p.setString(_sessionKey, e);
    return null;
  }

  Future<String?> login(String email, String password) async {
    final e = email.trim().toLowerCase();
    final u = _users()[e];
    if (u == null) return 'Account nahi mila. Pehle register karein.';
    if (_hash(password, u['salt'] as String) != u['hash']) {
      return 'Password galat hai.';
    }
    await _p.setString(_sessionKey, e);
    return null;
  }

  Future<void> logout() => _p.remove(_sessionKey);
}
