import 'package:flutter/material.dart';

class NX {
  static const bg = Color(0xFF070418);
  static const bg2 = Color(0xFF0E0A2E);
  static const card = Color(0xFF140E3B);
  static const violet = Color(0xFF8B5CF6);
  static const blue = Color(0xFF3B82F6);
  static const cyan = Color(0xFF22D3EE);
  static const pink = Color(0xFFEC4899);
  static const text = Color(0xFFEDEBFF);
  static const muted = Color(0xFF9A94C9);
  static const danger = Color(0xFFEF4444);
  static const ok = Color(0xFF34D399);

  static const gradient = LinearGradient(
    colors: [violet, blue],
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  static ThemeData theme() {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(
        primary: violet,
        secondary: cyan,
        surface: bg2,
      ),
      textTheme: base.textTheme.apply(bodyColor: text, displayColor: text),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: card,
        contentTextStyle: const TextStyle(color: text),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: const Color(0xFF0A0624),
        indicatorColor: violet.withOpacity(0.25),
        labelTextStyle: WidgetStateProperty.all(
          const TextStyle(fontSize: 11, color: muted),
        ),
      ),
    );
  }

  static InputDecoration field(String hint, IconData icon, {Widget? suffix}) {
    OutlineInputBorder b(Color c, [double w = 1]) => OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: c, width: w),
        );
    return InputDecoration(
      hintText: hint,
      hintStyle: const TextStyle(color: muted),
      prefixIcon: Icon(icon, color: muted, size: 20),
      suffixIcon: suffix,
      filled: true,
      fillColor: const Color(0xFF0B0724),
      contentPadding: const EdgeInsets.symmetric(vertical: 16),
      enabledBorder: b(const Color(0xFF2A2260)),
      focusedBorder: b(violet, 1.6),
      errorBorder: b(danger),
      focusedErrorBorder: b(danger, 1.6),
    );
  }
}
