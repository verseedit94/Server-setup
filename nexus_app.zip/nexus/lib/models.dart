import 'dart:typed_data';

import 'package:flutter/material.dart';

enum AssistantStatus { standby, listening, thinking, speaking }

enum BrainMode { auto, gemini, openrouter }

class ChatMessage {
  final bool fromUser;
  final String text;
  final Uint8List? image;
  final DateTime time;
  final bool isError;

  ChatMessage({
    required this.fromUser,
    required this.text,
    this.image,
    this.isError = false,
    DateTime? time,
  }) : time = time ?? DateTime.now();
}

class ToolMode {
  final String id;
  final String title;
  final String subtitle;
  final String prompt;
  final IconData icon;
  const ToolMode(this.id, this.title, this.subtitle, this.icon, this.prompt);
}

const kDefaultTool = ToolMode(
  'general',
  'Nexus Assistant',
  'General chat',
  Icons.chat_bubble_rounded,
  'You are Nexus, a friendly, smart AI voice assistant living in the user\'s phone. '
      'Reply in the same language the user writes in (Hindi, English or Hinglish). '
      'Keep answers short and natural because they may be spoken aloud. '
      'Use plain text; avoid markdown tables and long lists unless asked.',
);

const kTools = <ToolMode>[
  ToolMode(
    'text',
    'Text Generator',
    'Emails, posts, captions',
    Icons.edit_note_rounded,
    'You are Nexus in Text Generator mode. Write polished, ready-to-use text '
        '(emails, posts, captions, essays) in the language the user asks for.',
  ),
  ToolMode(
    'code',
    'Code Assistant',
    'Write & debug code',
    Icons.code_rounded,
    'You are Nexus in Code Assistant mode. Give correct, concise code with a short explanation. '
        'Put code in fenced blocks.',
  ),
  ToolMode(
    'translate',
    'Translator',
    'Any language to any',
    Icons.translate_rounded,
    'You are Nexus in Translator mode. Translate the user\'s text to the target language they mention; '
        'if none is given, translate Hindi/Hinglish to English and anything else to Hindi. '
        'Return only the translation plus a one-line pronunciation note if helpful.',
  ),
  ToolMode(
    'data',
    'Data Analysis',
    'Numbers, tables, insights',
    Icons.insights_rounded,
    'You are Nexus in Data Analysis mode. Analyse the data or question step by step, '
        'show key numbers, and finish with a clear conclusion.',
  ),
  ToolMode(
    'task',
    'Task Manager',
    'Plans, to-dos, reminders',
    Icons.task_alt_rounded,
    'You are Nexus in Task Manager mode. Turn the user\'s requests into clear prioritized to-do lists '
        'and schedules. Ask at most one clarifying question when needed.',
  ),
  ToolMode(
    'vision',
    'Vision',
    'Ask about a photo',
    Icons.photo_camera_rounded,
    'You are Nexus in Vision mode. Describe and analyse the image the user sends, '
        'read any text in it, and answer their question about it.',
  ),
];
