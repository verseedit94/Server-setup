import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import '../services/auth_service.dart';
import '../services/brain_service.dart';
import '../services/license_service.dart';
import '../services/voice_service.dart';

class AppState extends ChangeNotifier {
  final SharedPreferences prefs;
  final AuthService auth;
  final VoiceService voice = VoiceService();
  final ImagePicker _picker = ImagePicker();

  AppState(this.prefs) : auth = AuthService(prefs) {
    voice.init();
    voice.onStatus = (st) {
      if ((st == 'done' || st == 'notListening') && status == AssistantStatus.listening) {
        _setStatus(AssistantStatus.standby);
      }
    };
    _email = auth.sessionEmail;
  }

  // ---------- license ----------
  String get licenseKey => prefs.getString('nx_license') ?? '';
  bool get licensed => LicenseService.isValid(licenseKey);

  Future<bool> activate(String key) async {
    if (!LicenseService.isValid(key)) return false;
    await prefs.setString('nx_license', LicenseService.format(key));
    notifyListeners();
    return true;
  }

  // ---------- session ----------
  String? _email;
  bool get loggedIn => _email != null;
  String get userName => (_email == null ? null : auth.nameOf(_email!)) ?? 'Boss';

  Future<String?> login(String email, String pw) async {
    final err = await auth.login(email, pw);
    if (err == null) {
      _email = auth.sessionEmail;
      notifyListeners();
    }
    return err;
  }

  Future<String?> register(String name, String email, String pw) async {
    final err = await auth.register(name, email, pw);
    if (err == null) {
      _email = auth.sessionEmail;
      notifyListeners();
    }
    return err;
  }

  Future<void> logout() async {
    await stopAll();
    await auth.logout();
    _email = null;
    messages.clear();
    notifyListeners();
  }

  // ---------- settings ----------
  String get geminiKey => prefs.getString('gemini_key') ?? '';
  String get geminiModel => prefs.getString('gemini_model') ?? 'gemini-2.5-flash';
  String get openRouterKey => prefs.getString('or_key') ?? '';
  String get openRouterModel => prefs.getString('or_model') ?? 'google/gemini-2.5-flash';
  BrainMode get brainMode =>
      BrainMode.values[(prefs.getInt('brain_mode') ?? 0).clamp(0, BrainMode.values.length - 1)];
  bool get female => prefs.getBool('female') ?? true;
  bool get muted => prefs.getBool('muted') ?? false;
  String get lang => prefs.getString('lang') ?? 'en-IN';
  bool get autoSpeak => prefs.getBool('auto_speak') ?? true;

  Future<void> saveBrain({
    String? gKey,
    String? gModel,
    String? orKey,
    String? orModel,
    BrainMode? mode,
  }) async {
    if (gKey != null) await prefs.setString('gemini_key', gKey.trim());
    if (gModel != null && gModel.trim().isNotEmpty) {
      await prefs.setString('gemini_model', gModel.trim());
    }
    if (orKey != null) await prefs.setString('or_key', orKey.trim());
    if (orModel != null && orModel.trim().isNotEmpty) {
      await prefs.setString('or_model', orModel.trim());
    }
    if (mode != null) await prefs.setInt('brain_mode', mode.index);
    notifyListeners();
  }

  Future<void> setFemale(bool v) async {
    await prefs.setBool('female', v);
    notifyListeners();
  }

  Future<void> setLang(String v) async {
    await prefs.setString('lang', v);
    notifyListeners();
  }

  Future<void> setAutoSpeak(bool v) async {
    await prefs.setBool('auto_speak', v);
    notifyListeners();
  }

  Future<void> toggleMute() async {
    final v = !muted;
    await prefs.setBool('muted', v);
    if (v) await voice.stopSpeaking();
    notifyListeners();
  }

  bool get hasKey => geminiKey.isNotEmpty || openRouterKey.isNotEmpty;

  BrainConfig get _cfg => BrainConfig(
        mode: brainMode,
        geminiKey: geminiKey,
        geminiModel: geminiModel,
        openRouterKey: openRouterKey,
        openRouterModel: openRouterModel,
      );

  // ---------- assistant ----------
  final List<ChatMessage> messages = [];
  AssistantStatus status = AssistantStatus.standby;
  ToolMode tool = kDefaultTool;
  Uint8List? pendingImage;
  String partialSpeech = '';
  String lastReply = '';
  String? notice; // transient message shown by UI

  void _setStatus(AssistantStatus s) {
    status = s;
    notifyListeners();
  }

  void setTool(ToolMode t) {
    tool = t;
    notifyListeners();
  }

  void clearChat() {
    messages.clear();
    lastReply = '';
    notifyListeners();
  }

  Future<void> pickImage({required bool camera}) async {
    try {
      final f = await _picker.pickImage(
        source: camera ? ImageSource.camera : ImageSource.gallery,
        maxWidth: 1280,
        imageQuality: 75,
      );
      if (f == null) return;
      pendingImage = await f.readAsBytes();
      notifyListeners();
    } catch (e) {
      notice = 'Image nahi mil paayi: $e';
      notifyListeners();
    }
  }

  void clearImage() {
    pendingImage = null;
    notifyListeners();
  }

  Future<void> send(String text) async {
    final t = text.trim();
    if (t.isEmpty && pendingImage == null) return;
    if (status == AssistantStatus.thinking) return;
    await voice.stopSpeaking();

    messages.add(ChatMessage(fromUser: true, text: t, image: pendingImage));
    pendingImage = null;
    _setStatus(AssistantStatus.thinking);

    try {
      final reply = await BrainService.ask(
        cfg: _cfg,
        history: List.of(messages.where((m) => !m.isError)),
        systemPrompt: tool.prompt,
      );
      messages.add(ChatMessage(fromUser: false, text: reply));
      lastReply = reply;
      if (!muted && autoSpeak) {
        _setStatus(AssistantStatus.speaking);
        await voice.speak(reply, lang: lang, female: female);
      }
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      messages.add(ChatMessage(fromUser: false, text: msg, isError: true));
      lastReply = msg;
    }
    _setStatus(AssistantStatus.standby);
  }

  Future<void> startListening() async {
    if (status == AssistantStatus.listening) {
      await voice.stopListening();
      _setStatus(AssistantStatus.standby);
      return;
    }
    await voice.stopSpeaking();
    partialSpeech = '';
    final ok = await voice.listen(
      locale: lang.replaceAll('-', '_'),
      onPartial: (p) {
        partialSpeech = p;
        notifyListeners();
      },
      onFinal: (t) {
        partialSpeech = '';
        if (t.trim().isNotEmpty) send(t);
      },
      onDone: () {},
      onError: (e) {
        if (status == AssistantStatus.listening) _setStatus(AssistantStatus.standby);
      },
    );
    if (ok) {
      _setStatus(AssistantStatus.listening);
    } else {
      notice = 'Mic permission do ya speech recognition enable karein.';
      notifyListeners();
    }
  }

  Future<void> stopAll() async {
    await voice.stopListening();
    await voice.stopSpeaking();
    status = AssistantStatus.standby;
  }

  void consumeNotice() => notice = null;
}
