# Nexus - AI Voice Assistant (Android)

Flutter app. Brain: **Gemini** + **OpenRouter**. Screens: Login, Register, Dashboard (Nexus orb), Chat, Tools, Settings.

## APK banane ke steps (GitHub Actions)
1. Ye poora folder ek naye GitHub repo me push karein (`.github/` folder zaroor jaye).
2. Repo > **Actions** > **Build Nexus APK** > *Run workflow* (ya `main` par push karte hi chalega).
3. Run khatam hone par **Artifacts > Nexus-APK** se `app-release.apk` download karein.

Workflow khud `flutter create` se Android scaffold banata hai, app name `Nexus` set karta hai, mic/camera/internet permissions add karta hai aur logo se launcher icon banata hai.

## API keys
App me **Settings > Brain** me Gemini key (aistudio.google.com) aur/ya OpenRouter key (openrouter.ai) daalein.
Keys sirf phone me store hoti hain.

## Local run
```
flutter create --platforms=android --org com.nexus --project-name nexus .
python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter run
```

## Activation key (paid)
App bina valid key ke khulta nahi. Keys banane ke liye:
```
python3 tool/keygen.py 10      # 10 keys
```
Secret badalna ho to GitHub repo me secret `NEXUS_LICENSE_SECRET` set karein aur keygen chalate waqt
`NEXUS_SECRET=<wahi secret> python3 tool/keygen.py` use karein. **Repo private rakhein** (keygen.py ya secret public na ho).
Kisi key ko block karne ke liye uske pehle 8 chars (NXS ke baad) `LicenseService.revoked` me daalein.
