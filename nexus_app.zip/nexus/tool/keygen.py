#!/usr/bin/env python3
"""Nexus activation key generator.

Usage:  python3 tool/keygen.py [count]
Secret is read from env NEXUS_SECRET, else the default below
(it must match the secret inside the app / GitHub secret NEXUS_LICENSE_SECRET).
KEEP THIS FILE PRIVATE - do not give it to customers.
"""
import hashlib, hmac, os, secrets, sys

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
SECRET = os.environ.get("NEXUS_SECRET") or "68fbb022c5806094070f14a808768a78"


def make_key():
    kid = "".join(secrets.choice(ALPHABET) for _ in range(8))
    h = hmac.new(SECRET.encode(), kid.encode(), hashlib.sha256).digest()
    body = kid + "".join(ALPHABET[h[i] % 32] for i in range(8))
    return "NXS-" + "-".join(body[i:i + 4] for i in range(0, 16, 4))


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    for _ in range(n):
        print(make_key())
