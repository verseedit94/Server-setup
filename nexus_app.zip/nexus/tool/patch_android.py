"""Sets the app name to Nexus and adds the permissions Nexus needs."""
import re
import sys
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else "android/app/src/main/AndroidManifest.xml")
xml = path.read_text(encoding="utf-8")

perms = [
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
    "android.permission.CAMERA",
    "android.permission.BLUETOOTH",
    "android.permission.BLUETOOTH_CONNECT",
]
for name in perms:
    if f'"{name}"' not in xml:
        xml = xml.replace("<application", f'<uses-permission android:name="{name}"/>\n    <application', 1)

intents = (
    '<intent><action android:name="android.speech.RecognitionService"/></intent>\n'
    '        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>\n'
)
if "android.speech.RecognitionService" not in xml:
    if re.search(r"<queries>", xml):
        xml = re.sub(r"<queries>", "<queries>\n        " + intents, xml, count=1)
    else:
        xml = xml.replace("</manifest>", "    <queries>\n        " + intents + "    </queries>\n</manifest>")

xml = re.sub(r'android:label="[^"]*"', 'android:label="Nexus"', xml, count=1)
path.write_text(xml, encoding="utf-8")
print("AndroidManifest patched")
