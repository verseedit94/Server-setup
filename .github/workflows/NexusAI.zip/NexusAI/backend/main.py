"""Optional Nexus backend: an authenticated, rate-limited streaming proxy to OpenRouter.

The Android app can use it by setting the OpenRouter base URL to
https://YOUR-HOST/v1 and using NEXUS_AUTH_TOKEN as the "API key".
The real provider key stays in this server's environment only.
"""
import json
import os
import time
from collections import defaultdict, deque

import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse, StreamingResponse
from starlette.background import BackgroundTask

UPSTREAM = "https://openrouter.ai/api/v1/chat/completions"
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "")
AUTH_TOKEN = os.environ.get("NEXUS_AUTH_TOKEN", "")
RATE_LIMIT = int(os.environ.get("RATE_LIMIT_PER_MIN", "30"))

app = FastAPI(title="Nexus backend")
_hits: dict[str, deque] = defaultdict(deque)


def _guard(request: Request, authorization: str | None) -> None:
    if not AUTH_TOKEN or not OPENROUTER_API_KEY:
        raise HTTPException(503, "Server is not configured")
    if authorization != f"Bearer {AUTH_TOKEN}":
        raise HTTPException(401, "Unauthorized")
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    q = _hits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        raise HTTPException(429, "Rate limit exceeded")
    q.append(now)


@app.get("/health")
async def health():
    return {"status": "ok", "configured": bool(AUTH_TOKEN and OPENROUTER_API_KEY)}


@app.post("/v1/chat/completions")
async def chat(request: Request, authorization: str | None = Header(default=None)):
    _guard(request, authorization)
    body = await request.json()
    if not isinstance(body.get("messages"), list) or len(json.dumps(body)) > 6_000_000:
        raise HTTPException(400, "Invalid request")
    client = httpx.AsyncClient(timeout=httpx.Timeout(60.0, connect=10.0))
    req = client.build_request(
        "POST", UPSTREAM, json=body,
        headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}"},
    )
    r = await client.send(req, stream=True)
    if r.status_code >= 400:
        await r.aclose()
        await client.aclose()
        return JSONResponse(status_code=r.status_code,
                            content={"error": {"message": "Upstream error", "status": r.status_code}})

    async def close():
        await r.aclose()
        await client.aclose()

    return StreamingResponse(r.aiter_raw(),
                             media_type=r.headers.get("content-type", "text/event-stream"),
                             background=BackgroundTask(close))

# Run: uvicorn main:app --host 0.0.0.0 --port 8000   (put behind HTTPS, e.g. Render/Fly/Caddy)
