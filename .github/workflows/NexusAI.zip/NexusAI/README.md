# Nexus AI (Android) — Part 2

**Not compiled by the author of this zip** (no Android SDK/network in the sandbox). The first GitHub Actions run is the
real build test. If it fails, send the error log and it will be fixed.

## Build with GitHub Actions
1. New GitHub repo -> upload everything here (keep the `.github` folder).
2. Push to `main` -> **Actions -> Build Nexus AI (debug APK)**.
3. Download artifact **NexusAI-debug-apk**, unzip, install `app-debug.apk`.

## Setup
Settings -> AI provider -> Gemini, OpenRouter or Groq (console.groq.com) -> paste your own API key (encrypted with Android Keystore).
Safer: deploy `backend/` (FastAPI proxy, `.env.example`) and use its URL + `/v1` as the OpenRouter base URL
with `NEXUS_AUTH_TOKEN` as the key. Use a **vision-capable model** for image questions.

## Features
| Feature | How it works | Limits |
|---|---|---|
| Voice, TTS, voice mode, interrupt | SpeechRecognizer + TextToSpeech | quality depends on phone's speech engine; male voice only if engine has one |
| Wake word | Foreground service (mic) + SpeechRecognizer loop matches your phrase | Not a low-power engine: more battery, may beep, audio may go to Google's speech service. If app isn't running, a "Nexus heard you" notification appears to tap |
| Live screen reading | MediaProjection consent + foreground service, one frame on request ("Read screen" / "explain the error on my screen") | Secure/protected screens are black. You must switch to the target screen during the countdown, then return to Nexus |
| Camera + vision | CameraX photo -> preview -> **Ask AI** uploads image to your provider | Nothing uploaded without tapping Ask AI |
| Hindi + English OCR | ML Kit Latin + Devanagari, on-device | Printed text works best |
| Web research with sources | Gemini: Google Search grounding. OpenRouter: `:online` plugin. Sources shown as links under the answer | Needs a provider/model that supports it; free tiers may refuse. Without sources the answer is flagged unverified |
| HTML preview | "Preview" button on ```html blocks; sandboxed WebView (JS & network off by default) + save to chosen location | Only HTML preview |
| Memory, history search, export | Room | |
| Phone actions | open app/url, timer, alarm, settings, volume, share, copy, dial, WhatsApp draft, files | Android blocks silent control of other apps |

Say "research <topic>" or toggle **Web: ON** for research. Say "read my screen" after starting a session in Tools.

## Still not included
Discord voice bot, cloud sync, brightness control, dedicated low-power wake-word engine (e.g. Porcupine needs its own key and trained "Hey Nexus" file), full Markdown rendering (bold + code blocks only), Python/other-language code execution (by design).

## Troubleshooting
- Wake word never triggers: speech service may need network or an offline language pack; try a simple phrase.
- Screen capture is black: the app on screen blocks capture.
- 404 from provider: model name wrong or doesn't support images/search. 401/403: bad key. 429: rate limit.
- Local build: Gradle 8.7, JDK 17, `local.properties` with `sdk.dir`.
