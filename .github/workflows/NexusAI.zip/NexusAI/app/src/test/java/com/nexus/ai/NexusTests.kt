package com.nexus.ai

import com.nexus.ai.automation.ActionParser
import com.nexus.ai.automation.ActionRequest
import com.nexus.ai.automation.DefaultTools
import com.nexus.ai.automation.ToolRegistry
import com.nexus.ai.automation.Validation
import com.nexus.ai.memory.MemoryGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionParserTest {
    @Test fun openApp() {
        val r = ActionParser.parse("Nexus, open YouTube.")
        assertEquals("open_app", r?.name); assertEquals("YouTube", r?.args?.get("app"))
    }
    @Test fun timerWords() {
        val r = ActionParser.parse("Nexus, set a timer for ten minutes")
        assertEquals("set_timer", r?.name); assertEquals("600", r?.args?.get("seconds"))
    }
    @Test fun timerDigits() { assertEquals("90", ActionParser.parse("timer 90 seconds")?.args?.get("seconds")) }
    @Test fun volumeUp() { assertEquals("up", ActionParser.parse("increase media volume")?.args?.get("direction")) }
    @Test fun search() { assertEquals("Minecraft server hosting", ActionParser.parse("search the web for Minecraft server hosting")?.args?.get("query")) }
    @Test fun wifiSettings() { assertEquals("wifi", ActionParser.parse("open wifi settings")?.args?.get("page")) }
    @Test fun createFile() { assertEquals("notes.txt", ActionParser.parse("create a text file called notes.txt")?.args?.get("name")) }
    @Test fun hinglishOpen() { assertEquals("whatsapp", ActionParser.parse("whatsapp kholo")?.args?.get("app")) }
    @Test fun chatIsNotAnAction() { assertNull(ActionParser.parse("what is the capital of France")) }
    @Test fun aiJson() {
        val r = ActionParser.parseAiJson("{\"action\":\"open_app\",\"args\":{\"app\":\"Maps\"}}")
        assertEquals("open_app", r?.name); assertEquals("Maps", r?.args?.get("app"))
    }
    @Test fun aiJsonRejectsProse() { assertNull(ActionParser.parseAiJson("Sure! Opening it now.")) }
}

class ToolRegistryTest {
    private val reg = ToolRegistry(DefaultTools.all())
    @Test fun unknownActionRejected() { assertTrue(reg.validate(ActionRequest("rm_rf", mapOf("path" to "/"))) is Validation.Invalid) }
    @Test fun unexpectedArgRejected() { assertTrue(reg.validate(ActionRequest("battery_status", mapOf("x" to "1"))) is Validation.Invalid) }
    @Test fun missingArgRejected() { assertTrue(reg.validate(ActionRequest("open_app")) is Validation.Invalid) }
    @Test fun validAccepted() { assertTrue(reg.validate(ActionRequest("open_app", mapOf("app" to "YouTube"))) is Validation.Valid) }
    @Test fun oversizedArgRejected() { assertTrue(reg.validate(ActionRequest("copy_text", mapOf("text" to "a".repeat(5000)))) is Validation.Invalid) }
    @Test fun deleteIsSensitive() { assertTrue(reg.get("delete_file")!!.sensitive) }
    @Test fun parserOutputAlwaysValid() {
        val r = ActionParser.parse("open YouTube")
        assertNotNull(r); assertTrue(reg.validate(r!!) is Validation.Valid)
    }
}

class MemoryGuardTest {
    @Test fun extractsFact() { assertEquals("my dog is called Rex", MemoryGuard.candidate("Remember that my dog is called Rex")) }
    @Test fun ignoresNormalChat() { assertNull(MemoryGuard.candidate("how are you")) }
    @Test fun blocksSecrets() {
        assertTrue(MemoryGuard.isSensitive("my password is hunter2"))
        assertTrue(MemoryGuard.isSensitive("card 4111111111111111"))
        assertFalse(MemoryGuard.isSensitive("I like cricket"))
    }
}

class ResearchParserTest {
    @Test fun researchPrefix() { assertEquals("quantum computing", ActionParser.researchQuery("Nexus, research quantum computing")) }
    @Test fun newsPrefix() { assertEquals("india cricket", ActionParser.researchQuery("news about india cricket")) }
    @Test fun normalChatIsNotResearch() { assertNull(ActionParser.researchQuery("what time is it")) }
    @Test fun researchIsNotBrowserSearch() { assertNull(ActionParser.parse("research solar panels")) }
}
