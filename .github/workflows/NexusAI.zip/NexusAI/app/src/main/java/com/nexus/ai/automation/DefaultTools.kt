package com.nexus.ai.automation

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private fun Context.launch(i: Intent): Boolean {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try { startActivity(i); true } catch (e: ActivityNotFoundException) { false }
}

private val fileNameRule = Regex("^[\\w][\\w.\\- ]{0,63}$")

private fun Context.nexusDir(): File =
    File(getExternalFilesDir(null) ?: filesDir, "NexusFiles").also { it.mkdirs() }

object DefaultTools {
    fun all(): List<Tool> = listOf(
        OpenApp, OpenUrl, WebSearch, SetTimer, SetAlarm, OpenSettings, BatteryStatus, VolumeTool,
        ShareText, CopyText, DialTool, WhatsAppDraft, CreateFile, RenameFile, DeleteFile, DeviceInfo
    )
}

object OpenApp : Tool {
    override val name = "open_app"
    override val description = "Open an installed app by its name"
    override val args = setOf("app")
    override val required = setOf("app")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val q = a.getValue("app").trim().lowercase()
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return ToolResult(false, "I couldn't find an app named '${a["app"]}'.")
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return ToolResult(false, "That app can't be launched.")
        val label = match.loadLabel(pm)
        return if (ctx.launch(intent)) ToolResult(true, "Opening $label.") else ToolResult(false, "Couldn't open $label.")
    }
}

object OpenUrl : Tool {
    override val name = "open_url"
    override val description = "Open a website (http/https) in the browser"
    override val args = setOf("url")
    override val required = setOf("url")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val raw = a.getValue("url").trim()
        val uri = Uri.parse(if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw")
        if ((uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) return ToolResult(false, "That isn't a valid web address.")
        return if (ctx.launch(Intent(Intent.ACTION_VIEW, uri))) ToolResult(true, "Opening ${uri.host}.") else ToolResult(false, "No browser available.")
    }
}

object WebSearch : Tool {
    override val name = "web_search"
    override val description = "Search the web in the browser (opens results; Nexus does not read them)"
    override val args = setOf("query")
    override val required = setOf("query")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getValue("query")))
        return if (ctx.launch(Intent(Intent.ACTION_VIEW, uri))) ToolResult(true, "Searching the web for '${a["query"]}'.") else ToolResult(false, "No browser available.")
    }
}

object SetTimer : Tool {
    override val name = "set_timer"
    override val description = "Start a countdown timer (seconds: 1-86400)"
    override val args = setOf("seconds")
    override val required = setOf("seconds")
    override val permissionNote = "Uses the SET_ALARM permission (granted at install)"
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val s = a["seconds"]?.toIntOrNull()?.takeIf { it in 1..86400 } ?: return ToolResult(false, "Timer length must be 1 to 86400 seconds.")
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "Nexus timer")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (ctx.launch(i)) ToolResult(true, "Timer set for ${if (s % 60 == 0) "${s / 60} minutes" else "$s seconds"}.")
        else ToolResult(false, "No clock app can set timers on this phone.")
    }
}

object SetAlarm : Tool {
    override val name = "set_alarm"
    override val description = "Set an alarm (hour 0-23, minute 0-59, optional label)"
    override val args = setOf("hour", "minute", "label")
    override val required = setOf("hour", "minute")
    override val permissionNote = "Uses the SET_ALARM permission (granted at install)"
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val h = a["hour"]?.toIntOrNull()?.takeIf { it in 0..23 } ?: return ToolResult(false, "Hour must be 0 to 23.")
        val m = a["minute"]?.toIntOrNull()?.takeIf { it in 0..59 } ?: return ToolResult(false, "Minute must be 0 to 59.")
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a["label"] ?: "Nexus alarm")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return if (ctx.launch(i)) ToolResult(true, "Alarm set for %02d:%02d.".format(h, m)) else ToolResult(false, "No clock app can set alarms.")
    }
}

object OpenSettings : Tool {
    override val name = "open_settings"
    override val description = "Open a system settings page (page: wifi, bluetooth, display, sound, main)"
    override val args = setOf("page")
    override val required = setOf("page")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val action = when (a["page"]?.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "main" -> Settings.ACTION_SETTINGS
            else -> return ToolResult(false, "Unknown settings page.")
        }
        return if (ctx.launch(Intent(action))) ToolResult(true, "Opening ${a["page"]} settings. Android requires you to change the setting yourself.")
        else ToolResult(false, "Couldn't open that settings page.")
    }
}

object BatteryStatus : Tool {
    override val name = "battery_status"
    override val description = "Report battery level"
    override val args = emptySet<String>()
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return ToolResult(true, "Battery is at $pct%${if (bm.isCharging) " and charging" else ""}.")
    }
}

object VolumeTool : Tool {
    override val name = "volume"
    override val description = "Raise or lower media volume (direction: up or down)"
    override val args = setOf("direction")
    override val required = setOf("direction")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val dir = when (a["direction"]?.lowercase()) {
            "up" -> AudioManager.ADJUST_RAISE
            "down" -> AudioManager.ADJUST_LOWER
            else -> return ToolResult(false, "Direction must be up or down.")
        }
        val am = ctx.getSystemService(AudioManager::class.java)
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        return ToolResult(true, "Media volume ${a["direction"]}.")
    }
}

object ShareText : Tool {
    override val name = "share_text"
    override val description = "Open the Android share sheet with some text"
    override val args = setOf("text")
    override val required = setOf("text")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.getValue("text"))
        return if (ctx.launch(Intent.createChooser(send, "Share via"))) ToolResult(true, "Opened the share sheet.") else ToolResult(false, "Sharing isn't available.")
    }
}

object CopyText : Tool {
    override val name = "copy_text"
    override val description = "Copy text to the clipboard"
    override val args = setOf("text")
    override val required = setOf("text")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Nexus", a.getValue("text")))
        return ToolResult(true, "Copied to clipboard.")
    }
}

object DialTool : Tool {
    override val name = "dial"
    override val description = "Open the dialer with a number (you press call)"
    override val args = setOf("number")
    override val required = setOf("number")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val n = a.getValue("number").trim()
        if (!Regex("^[+0-9 ()-]{3,20}$").matches(n)) return ToolResult(false, "That doesn't look like a phone number.")
        return if (ctx.launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))) ToolResult(true, "Dialer opened. Press call to dial.")
        else ToolResult(false, "No dialer available.")
    }
}

object WhatsAppDraft : Tool {
    override val name = "prepare_whatsapp"
    override val description = "Open WhatsApp with a drafted message (optional phone with country code). You review and press send."
    override val args = setOf("text", "phone")
    override val required = setOf("text")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult {
        val phone = a["phone"]?.filter { it.isDigit() }.orEmpty()
        val url = "https://wa.me/" + phone + "?text=" + Uri.encode(a.getValue("text"))
        return if (ctx.launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) ToolResult(true, "Draft ready in WhatsApp. Review it and press send yourself.")
        else ToolResult(false, "Couldn't open WhatsApp.")
    }
}

object CreateFile : Tool {
    override val name = "create_file"
    override val description = "Create a text file in Nexus's own folder (name, optional content)"
    override val args = setOf("name", "content")
    override val required = setOf("name")
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val n = a.getValue("name").trim()
        if (!fileNameRule.matches(n)) return@withContext ToolResult(false, "Invalid file name.")
        val f = File(ctx.nexusDir(), n)
        if (f.exists()) return@withContext ToolResult(false, "'$n' already exists.")
        f.writeText(a["content"].orEmpty())
        ToolResult(true, "Created $n in ${f.parentFile?.absolutePath}.")
    }
}

object RenameFile : Tool {
    override val name = "rename_file"
    override val description = "Rename a file in Nexus's folder (name, new_name)"
    override val args = setOf("name", "new_name")
    override val required = setOf("name", "new_name")
    override val sensitive = true
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val from = a.getValue("name").trim(); val to = a.getValue("new_name").trim()
        if (!fileNameRule.matches(from) || !fileNameRule.matches(to)) return@withContext ToolResult(false, "Invalid file name.")
        val src = File(ctx.nexusDir(), from); val dst = File(ctx.nexusDir(), to)
        if (!src.exists()) return@withContext ToolResult(false, "'$from' doesn't exist.")
        if (dst.exists()) return@withContext ToolResult(false, "'$to' already exists.")
        if (src.renameTo(dst)) ToolResult(true, "Renamed $from to $to.") else ToolResult(false, "Rename failed.")
    }
}

object DeleteFile : Tool {
    override val name = "delete_file"
    override val description = "Delete a file from Nexus's folder (name)"
    override val args = setOf("name")
    override val required = setOf("name")
    override val sensitive = true
    override fun describe(a: Map<String, String>) = "Delete the file '${a["name"]}' from Nexus's folder?"
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
        val n = a.getValue("name").trim()
        if (!fileNameRule.matches(n)) return@withContext ToolResult(false, "Invalid file name.")
        val f = File(ctx.nexusDir(), n)
        if (!f.exists()) return@withContext ToolResult(false, "'$n' doesn't exist.")
        if (f.delete()) ToolResult(true, "Deleted $n.") else ToolResult(false, "Couldn't delete $n.")
    }
}

object DeviceInfo : Tool {
    override val name = "device_info"
    override val description = "Report basic device info"
    override val args = emptySet<String>()
    override suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult =
        ToolResult(true, "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}).")
}
