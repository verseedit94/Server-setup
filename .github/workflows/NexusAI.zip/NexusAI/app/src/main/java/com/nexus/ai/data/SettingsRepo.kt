package com.nexus.ai.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class NexusSettings(
    val provider: String = "gemini",              // "gemini" | "openrouter"
    val geminiModel: String = "gemini-2.0-flash",
    val openRouterModel: String = "openai/gpt-4o-mini",
    val groqModel: String = "llama-3.3-70b-versatile",
    val openRouterBase: String = "https://openrouter.ai/api/v1",
    val language: String = "en-IN",               // also used for Hinglish
    val rate: Float = 1.0f,
    val pitch: Float = 0.9f,
    val voiceName: String = "",
    val memoryEnabled: Boolean = true,
    val animations: Boolean = true,
    val speakReplies: Boolean = true,
    val wakeWord: String = "hey nexus"
)

private val Context.nexusStore by preferencesDataStore(name = "nexus_settings")

class SettingsRepo(private val ctx: Context) {
    val flow: Flow<NexusSettings> = ctx.nexusStore.data.map { p ->
        val d = NexusSettings()
        NexusSettings(
            provider = p[PROVIDER] ?: d.provider,
            geminiModel = p[GEMINI_MODEL] ?: d.geminiModel,
            openRouterModel = p[OR_MODEL] ?: d.openRouterModel,
            groqModel = p[GROQ_MODEL] ?: d.groqModel,
            openRouterBase = p[OR_BASE] ?: d.openRouterBase,
            language = p[LANG] ?: d.language,
            rate = p[RATE] ?: d.rate,
            pitch = p[PITCH] ?: d.pitch,
            voiceName = p[VOICE] ?: d.voiceName,
            memoryEnabled = p[MEMORY] ?: d.memoryEnabled,
            animations = p[ANIM] ?: d.animations,
            speakReplies = p[SPEAK] ?: d.speakReplies,
            wakeWord = p[WAKE] ?: d.wakeWord
        )
    }

    suspend fun save(s: NexusSettings) {
        ctx.nexusStore.edit { p ->
            p[PROVIDER] = s.provider
            p[GEMINI_MODEL] = s.geminiModel.trim()
            p[OR_MODEL] = s.openRouterModel.trim()
            p[GROQ_MODEL] = s.groqModel.trim()
            p[OR_BASE] = s.openRouterBase.trim()
            p[LANG] = s.language
            p[RATE] = s.rate
            p[PITCH] = s.pitch
            p[VOICE] = s.voiceName
            p[MEMORY] = s.memoryEnabled
            p[ANIM] = s.animations
            p[SPEAK] = s.speakReplies
            p[WAKE] = s.wakeWord.trim().ifBlank { "hey nexus" }
        }
    }

    private companion object {
        val PROVIDER = stringPreferencesKey("provider")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val OR_MODEL = stringPreferencesKey("or_model")
        val GROQ_MODEL = stringPreferencesKey("groq_model")
        val OR_BASE = stringPreferencesKey("or_base")
        val LANG = stringPreferencesKey("language")
        val RATE = floatPreferencesKey("rate")
        val PITCH = floatPreferencesKey("pitch")
        val VOICE = stringPreferencesKey("voice")
        val MEMORY = booleanPreferencesKey("memory")
        val ANIM = booleanPreferencesKey("anim")
        val SPEAK = booleanPreferencesKey("speak")
        val WAKE = stringPreferencesKey("wake_word")
    }
}
