package com.nexus.ai.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.google.mlkit.vision.common.InputImage
import com.nexus.ai.screenreader.ImageUtil
import com.nexus.ai.screenreader.ScreenCaptureService
import java.io.IOException

private val Grey = Color(0xFF94A3B8)

/** Runs [action] after asking for the notification permission (Android 13+). The answer doesn't block the action. */
@Composable
fun rememberNotifGate(): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.invoke(); pending = null
    }
    return { action ->
        if (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) action()
        else { pending = action; launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }
    }
}

// ---------------- Tools ----------------
@Composable
fun ToolsScreen(vm: NexusViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val gate = rememberNotifGate()
    val capOn by ScreenCaptureService.active.collectAsStateWithLifecycle()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.loadImage(uri) }
    val mpm = remember { ctx.getSystemService(MediaProjectionManager::class.java) }
    val capLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null) ScreenCaptureService.start(ctx, r.resultCode, d)
        else vm.showError("Screen capture permission was not granted.")
    }

    ScreenFrame("Tools", nav) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Section("Look at something") {
                Text("Take a photo or pick an image/screenshot. You see a preview first; nothing is uploaded until you choose \"Ask AI\". Local OCR reads English and Hindi on-device.", fontSize = 12.sp, color = Grey)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { nav.navigate("camera") }) { Text("Camera") }
                    OutlinedButton(onClick = { pick.launch("image/*") }) { Text("Pick image") }
                }
            }
            Section("Live screen reading") {
                Text(
                    if (capOn) "Session ACTIVE: Nexus can capture one frame when you ask. A notification and Android's own indicator are shown."
                    else "Off. Starting shows Android's consent dialog. Secure/protected screens (banking, DRM) appear black and cannot be read.",
                    fontSize = 12.sp, color = if (capOn) Color(0xFFEF4444) else Grey
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!capOn) Button(onClick = { gate { capLauncher.launch(mpm.createScreenCaptureIntent()) } }) { Text("Start session") }
                    else {
                        Button(onClick = { vm.captureScreenDelayed(5); nav.popBackStack() }) { Text("Capture in 5s") }
                        OutlinedButton(onClick = { ScreenCaptureService.stop(ctx) }) { Text("Stop session") }
                    }
                }
                Text("After tapping Capture, switch to the screen you want read, wait, then come back to Nexus to review the image.", fontSize = 11.sp, color = Grey)
            }
            Section("Phone actions Nexus can run") {
                vm.tools.forEach { t ->
                    Column {
                        Text(t.name + if (t.sensitive) "  (asks to confirm)" else "", color = Cyan, fontSize = 13.sp)
                        Text(t.description, fontSize = 12.sp)
                        Text("Needs: ${t.permissionNote}", fontSize = 11.sp, color = Grey)
                    }
                }
            }
        }
    }
}

// ---------------- Camera (CameraX) ----------------
@Composable
fun CameraScreen(vm: NexusViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val owner = ctx as ComponentActivity
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }

    ScreenFrame("Camera", nav) {
        if (!granted) {
            Text("Camera permission is needed to show the viewfinder. The camera is only on while this screen is open, and nothing is recorded or uploaded.", color = Grey)
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }, modifier = Modifier.padding(top = 12.dp)) { Text("Allow camera") }
        } else {
            val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build() }
            AndroidView(
                factory = { c ->
                    val pv = PreviewView(c)
                    val future = ProcessCameraProvider.getInstance(c)
                    future.addListener({
                        try {
                            val provider = future.get()
                            val preview = Preview.Builder().build()
                            preview.setSurfaceProvider(pv.surfaceProvider)
                            provider.unbindAll()
                            provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                        } catch (e: Exception) {
                            vm.showError("Camera unavailable on this device.")
                        }
                    }, ContextCompat.getMainExecutor(c))
                    pv
                },
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
            DisposableEffect(Unit) {
                onDispose { try { ProcessCameraProvider.getInstance(ctx).get().unbindAll() } catch (e: Exception) { } }
            }
            Text("You'll see a preview and decide before anything is sent.", fontSize = 12.sp, color = Grey, modifier = Modifier.padding(vertical = 6.dp))
            Button(
                onClick = {
                    imageCapture.takePicture(ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val rot = image.imageInfo.rotationDegrees
                            val raw = image.toBitmap()
                            image.close()
                            val bmp: Bitmap = if (rot != 0) Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(rot.toFloat()) }, true) else raw
                            vm.pendingImage.value = ImageUtil.scale(bmp, 2048)
                            nav.navigate("vision") { popUpTo("camera") { inclusive = true } }
                        }
                        override fun onError(exception: ImageCaptureException) { vm.showError("Capture failed.") }
                    })
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) { Text("Capture") }
        }
    }
}

// ---------------- Vision (preview + consent) ----------------
@Composable
fun VisionScreen(vm: NexusViewModel, nav: NavHostController) {
    val bmp by vm.pendingImage.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val clip = LocalClipboardManager.current
    var q by remember { mutableStateOf("What is shown here? Read any text and explain any error.") }
    val model = when (s.provider) { "gemini" -> s.geminiModel; "groq" -> s.groqModel; else -> s.openRouterModel }
    val hasKey = when (s.provider) { "gemini" -> ui.hasGeminiKey; "groq" -> ui.hasGroqKey; else -> ui.hasOpenRouterKey }

    ScreenFrame("Image", nav) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            val b = bmp
            if (b == null) {
                Text("No image selected.", color = Grey)
            } else {
                Image(b.asImageBitmap(), "Preview", Modifier.fillMaxWidth().heightIn(max = 320.dp), contentScale = ContentScale.Fit)
                Text(
                    "Preview only. Nothing leaves your phone unless you tap \"Ask AI\", which uploads this image to ${s.provider} ($model). \"Read text\" runs fully on-device.",
                    fontSize = 12.sp, color = Grey, modifier = Modifier.padding(vertical = 8.dp)
                )
                OutlinedTextField(q, { q = it }, label = { Text("Question") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    Button(enabled = hasKey, onClick = { vm.askAboutImage(b, q); nav.popBackStack("home", false) }) { Text("Ask AI (uploads)") }
                    OutlinedButton(onClick = { vm.analyzeImage(InputImage.fromBitmap(b, 0)) }) { Text("Read text (local)") }
                }
                if (!hasKey) Text("Add an API key in Settings to use a vision model. Use a vision-capable model name (e.g. Gemini Flash, or a vision model on OpenRouter).", fontSize = 11.sp, color = Grey)
                if (ui.ocrText.isNotBlank()) {
                    SelectionContainer { Text(ui.ocrText, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { clip.setText(AnnotatedString(ui.ocrText)) }) { Text("Copy") }
                        Button(enabled = hasKey, onClick = { vm.explainOcr(); nav.popBackStack("home", false) }) { Text("Explain text with AI") }
                    }
                    Text("\"Explain text\" sends only the extracted text, not the image.", fontSize = 11.sp, color = Grey)
                }
                OutlinedButton(onClick = { vm.pendingImage.value = null; nav.popBackStack() }, modifier = Modifier.padding(top = 8.dp)) { Text("Discard image") }
            }
        }
    }
}

// ---------------- Sandboxed HTML preview ----------------
@Composable
fun PreviewScreen(vm: NexusViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val html by vm.previewHtml.collectAsStateWithLifecycle()
    var js by remember { mutableStateOf(false) }
    var net by remember { mutableStateOf(false) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
        if (uri != null) {
            try { ctx.contentResolver.openOutputStream(uri)?.use { it.write(html.toByteArray()) } }
            catch (e: IOException) { vm.showError("Couldn't save the file.") }
        }
    }
    ScreenFrame("HTML preview (sandboxed)", nav) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("JavaScript", Modifier.weight(1f)); Switch(js, { js = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Allow network (CDNs, images)", Modifier.weight(1f)); Switch(net, { net = it })
        }
        Text("Runs in an isolated WebView: no file or content access, links are blocked, and JavaScript/network are off unless you enable them.", fontSize = 11.sp, color = Grey)
        AndroidView(
            factory = { c ->
                WebView(c).apply {
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
                    }
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                }
            },
            update = { w ->
                w.settings.javaScriptEnabled = js
                w.settings.blockNetworkLoads = !net
                w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
            },
            modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)
        )
        Button(onClick = { save.launch("nexus-page.html") }, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) { Text("Save HTML to a location you choose") }
    }
}
