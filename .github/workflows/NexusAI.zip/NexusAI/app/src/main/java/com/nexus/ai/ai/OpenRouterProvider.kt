package com.nexus.ai.ai

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Works with OpenRouter and with any OpenAI-compatible HTTPS endpoint (e.g. the bundled backend proxy). */
class OpenRouterProvider(
    private val apiKey: String,
    private val model: String,
    private val baseUrl: String,
    /** true = OpenRouter (":online" web plugin + X-Title header). false = plain OpenAI-compatible (e.g. Groq). */
    private val openRouterStyle: Boolean = true
) : AiProvider {
    override val id = "openrouter"

    override fun stream(messages: List<ChatMsg>, system: String, research: Boolean, onSources: (List<Source>) -> Unit): Flow<String> {
        if (!baseUrl.startsWith("https://")) {
            return flow { throw AiException("The base URL must use HTTPS.") }
        }
        val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        for (m in messages) {
            val o = JSONObject().put("role", m.role)
            if (m.imageB64 != null) {
                val content = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", m.content))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64," + m.imageB64)))
                o.put("content", content)
            } else {
                o.put("content", m.content)
            }
            arr.put(o)
        }
        // OpenRouter's ":online" suffix enables its web-search plugin and returns url_citation annotations.
        val effectiveModel = if (research && openRouterStyle && !model.endsWith(":online")) "$model:online" else model
        val body = JSONObject().put("model", effectiveModel).put("stream", true).put("messages", arr)

        return Http.sseFlow(
            build = {
                Request.Builder()
                    .url(baseUrl.trimEnd('/') + "/chat/completions")
                    .header("Authorization", "Bearer $apiKey")
                    .apply { if (openRouterStyle) header("X-Title", "Nexus AI") }
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
            },
            extract = { data ->
                val delta = JSONObject(data).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")
                val ann = delta?.optJSONArray("annotations")
                if (ann != null) {
                    val found = mutableListOf<Source>()
                    for (i in 0 until ann.length()) {
                        val c = ann.optJSONObject(i)?.optJSONObject("url_citation") ?: continue
                        val u = c.optString("url")
                        if (u.isNotBlank()) found.add(Source(c.optString("title").ifBlank { u }, u))
                    }
                    if (found.isNotEmpty()) onSources(found)
                }
                delta?.optString("content")?.takeIf { it != "null" }
            }
        )
    }
}
