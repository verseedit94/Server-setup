package com.nexus.ai.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val updatedAt: Long,
    val summary: String = ""
)

@Entity(tableName = "messages", indices = [Index("conversationId")])
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val role: String,
    val content: String,
    val createdAt: Long
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long
)

@Dao
interface ChatDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun conversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    suspend fun conversationsOnce(): List<ConversationEntity>

    @Query(
        "SELECT DISTINCT c.* FROM conversations c LEFT JOIN messages m ON m.conversationId = c.id " +
            "WHERE c.title LIKE '%' || :q || '%' OR m.content LIKE '%' || :q || '%' ORDER BY c.updatedAt DESC"
    )
    fun search(q: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun conversation(id: String): ConversationEntity?

    @Query("SELECT * FROM messages WHERE conversationId = :id ORDER BY createdAt, id")
    suspend fun messages(id: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: ConversationEntity)

    @Insert
    suspend fun insert(m: MessageEntity): Long

    @Query("UPDATE conversations SET summary = :s WHERE id = :id")
    suspend fun setSummary(id: String, s: String)

    @Query("SELECT summary FROM conversations WHERE id = :id")
    suspend fun summary(id: String): String?

    @Query(
        "DELETE FROM messages WHERE id = (SELECT id FROM messages WHERE conversationId = :id " +
            "AND role = 'assistant' ORDER BY createdAt DESC, id DESC LIMIT 1)"
    )
    suspend fun deleteLastAssistant(id: String)

    @Query("DELETE FROM messages WHERE conversationId = :id")
    suspend fun deleteMessages(id: String)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM messages")
    suspend fun clearMessages()

    @Query("DELETE FROM conversations")
    suspend fun clearConversations()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    fun all(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY createdAt DESC")
    suspend fun snapshot(): List<MemoryEntity>

    @Insert
    suspend fun insert(m: MemoryEntity): Long

    @Update
    suspend fun update(m: MemoryEntity)

    @Delete
    suspend fun delete(m: MemoryEntity)

    @Query("DELETE FROM memories")
    suspend fun clear()
}

@Database(entities = [ConversationEntity::class, MessageEntity::class, MemoryEntity::class], version = 1, exportSchema = false)
abstract class NexusDb : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun memoryDao(): MemoryDao
}
