package com.nexus.ai.ui

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.graphics.Bitmap
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.nexus.ai.ai.Source
import com.nexus.ai.screenreader.ImageUtil
import com.nexus.ai.screenreader.ScreenCaptureService
import com.nexus.ai.voice.WakeWordBus
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.util.concurrent.CopyOnWriteArrayList
import com.nexus.ai.NexusApp
import com.nexus.ai.ai.AiException
import com.nexus.ai.ai.AiProvider
import com.nexus.ai.ai.ChatMsg
import com.nexus.ai.ai.GeminiProvider
import com.nexus.ai.ai.OpenRouterProvider
import com.nexus.ai.automation.ActionParser
import com.nexus.ai.automation.ActionRequest
import com.nexus.ai.automation.Tool
import com.nexus.ai.automation.ToolResult
import com.nexus.ai.automation.Validation
import com.nexus.ai.core.ActivityState
import com.nexus.ai.data.ConversationEntity
import com.nexus.ai.data.MemoryEntity
import com.nexus.ai.data.MessageEntity
import com.nexus.ai.data.NexusSettings
import com.nexus.ai.memory.MemoryGuard
import com.nexus.ai.screenreader.OcrEngine
import com.nexus.ai.voice.Speech
import com.nexus.ai.voice.VoiceManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class UiMessage(
    val id: Long,
    val role: String,
    val content: String,
    val streaming: Boolean = false,
    val sources: List<Source> = emptyList()
)
data class PendingAction(val request: ActionRequest, val description: String)

data class UiState(
    val activity: ActivityState = ActivityState.IDLE,
    val detail: String = "",
    val partial: String = "",
    val battery: Int = -1,
    val online: Boolean = true,
    val voiceMode: Boolean = false,
    val pending: PendingAction? = null,
    val pendingMemory: String? = null,
    val hasGeminiKey: Boolean = false,
    val hasOpenRouterKey: Boolean = false,
    val hasGroqKey: Boolean = false,
    val ocrText: String = "",
    val researchMode: Boolean = false
)

private const val BASE_PROMPT =
    "You are NEXUS, a concise, helpful voice assistant on an Android phone. " +
        "Reply in the user's language (English, Hindi or Hinglish). Keep answers short enough to be spoken. " +
        "You have NO live internet access and cannot see the screen unless text is provided; never claim otherwise. " +
        "If the user clearly asks you to perform one of the phone actions listed below, reply with ONLY a JSON object " +
        "like {\"action\":\"open_app\",\"args\":{\"app\":\"YouTube\"}} and nothing else. Otherwise answer normally."

private const val SUMMARY_PROMPT =
    "Summarize the conversation in under 120 words. Keep facts, decisions and open tasks. Plain text only."

private const val RESEARCH_PROMPT =
    "Web research mode: use web search for current information. Structure the answer in two parts: " +
        "'From the web:' (facts found in search results) and 'My explanation:' (your own reasoning, clearly labelled as such). " +
        "If you could not find a reliable source for something, say so."

private val screenRegex = Regex(
    "^(?:nexus[,:]?\\s*)?(?:read|explain|analy[sz]e|scan)\\s+(?:the\\s+error\\s+on\\s+)?(?:the\\s+|my\\s+|this\\s+)?screen\\b",
    RegexOption.IGNORE_CASE
)

private fun sourcesText(l: List<Source>): String =
    if (l.isEmpty()) "" else "\n\nSources:\n" + l.joinToString("\n") { "- ${it.title}: ${it.url}" }

class NexusViewModel(app: Application) : AndroidViewModel(app) {
    private val c = (app as NexusApp).container
    private val chatDao = c.db.chatDao()
    private val memDao = c.db.memoryDao()

    val voice = VoiceManager(app)
    val tools get() = c.tools.all
    val settings: StateFlow<NexusSettings> = c.settings.flow.stateIn(viewModelScope, SharingStarted.Eagerly, NexusSettings())

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()
    private val _messages = MutableStateFlow<List<UiMessage>>(emptyList())
    val messages: StateFlow<List<UiMessage>> = _messages.asStateFlow()

    val memories: StateFlow<List<MemoryEntity>> =
        memDao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val historyQuery = MutableStateFlow("")

    /** Image waiting for the user's decision on the Vision screen (camera, gallery or screen capture). */
    val pendingImage = MutableStateFlow<Bitmap?>(null)
    val previewHtml = MutableStateFlow("")
    private val _navEvents = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val navEvents: SharedFlow<String> = _navEvents.asSharedFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val conversations: StateFlow<List<ConversationEntity>> = historyQuery
        .flatMapLatest { q -> if (q.isBlank()) chatDao.conversations() else chatDao.search(q.trim()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var conversationId = UUID.randomUUID().toString()
    private var nextId = 1L
    private var summarizedUpTo = 0
    private var job: Job? = null

    init {
        voice.onResult = { text -> _ui.update { it.copy(partial = "") }; send(text) }
        voice.onEnd = { setActivity(ActivityState.PROCESSING_AUDIO, "Processing audio") }
        voice.onFailure = { msg ->
            _ui.update { it.copy(voiceMode = false, partial = "") }
            if (msg.isBlank()) setActivity(ActivityState.IDLE, "Didn't catch that") else showError(msg)
        }
        voice.onSpoken = {
            setActivity(ActivityState.IDLE)
            if (_ui.value.voiceMode) beginListening()
        }
        voice.init()
        viewModelScope.launch { voice.partial.collect { p -> _ui.update { it.copy(partial = p) } } }
        // Wake word: the service emits an event; also pause it while the app itself uses the microphone.
        viewModelScope.launch { WakeWordBus.events.collect { wakeTriggered() } }
        viewModelScope.launch {
            _ui.map { Pair(it.activity, it.voiceMode) }.distinctUntilChanged().collect { (a, vm) ->
                WakeWordBus.paused.value = vm || (a != ActivityState.IDLE && a != ActivityState.ERROR && a != ActivityState.OFFLINE)
            }
        }
        refreshKeys()
        viewModelScope.launch {
            while (isActive) {
                _ui.update { it.copy(battery = readBattery(), online = isOnline()) }
                delay(15_000)
            }
        }
    }

    // ---------- state helpers ----------
    private fun setActivity(a: ActivityState, detail: String = "") {
        _ui.update { it.copy(activity = a, detail = detail) }
    }

    fun showError(msg: String) {
        addMessage("error", msg)
        setActivity(ActivityState.ERROR, msg)
        viewModelScope.launch {
            delay(5000)
            if (_ui.value.activity == ActivityState.ERROR) setActivity(ActivityState.IDLE)
        }
    }

    private fun addMessage(role: String, content: String, streaming: Boolean = false): Long {
        val id = nextId++
        _messages.update { it + UiMessage(id, role, content, streaming) }
        return id
    }

    private fun updateMessage(id: Long, content: String, streaming: Boolean, sources: List<Source>? = null) {
        _messages.update { list ->
            list.map { if (it.id == id) it.copy(content = content, streaming = streaming, sources = sources ?: it.sources) else it }
        }
    }

    private fun removeMessage(id: Long) { _messages.update { list -> list.filter { it.id != id } } }

    private fun refreshKeys() {
        _ui.update { it.copy(hasGeminiKey = c.secure.has(KEY_GEMINI), hasOpenRouterKey = c.secure.has(KEY_OR), hasGroqKey = c.secure.has(KEY_GROQ)) }
    }

    private fun readBattery(): Int =
        getApplication<Application>().getSystemService(BatteryManager::class.java)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    private fun isOnline(): Boolean {
        val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ---------- settings / keys ----------
    fun saveSettings(s: NexusSettings) { viewModelScope.launch { c.settings.save(s) } }

    fun saveKey(provider: String, key: String) {
        c.secure.put(when (provider) { "openrouter" -> KEY_OR; "groq" -> KEY_GROQ; else -> KEY_GEMINI }, key.trim())
        refreshKeys()
    }

    private fun provider(s: NexusSettings): AiProvider? = when (s.provider) {
        "groq" -> c.secure.get(KEY_GROQ)?.takeIf { it.isNotBlank() }?.let { OpenRouterProvider(it, s.groqModel, "https://api.groq.com/openai/v1", openRouterStyle = false) }
        "openrouter" -> c.secure.get(KEY_OR)?.takeIf { it.isNotBlank() }?.let { OpenRouterProvider(it, s.openRouterModel, s.openRouterBase) }
        else -> c.secure.get(KEY_GEMINI)?.takeIf { it.isNotBlank() }?.let { GeminiProvider(it, s.geminiModel) }
    }

    // ---------- sending ----------
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        voice.stopSpeaking(); voice.stopListening(); job?.cancel()
        addMessage("user", t)
        job = viewModelScope.launch {
            persist("user", t)

            val fact = MemoryGuard.candidate(t)
            if (fact != null) {
                if (!settings.value.memoryEnabled) { reply("Memory is switched off in Settings."); return@launch }
                if (MemoryGuard.isSensitive(fact)) { reply("I won't store that as a memory because it looks sensitive (passwords, PINs, tokens, card numbers)."); return@launch }
                _ui.update { it.copy(pendingMemory = fact) }
                reply("Do you want me to save this to memory? Please approve or decline.")
                return@launch
            }

            if (screenRegex.containsMatchIn(t)) { captureScreenDelayed(3); return@launch }
            if (ActionParser.researchQuery(t) != null) { askAi(research = true); return@launch }
            val local = ActionParser.parse(t)
            if (local != null) { handleAction(local); return@launch }
            askAi()
        }
    }

    private suspend fun askAi(research: Boolean = _ui.value.researchMode, image: String? = null) {
        if (research && settings.value.provider == "groq") {
            addMessage("assistant", "Groq has no web search in Nexus, so I'll answer without it. Use Gemini or OpenRouter for web research with sources.")
            askAi(research = false, image = image)
            return
        }
        val s = settings.value
        val p = provider(s)
        if (p == null) { showError("No API key set for ${s.provider}. Open Settings > AI provider to add one."); return }
        if (!isOnline()) { setActivity(ActivityState.OFFLINE, "No internet"); showError("You're offline. Local phone actions still work."); return }

        setActivity(
            if (research) ActivityState.SEARCHING_WEB else ActivityState.THINKING,
            if (research) "Searching the web via ${s.provider}" else "Asking ${s.provider}"
        )
        val history = _messages.value.filter { it.role == "user" || it.role == "assistant" }
            .takeLast(20).dropWhile { it.role == "assistant" }.map { ChatMsg(it.role, it.content) }
            .let { h -> if (image != null && h.isNotEmpty()) h.dropLast(1) + h.last().copy(imageB64 = image) else h }
        val system = systemPrompt() + if (research) "\n" + RESEARCH_PROMPT else ""
        val found = CopyOnWriteArrayList<Source>()
        val id = addMessage("assistant", "", streaming = true)
        val sb = StringBuilder()
        try {
            p.stream(history, system, research, onSources = { list ->
                list.forEach { src -> if (found.none { it.url == src.url }) found.add(src) }
            }).collect { chunk ->
                sb.append(chunk)
                updateMessage(id, sb.toString(), true, found.toList())
            }
        } catch (e: CancellationException) {
            if (sb.isEmpty()) removeMessage(id) else updateMessage(id, sb.toString(), false)
            setActivity(ActivityState.IDLE)
            throw e
        } catch (e: AiException) {
            removeMessage(id); showError(e.message ?: "AI request failed."); return
        } catch (e: Exception) {
            removeMessage(id); showError("Unexpected error: ${e.javaClass.simpleName}"); return
        }

        val full = sb.toString().trim()
        val action = if (research || image != null) null else ActionParser.parseAiJson(full)
        if (action != null) { removeMessage(id); handleAction(action); return }
        val srcs = found.toList()
        val shown = if (research && srcs.isEmpty()) full + "\n\n(No web sources were returned, so treat this as unverified.)" else full
        updateMessage(id, shown, false, srcs)
        persist("assistant", shown + sourcesText(srcs))
        speak(full)
        maybeSummarize(p)
    }

    private suspend fun systemPrompt(): String {
        val s = settings.value
        val sb = StringBuilder(BASE_PROMPT).append("\n").append(c.tools.promptDescription())
        if (s.memoryEnabled) {
            val mems = memDao.snapshot().take(30)
            if (mems.isNotEmpty()) sb.append("\nUser-approved memories:\n").append(mems.joinToString("\n") { "- " + it.text })
            val sum = chatDao.summary(conversationId)
            if (!sum.isNullOrBlank()) sb.append("\nEarlier in this conversation:\n").append(sum)
        }
        return sb.toString()
    }

    private suspend fun maybeSummarize(p: AiProvider) {
        val msgs = _messages.value.filter { it.role == "user" || it.role == "assistant" }
        if (!settings.value.memoryEnabled || msgs.size - summarizedUpTo < 24) return
        val text = msgs.dropLast(10).joinToString("\n") { "${it.role}: ${it.content.take(500)}" }
        val sb = StringBuilder()
        try { p.stream(listOf(ChatMsg("user", text)), SUMMARY_PROMPT).collect { sb.append(it) } } catch (e: AiException) { return }
        if (sb.isNotBlank()) { chatDao.setSummary(conversationId, sb.toString().trim()); summarizedUpTo = msgs.size }
    }

    private suspend fun persist(role: String, content: String) {
        if (!settings.value.memoryEnabled) return
        val now = System.currentTimeMillis()
        val existing = chatDao.conversation(conversationId)
        chatDao.upsert(ConversationEntity(conversationId, existing?.title ?: content.take(40), now, existing?.summary ?: ""))
        chatDao.insert(MessageEntity(conversationId = conversationId, role = role, content = content, createdAt = now))
    }

    // ---------- actions ----------
    private suspend fun handleAction(req: ActionRequest) {
        when (val v = c.tools.validate(req)) {
            is Validation.Invalid -> reply("I can't do that: ${v.reason}.")
            is Validation.Valid -> {
                if (v.tool.sensitive) {
                    _ui.update { it.copy(pending = PendingAction(req, v.tool.describe(req.args))) }
                    reply("This needs your confirmation first.")
                } else runTool(v.tool, req)
            }
        }
    }

    private suspend fun runTool(tool: Tool, req: ActionRequest) {
        setActivity(ActivityState.EXECUTING, tool.name)
        val result: ToolResult = withContext(Dispatchers.Main) {
            try { tool.execute(getApplication(), req.args) } catch (e: Exception) { ToolResult(false, "Action failed: ${e.javaClass.simpleName}") }
        }
        reply(result.message, isError = !result.ok)
    }

    fun resolvePending(approve: Boolean) {
        val p = _ui.value.pending ?: return
        _ui.update { it.copy(pending = null) }
        viewModelScope.launch {
            if (!approve) { reply("Cancelled."); return@launch }
            val tool = c.tools.get(p.request.name) ?: return@launch
            runTool(tool, p.request)
        }
    }

    private suspend fun reply(text: String, isError: Boolean = false) {
        if (isError) { showError(text); return }
        addMessage("assistant", text)
        persist("assistant", text)
        speak(text)
    }

    // ---------- voice ----------
    private fun speak(text: String) {
        val s = settings.value
        if (s.speakReplies && voice.ttsReady) {
            setActivity(ActivityState.SPEAKING, "Speaking")
            voice.speak(Speech.clean(text), s)
        } else {
            setActivity(ActivityState.IDLE)
            if (_ui.value.voiceMode) beginListening()
        }
    }

    fun speakMessage(text: String) {
        if (!voice.ttsReady) { showError("The text-to-speech engine isn't ready on this device."); return }
        voice.stopListening()
        setActivity(ActivityState.SPEAKING, "Speaking")
        voice.speak(Speech.clean(text), settings.value)
    }

    private fun beginListening() {
        voice.stopSpeaking()
        setActivity(ActivityState.LISTENING, "Listening")
        voice.startListening(settings.value.language)
    }

    fun toggleMic() {
        if (_ui.value.activity == ActivityState.LISTENING) { voice.stopListening(); setActivity(ActivityState.IDLE) }
        else { job?.cancel(); beginListening() }   // tapping while speaking interrupts the assistant
    }

    fun toggleVoiceMode() {
        if (_ui.value.voiceMode) cancelAll()
        else { _ui.update { it.copy(voiceMode = true) }; job?.cancel(); beginListening() }
    }

    fun cancelAll() {
        job?.cancel()
        voice.stopListening(); voice.stopSpeaking()
        _ui.update { it.copy(voiceMode = false, partial = "") }
        setActivity(ActivityState.IDLE)
    }

    // ---------- conversations ----------
    fun newConversation() {
        cancelAll()
        conversationId = UUID.randomUUID().toString()
        summarizedUpTo = 0
        _messages.value = emptyList()
    }

    fun openConversation(id: String) {
        cancelAll()
        viewModelScope.launch {
            val ms = chatDao.messages(id)
            conversationId = id
            summarizedUpTo = 0
            _messages.value = ms.map { UiMessage(nextId++, it.role, it.content) }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            chatDao.deleteMessages(id); chatDao.deleteConversation(id)
            if (id == conversationId) { _messages.value = emptyList(); conversationId = UUID.randomUUID().toString() }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch { chatDao.clearMessages(); chatDao.clearConversations() }
        newConversation()
    }

    fun regenerate() {
        val last = _messages.value.lastOrNull() ?: return
        if (last.role != "assistant" && last.role != "error") return
        job?.cancel()
        _messages.update { it.dropLast(1) }
        job = viewModelScope.launch {
            if (last.role == "assistant" && settings.value.memoryEnabled) chatDao.deleteLastAssistant(conversationId)
            askAi()
        }
    }

    // ---------- memory ----------
    fun approveMemory(approve: Boolean) {
        val fact = _ui.value.pendingMemory ?: return
        _ui.update { it.copy(pendingMemory = null) }
        if (approve) viewModelScope.launch { memDao.insert(MemoryEntity(text = fact, createdAt = System.currentTimeMillis())); reply("Saved to memory.") }
        else viewModelScope.launch { reply("Okay, I won't save it.") }
    }

    /** Returns false if the text is blank or looks sensitive. */
    fun addMemory(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || MemoryGuard.isSensitive(t)) return false
        viewModelScope.launch { memDao.insert(MemoryEntity(text = t, createdAt = System.currentTimeMillis())) }
        return true
    }

    fun updateMemory(m: MemoryEntity, text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty() || MemoryGuard.isSensitive(t)) return false
        viewModelScope.launch { memDao.update(m.copy(text = t)) }
        return true
    }

    fun deleteMemory(m: MemoryEntity) { viewModelScope.launch { memDao.delete(m) } }
    fun clearMemories() { viewModelScope.launch { memDao.clear() } }

    // ---------- OCR ----------
    fun analyzeImage(image: InputImage) {
        viewModelScope.launch {
            setActivity(ActivityState.READING_SCREEN, "Running on-device OCR")
            try {
                val t = OcrEngine.recognize(image)
                _ui.update { it.copy(ocrText = t.ifBlank { "(no text found)" }) }
                setActivity(ActivityState.IDLE)
            } catch (e: Exception) {
                showError("OCR failed: ${e.javaClass.simpleName}")
            }
        }
    }

    fun explainOcr() {
        val t = _ui.value.ocrText
        if (t.isBlank()) return
        send("Explain this text that was extracted from my screen and tell me what to do:\n\n$t")
    }

    // ---------- export ----------
    fun exportData(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val arr = JSONArray()
            for (conv in chatDao.conversationsOnce()) {
                val ms = JSONArray()
                chatDao.messages(conv.id).forEach { ms.put(JSONObject().put("role", it.role).put("content", it.content).put("at", it.createdAt)) }
                arr.put(JSONObject().put("id", conv.id).put("title", conv.title).put("summary", conv.summary).put("messages", ms))
            }
            val mem = JSONArray()
            memDao.snapshot().forEach { mem.put(it.text) }
            onReady(JSONObject().put("conversations", arr).put("memories", mem).toString(2))
        }
    }

    // ---------- web research / vision / screen / wake / preview ----------
    fun toggleResearch() { _ui.update { it.copy(researchMode = !it.researchMode) } }

    fun askAboutImage(bmp: Bitmap, question: String) {
        val q = question.trim().ifBlank { "Describe this image and read any visible text." }
        voice.stopSpeaking(); voice.stopListening(); job?.cancel()
        addMessage("user", "[Image] $q")
        pendingImage.value = null
        job = viewModelScope.launch {
            val b64 = withContext(Dispatchers.Default) { ImageUtil.toJpegBase64(bmp) }
            persist("user", "[Image] $q")
            askAi(research = false, image = b64)
        }
    }

    fun loadImage(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) { ImageUtil.decode(getApplication<Application>(), uri, 2048) }
            if (bmp == null) { showError("Couldn't open that image."); return@launch }
            pendingImage.value = bmp
            _navEvents.emit("vision")
        }
    }

    fun captureScreenDelayed(seconds: Int) {
        if (!ScreenCaptureService.active.value) {
            showError("Screen reading isn't running. Start a session in Tools first (Android will ask for your permission).")
            return
        }
        job?.cancel()
        job = viewModelScope.launch {
            for (n in seconds downTo 1) {
                setActivity(ActivityState.READING_SCREEN, "Capturing in $n s. Switch to the screen to read, then return to Nexus.")
                delay(1000)
            }
            val bmp = ScreenCaptureService.snapshot()
            if (bmp == null) { showError("No screen frame available yet. Try again."); return@launch }
            pendingImage.value = bmp
            setActivity(ActivityState.IDLE)
            _navEvents.emit("vision")
        }
    }

    fun wakeTriggered() {
        if (_ui.value.activity == ActivityState.IDLE) { job?.cancel(); beginListening() }
    }

    fun openPreview(html: String) {
        previewHtml.value = html
        viewModelScope.launch { _navEvents.emit("preview") }
    }

    override fun onCleared() {
        voice.shutdown()
        super.onCleared()
    }

    private companion object {
        const val KEY_GEMINI = "gemini_key"
        const val KEY_OR = "openrouter_key"
        const val KEY_GROQ = "groq_key"
    }
}
