package com.nexus.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.nexus.ai.data.NexusSettings
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

object Speech {
    /** Strips markdown/code so the TTS engine doesn't read symbols aloud. */
    fun clean(text: String): String = text
        .replace(Regex("```[\\s\\S]*?```"), " code block omitted. ")
        .replace(Regex("[*#`_>]"), "")
        .trim()
}

class VoiceManager(private val ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    @Volatile var ttsReady = false
        private set

    val level = MutableStateFlow(0f)          // 0..1 microphone level from the recognizer
    val partial = MutableStateFlow("")        // live transcription
    val voices = MutableStateFlow<List<String>>(emptyList())

    var onResult: (String) -> Unit = {}
    var onEnd: () -> Unit = {}
    var onFailure: (String) -> Unit = {}      // empty string = nothing heard
    var onSpoken: () -> Unit = {}

    fun init() {
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { if (utteranceId == LAST) main.post { onSpoken() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { onSpoken() } }
                })
            }
        }
    }

    fun refreshVoices(languageTag: String) {
        val engine = tts ?: return
        if (!ttsReady) return
        val lang = Locale.forLanguageTag(languageTag).language
        voices.value = (engine.voices ?: emptySet()).filter { it.locale.language == lang }.map { it.name }.sorted()
    }

    fun speak(text: String, s: NexusSettings) {
        val engine = tts
        if (engine == null || !ttsReady || text.isBlank()) { main.post { onSpoken() }; return }
        val locale = Locale.forLanguageTag(s.language)
        engine.setLanguage(locale)
        engine.setSpeechRate(s.rate)
        engine.setPitch(s.pitch)
        val all = engine.voices ?: emptySet()
        val voice = all.firstOrNull { it.name == s.voiceName }
            ?: all.firstOrNull { it.locale.language == locale.language && it.name.contains("male", true) && !it.name.contains("female", true) }
        if (voice != null) engine.voice = voice
        val chunks = text.chunked(3000)
        chunks.forEachIndexed { i, part ->
            engine.speak(part, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, if (i == chunks.lastIndex) LAST else "c$i")
        }
    }

    fun stopSpeaking() { tts?.stop() }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) { level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { level.value = 0f; onEnd() }
        override fun onError(error: Int) { level.value = 0f; partial.value = ""; onFailure(errorText(error)) }
        override fun onResults(results: Bundle?) {
            level.value = 0f
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isBlank()) onFailure("") else onResult(t)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    fun startListening(languageTag: String) {
        main.post {
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
                onFailure("Speech recognition isn't available on this device.")
                return@post
            }
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            r.setRecognitionListener(listener)
            recognizer = r
            partial.value = ""
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            }
            r.startListening(intent)
        }
    }

    fun stopListening() {
        main.post { recognizer?.cancel(); level.value = 0f; partial.value = "" }
    }

    fun shutdown() {
        main.post { recognizer?.destroy(); recognizer = null }
        tts?.stop(); tts?.shutdown(); tts = null
    }

    private fun errorText(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ""
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs a network connection on this device."
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again."
        else -> "Speech recognition error ($code)."
    }

    private companion object { const val LAST = "nexus_last" }
}
