package com.nexus.ai.automation

import android.content.Context

data class ActionRequest(val name: String, val args: Map<String, String> = emptyMap())

data class ToolResult(val ok: Boolean, val message: String)

/** One allow-listed capability. Add a new Tool + register it in DefaultTools to extend Nexus. */
interface Tool {
    val name: String
    val description: String
    val args: Set<String>
    val required: Set<String> get() = emptySet()
    /** Sensitive tools always ask the user for confirmation first. */
    val sensitive: Boolean get() = false
    val permissionNote: String get() = "No special permission"
    fun describe(a: Map<String, String>): String = "$name ${a.entries.joinToString { "${it.key}=${it.value}" }}"
    suspend fun execute(ctx: Context, a: Map<String, String>): ToolResult
}

sealed class Validation {
    data class Valid(val tool: Tool) : Validation()
    data class Invalid(val reason: String) : Validation()
}

class ToolRegistry(tools: List<Tool>) {
    private val map = tools.associateBy { it.name }
    val all: List<Tool> get() = map.values.toList()

    fun get(name: String): Tool? = map[name]

    /** Strict allow-list validation of an (AI- or parser-produced) action. */
    fun validate(r: ActionRequest): Validation {
        val t = map[r.name] ?: return Validation.Invalid("'${r.name}' is not an allowed action")
        val extra = r.args.keys - t.args
        if (extra.isNotEmpty()) return Validation.Invalid("unexpected arguments: ${extra.joinToString()}")
        val missing = t.required.filter { r.args[it].isNullOrBlank() }
        if (missing.isNotEmpty()) return Validation.Invalid("missing arguments: ${missing.joinToString()}")
        if (r.args.values.any { it.length > MAX_ARG }) return Validation.Invalid("an argument is too long")
        return Validation.Valid(t)
    }

    fun promptDescription(): String = buildString {
        append("Available phone actions (name(args) - description):\n")
        for (t in map.values) append("- ${t.name}(${t.args.joinToString()}) - ${t.description}\n")
    }

    private companion object { const val MAX_ARG = 4000 }
}
