package com.nexus.ai.screenreader

import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.nexus.ai.core.Notif
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Screen reading session. Uses Android's MediaProjection consent dialog and a visible foreground
 * notification (plus the system's own capture indicator). Protected (FLAG_SECURE) windows come out black.
 * Frames are only held in memory; a snapshot is taken when the user asks for one.
 */
class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private val lock = Any()
    private var held: Image? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    @SuppressLint("WrongConstant")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }

        Notif.channel(this, CHANNEL, "Screen reading")
        val stop = PendingIntent.getService(
            this, 2, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Nexus screen reading is ON")
            .setContentText("Your screen can be captured when you ask. Tap Stop to end.")
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        if (!Notif.startForeground(this, 12, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)) { stopSelf(); return START_NOT_STICKY }

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            val dm = resources.displayMetrics
            val s = (1280f / maxOf(dm.widthPixels, dm.heightPixels)).coerceAtMost(1f)
            val w = (dm.widthPixels * s).toInt()
            val h = (dm.heightPixels * s).toInt()
            val t = HandlerThread("nexus-capture").also { it.start() }
            val handler = Handler(t.looper)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            r.setOnImageAvailableListener({ rd ->
                val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) synchronized(lock) { held?.close(); held = img }
            }, handler)
            // Android 14 requires a callback to be registered before creating the virtual display.
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
            display = p.createVirtualDisplay("nexus-screen", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
            projection = p; reader = r; thread = t
            instance = this
            active.value = true
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun takeSnapshot(): Bitmap? = synchronized(lock) {
        val img = held ?: return null
        try {
            val plane = img.planes[0]
            val buf = plane.buffer
            buf.rewind()
            val pix = plane.pixelStride
            val rowPad = plane.rowStride - pix * img.width
            val bmp = Bitmap.createBitmap(img.width + rowPad / pix, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buf)
            Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
        } catch (e: Exception) {
            null
        }
    }

    override fun onDestroy() {
        active.value = false
        instance = null
        display?.release(); display = null
        synchronized(lock) { held?.close(); held = null }
        reader?.close(); reader = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null
        thread?.quitSafely(); thread = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "nexus_capture"
        private const val ACTION_STOP = "com.nexus.ai.STOP_CAPTURE"
        private const val EXTRA_CODE = "code"
        private const val EXTRA_DATA = "data"

        val active = MutableStateFlow(false)
        @Volatile private var instance: ScreenCaptureService? = null

        fun start(ctx: Context, resultCode: Int, data: Intent) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, ScreenCaptureService::class.java).putExtra(EXTRA_CODE, resultCode).putExtra(EXTRA_DATA, data)
            )
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, ScreenCaptureService::class.java)) }

        /** Latest frame as a Bitmap, or null if the session isn't running / no frame yet. */
        fun snapshot(): Bitmap? = instance?.takeSnapshot()
    }
}
