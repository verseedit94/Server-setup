package com.nexus.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.google.mlkit.vision.common.InputImage
import com.nexus.ai.BuildConfig
import com.nexus.ai.data.MemoryEntity
import com.nexus.ai.voice.WakeWordBus
import com.nexus.ai.voice.WakeWordService
import java.io.IOException
import java.text.DateFormat
import java.util.Date

@Composable
fun ScreenFrame(title: String, nav: NavHostController, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(NexusBg, NexusNavy)))
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Cyan) }
            Text(title, fontSize = 20.sp, color = Cyan)
        }
        content()
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Cyan, fontSize = 14.sp)
        content()
    }
}

@Composable
private fun Pick(label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text("$label: ${value.ifBlank { "(default)" }}", maxLines = 1) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o.ifBlank { "(default)" }) }, onClick = { onPick(o); open = false }) }
        }
    }
}

// ---------------- History ----------------
@Composable
fun HistoryScreen(vm: NexusViewModel, nav: NavHostController) {
    val list by vm.conversations.collectAsStateWithLifecycle()
    val q by vm.historyQuery.collectAsStateWithLifecycle()
    ScreenFrame("Conversations", nav) {
        OutlinedTextField(q, { vm.historyQuery.value = it }, label = { Text("Search conversations") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        if (list.isEmpty()) Text("Nothing saved yet. (History is only saved while Memory is on.)", color = Color(0xFF94A3B8), modifier = Modifier.padding(top = 12.dp))
        LazyColumn(Modifier.weight(1f).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { c ->
                Row(
                    Modifier.fillMaxWidth().glass().clickable { vm.openConversation(c.id); nav.popBackStack() }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(c.title.ifBlank { "Conversation" }, maxLines = 1)
                        Text(DateFormat.getDateTimeInstance().format(Date(c.updatedAt)), fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                    IconButton(onClick = { vm.deleteConversation(c.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = Danger) }
                }
            }
        }
    }
}

// ---------------- Memory ----------------
@Composable
fun MemoryScreen(vm: NexusViewModel, nav: NavHostController) {
    val mems by vm.memories.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    var newText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<MemoryEntity?>(null) }
    var editText by remember { mutableStateOf("") }

    ScreenFrame("Memory", nav) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Memory on (saves history, summaries and approved facts)", Modifier.weight(1f), fontSize = 13.sp)
            Switch(checked = s.memoryEnabled, onCheckedChange = { vm.saveSettings(s.copy(memoryEnabled = it)) })
        }
        Text("Say \"remember that ...\" in chat, or add a fact here. Passwords, PINs, tokens and card numbers are refused.", fontSize = 11.sp, color = Color(0xFF94A3B8))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            OutlinedTextField(newText, { newText = it }, Modifier.weight(1f), label = { Text("New memory") }, singleLine = true)
            Button(onClick = { note = if (vm.addMemory(newText)) "" else "Not saved: empty or looks sensitive."; if (note.isEmpty()) newText = "" }, modifier = Modifier.padding(start = 8.dp)) { Text("Add") }
        }
        if (note.isNotEmpty()) Text(note, color = Danger, fontSize = 12.sp)
        LazyColumn(Modifier.weight(1f).padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(mems, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth().glass().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(m.text, Modifier.weight(1f))
                    IconButton(onClick = { editing = m; editText = m.text }) { Icon(Icons.Filled.Edit, "Edit", tint = Cyan) }
                    IconButton(onClick = { vm.deleteMemory(m) }) { Icon(Icons.Filled.Delete, "Delete", tint = Danger) }
                }
            }
        }
        TextButton(onClick = { vm.clearMemories() }) { Text("Delete all memories", color = Danger) }
    }
    editing?.let { m ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Edit memory") },
            text = { OutlinedTextField(editText, { editText = it }) },
            confirmButton = { TextButton(onClick = { if (vm.updateMemory(m, editText)) editing = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

// ---------------- Settings ----------------
@Composable
fun SettingsScreen(vm: NexusViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val saved by vm.settings.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val voices by vm.voice.voices.collectAsStateWithLifecycle()
    var draft by remember(saved) { mutableStateOf(saved) }
    var key by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    var micGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micGranted = it }
    LaunchedEffect(draft.language) { vm.voice.refreshVoices(draft.language) }

    ScreenFrame("Settings", nav) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Section("AI provider") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pick("Provider", draft.provider, listOf("gemini", "openrouter", "groq")) { draft = draft.copy(provider = it) }
                }
                if (draft.provider == "gemini") {
                    OutlinedTextField(draft.geminiModel, { draft = draft.copy(geminiModel = it) }, label = { Text("Gemini model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                } else if (draft.provider == "groq") {
                    OutlinedTextField(draft.groqModel, { draft = draft.copy(groqModel = it) }, label = { Text("Groq model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Key from console.groq.com. Groq offers a free tier with rate limits (check current terms). No web search; image questions need a Groq vision model name.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                } else {
                    OutlinedTextField(draft.openRouterModel, { draft = draft.copy(openRouterModel = it) }, label = { Text("OpenRouter model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(draft.openRouterBase, { draft = draft.copy(openRouterBase = it) }, label = { Text("Base URL (HTTPS only)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("Use your own backend (see /backend) by setting its URL + /v1 here and your NEXUS_AUTH_TOKEN as the key.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                }
                val has = when (draft.provider) { "gemini" -> ui.hasGeminiKey; "groq" -> ui.hasGroqKey; else -> ui.hasOpenRouterKey }
                OutlinedTextField(
                    key, { key = it }, label = { Text(if (has) "API key saved - enter a new one to replace" else "API key") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.saveSettings(draft); if (key.isNotBlank()) { vm.saveKey(draft.provider, key); key = "" } }) { Text("Save") }
                    if (has) OutlinedButton(onClick = { vm.saveKey(draft.provider, "") }) { Text("Remove key") }
                }
                Text(
                    "Risk: a key typed into the app lives on this phone (encrypted with the Android Keystore) but a rooted or compromised device could still expose it. " +
                        "For stronger protection use the backend proxy so the real key never reaches the phone. Gemini offers a free tier with limits; OpenRouter has some free models; check each provider's current terms.",
                    fontSize = 11.sp, color = Color(0xFF94A3B8)
                )
            }
            Section("Voice") {
                Pick("Language", draft.language, listOf("en-IN", "hi-IN", "en-US")) { draft = draft.copy(language = it) }
                Text("Hinglish: use en-IN (Android has no dedicated Hinglish recognizer). Recognition quality depends on your phone's speech engine.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                Pick("Voice", draft.voiceName, listOf("") + voices) { draft = draft.copy(voiceName = it) }
                Text("Speed ${"%.1f".format(draft.rate)}"); Slider(draft.rate, { draft = draft.copy(rate = it) }, valueRange = 0.5f..2f)
                Text("Pitch ${"%.1f".format(draft.pitch)} (lower = deeper)"); Slider(draft.pitch, { draft = draft.copy(pitch = it) }, valueRange = 0.5f..1.5f)
                Text("A male voice is only used if your TTS engine offers one; otherwise the default voice is used. Volume follows the phone's media volume.", fontSize = 11.sp, color = Color(0xFF94A3B8))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.voice.speak("Nexus online. Systems nominal.", draft) }) { Text("Test voice") }
                    Button(onClick = { vm.saveSettings(draft) }) { Text("Save") }
                }
            }
            Section("Wake word") {
                val wakeOn by WakeWordBus.running.collectAsStateWithLifecycle()
                val gate = rememberNotifGate()
                OutlinedTextField(draft.wakeWord, { draft = draft.copy(wakeWord = it) }, label = { Text("Wake phrase") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!wakeOn) {
                        Button(onClick = {
                            vm.saveSettings(draft)
                            if (!micGranted) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            else gate { WakeWordService.start(ctx, draft.wakeWord) }
                        }) { Text("Start listening") }
                    } else {
                        OutlinedButton(onClick = { WakeWordService.stop(ctx) }) { Text("Stop listening") }
                    }
                }
                Text(if (wakeOn) "Microphone is ACTIVE (ongoing notification shown)." else "Off. Nothing is listening in the background.", fontSize = 12.sp, color = if (wakeOn) Green else Color(0xFF94A3B8))
                Text(
                    "How it works: a foreground service keeps the microphone open and checks speech for your phrase. Android only allows background microphone use with a visible notification, so it stops if you stop it or the system kills it. " +
                        "It is not a low-power wake-word chip: expect extra battery use, possible beeps, and that your phone's speech service may send audio to Google. " +
                        "When it hears you, Nexus starts listening if the app is running, otherwise a \"Nexus heard you\" notification appears to tap.",
                    fontSize = 11.sp, color = Color(0xFF94A3B8)
                )
            }
            Section("Memory & display") {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Save history & memory", Modifier.weight(1f)); Switch(draft.memoryEnabled, { draft = draft.copy(memoryEnabled = it); vm.saveSettings(draft) }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Speak replies", Modifier.weight(1f)); Switch(draft.speakReplies, { draft = draft.copy(speakReplies = it); vm.saveSettings(draft) }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Animations (turn off to save battery)", Modifier.weight(1f)); Switch(draft.animations, { draft = draft.copy(animations = it); vm.saveSettings(draft) }) }
                OutlinedButton(onClick = { nav.navigate("memory") }) { Text("Open memory manager") }
            }
            Section("Permissions") {
                Text("Microphone: ${if (micGranted) "granted" else "not granted"}  (voice input only; the orb shows LISTENING whenever it is active)")
                if (!micGranted) Button(onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Grant microphone") }
                Text("Camera/gallery use Android's own pickers, so no camera or storage permission is needed. Timers/alarms use SET_ALARM (normal permission). Each phone action lists its needs under Tools.", fontSize = 12.sp, color = Color(0xFF94A3B8))
            }
            Section("Data & privacy") {
                Button(onClick = {
                    vm.exportData { json ->
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, json)
                        ctx.startActivity(Intent.createChooser(send, "Export Nexus data").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }) { Text("Export history & memories") }
                OutlinedButton(onClick = { confirmClear = true }) { Text("Delete all conversation history", color = Danger) }
                Text(
                    "Privacy: history and memories stay on this device. Messages you send are transmitted to the AI provider you choose (Gemini or OpenRouter/your backend) over HTTPS. " +
                        "OCR runs on-device. Nexus never reads other apps, never sends messages by itself, and never logs your API key or conversations.",
                    fontSize = 12.sp
                )
            }
            Section("About") {
                Text("Nexus AI ${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
                Text("Provider: ${saved.provider}  |  Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})", fontSize = 12.sp)
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete all history?") },
            text = { Text("This permanently removes every saved conversation. Saved memories are kept.") },
            confirmButton = { TextButton(onClick = { vm.clearAllHistory(); confirmClear = false }) { Text("Delete", color = Danger) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}
