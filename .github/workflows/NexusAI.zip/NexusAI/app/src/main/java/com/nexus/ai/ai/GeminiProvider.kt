package com.nexus.ai.ai

import android.net.Uri
import kotlinx.coroutines.flow.Flow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GeminiProvider(private val apiKey: String, private val model: String) : AiProvider {
    override val id = "gemini"

    override fun stream(messages: List<ChatMsg>, system: String, research: Boolean, onSources: (List<Source>) -> Unit): Flow<String> {
        val contents = JSONArray()
        for (m in messages) {
            val parts = JSONArray().put(JSONObject().put("text", m.content))
            if (m.imageB64 != null) {
                parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", m.imageB64)))
            }
            contents.put(JSONObject().put("role", if (m.role == "assistant") "model" else "user").put("parts", parts))
        }
        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        // Google Search grounding: the model searches the live web and returns citations.
        if (research) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))

        return Http.sseFlow(
            build = {
                Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/${Uri.encode(model)}:streamGenerateContent?alt=sse")
                    .header("x-goog-api-key", apiKey)
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .build()
            },
            extract = { data ->
                val cand = JSONObject(data).optJSONArray("candidates")?.optJSONObject(0)
                val chunks = cand?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
                if (chunks != null) {
                    val found = mutableListOf<Source>()
                    for (i in 0 until chunks.length()) {
                        val w = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                        val u = w.optString("uri")
                        if (u.isNotBlank()) found.add(Source(w.optString("title").ifBlank { u }, u))
                    }
                    if (found.isNotEmpty()) onSources(found)
                }
                val parts = cand?.optJSONObject("content")?.optJSONArray("parts")
                if (parts == null) null else buildString {
                    for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text") ?: "")
                }
            }
        )
    }
}
