package com.nexus.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.ai.core.ActivityState
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.random.Random
import androidx.compose.foundation.clickable
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextDecoration

fun stateColor(s: ActivityState): Color = when (s) {
    ActivityState.LISTENING -> Cyan
    ActivityState.PROCESSING_AUDIO, ActivityState.THINKING, ActivityState.SEARCHING_WEB, ActivityState.READING_SCREEN -> Purple
    ActivityState.EXECUTING -> Blue
    ActivityState.SPEAKING -> Green
    ActivityState.ERROR -> Danger
    ActivityState.OFFLINE -> Color(0xFF64748B)
    ActivityState.IDLE -> Blue
}

/** The orb reacts to the real activity state and to the live microphone level. */
@Composable
fun NexusOrb(state: ActivityState, level: Float, animate: Boolean, modifier: Modifier = Modifier) {
    val color = stateColor(state)
    val busy = state != ActivityState.IDLE && state != ActivityState.OFFLINE
    val pulse = if (animate) {
        val t = rememberInfiniteTransition(label = "orb")
        t.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(if (busy) 1100 else 2800, easing = LinearEasing), RepeatMode.Reverse),
            label = "pulse"
        ).value
    } else 0.5f

    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val base = size.minDimension / 2 * 0.5f
        val r = base * (1f + 0.07f * pulse + 0.3f * level)
        drawCircle(
            brush = Brush.radialGradient(listOf(color.copy(alpha = 0.40f), Color.Transparent), center = c, radius = r * 2.1f),
            radius = r * 2.1f, center = c
        )
        drawCircle(
            brush = Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), color, color.copy(alpha = 0.15f)), center = c, radius = r),
            radius = r, center = c
        )
        drawCircle(color = color.copy(alpha = 0.7f), radius = r * 1.25f, center = c, style = Stroke(width = 2.dp.toPx()))
        if (busy) {
            val rr = r * 1.5f
            drawArc(
                color = color, startAngle = pulse * 360f, sweepAngle = 90f, useCenter = false,
                topLeft = Offset(c.x - rr, c.y - rr), size = Size(rr * 2, rr * 2), style = Stroke(width = 3.dp.toPx())
            )
        }
    }
}

@Composable
fun Waveform(level: Float, state: ActivityState, animate: Boolean, modifier: Modifier = Modifier) {
    val bars = remember { mutableStateListOf<Float>().apply { repeat(32) { add(0.05f) } } }
    val lv = rememberUpdatedState(level)
    LaunchedEffect(state, animate) {
        if (!animate) return@LaunchedEffect
        while (isActive) {
            val v = when (state) {
                ActivityState.LISTENING -> lv.value
                ActivityState.SPEAKING -> 0.2f + 0.6f * Random.nextFloat()
                ActivityState.THINKING, ActivityState.PROCESSING_AUDIO, ActivityState.EXECUTING, ActivityState.READING_SCREEN -> 0.1f + 0.1f * Random.nextFloat()
                else -> 0.04f
            }
            bars.removeAt(0); bars.add(v.coerceIn(0.04f, 1f))
            delay(80)
        }
    }
    val color = stateColor(state)
    Canvas(modifier) {
        val n = bars.size
        val w = size.width / n
        bars.forEachIndexed { i, v ->
            val h = size.height * v
            drawRoundRect(
                color = color.copy(alpha = 0.85f),
                topLeft = Offset(i * w + w * 0.2f, (size.height - h) / 2),
                size = Size(w * 0.6f, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.3f)
            )
        }
    }
}

@Composable
fun StatusChip(state: ActivityState, modifier: Modifier = Modifier) {
    val c = stateColor(state)
    Row(modifier.glass(RoundedCornerShape(50), c).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.layout.Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(c))
        androidx.compose.foundation.layout.Spacer(Modifier.size(8.dp))
        Text(state.label, color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

data class Block(val code: Boolean, val text: String, val lang: String = "")

fun splitBlocks(s: String): List<Block> {
    val out = mutableListOf<Block>()
    s.split("```").forEachIndexed { i, part ->
        if (i % 2 == 1) {
            val hasNl = part.contains('\n')
            out += Block(true, (if (hasNl) part.substringAfter('\n') else part).trimEnd(), if (hasNl) part.substringBefore('\n').trim() else "")
        } else if (part.isNotBlank()) out += Block(false, part.trim())
    }
    return out
}

fun mdLite(s: String): AnnotatedString = buildAnnotatedString {
    s.split("**").forEachIndexed { i, seg ->
        if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(seg) } else append(seg)
    }
}

@Composable
fun CodeBlock(code: String, lang: String, onPreview: (String) -> Unit) {
    val clip = LocalClipboardManager.current
    val isHtml = lang.equals("html", true) || code.trimStart().startsWith("<!DOCTYPE", true) || code.trimStart().startsWith("<html", true)
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF020617))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.End) {
            if (lang.isNotBlank()) Text(lang, color = Color(0xFF94A3B8), fontSize = 11.sp, modifier = Modifier.weight(1f).padding(top = 12.dp))
            if (isHtml) TextButton(onClick = { onPreview(code) }) { Text("Preview") }
            TextButton(onClick = { clip.setText(AnnotatedString(code)) }) { Text("Copy") }
        }
        Text(
            code, fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color(0xFFA5F3FC),
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(8.dp)
        )
    }
}

@Composable
fun MessageBubble(
    m: UiMessage,
    showRegenerate: Boolean,
    onSpeak: (String) -> Unit,
    onRegenerate: () -> Unit,
    onPreview: (String) -> Unit
) {
    val isUser = m.role == "user"
    val isError = m.role == "error"
    val accent = when { isUser -> Purple; isError -> Danger; else -> Cyan }
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {
        Column(Modifier.widthIn(max = 330.dp).glass(RoundedCornerShape(16.dp), accent).padding(12.dp)) {
            if (m.content.isEmpty() && m.streaming) Text("...", color = Cyan)
            splitBlocks(m.content).forEach { b ->
                if (b.code) CodeBlock(b.text, b.lang, onPreview)
                else Text(mdLite(b.text), color = if (isError) Danger else MaterialTheme.colorScheme.onSurface)
            }
            if (m.sources.isNotEmpty()) {
                Text("Sources from web search (the text above is AI-written):", fontSize = 11.sp, color = Color(0xFF94A3B8), modifier = Modifier.padding(top = 8.dp))
                m.sources.take(8).forEach { src ->
                    Text(
                        src.title.ifBlank { src.url }, color = Cyan, fontSize = 12.sp, maxLines = 1,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier.padding(top = 2.dp).clickable {
                            if (src.url.startsWith("http")) try { uri.openUri(src.url) } catch (e: Exception) { }
                        }
                    )
                }
            }
            if (!isUser && !isError && !m.streaming && m.content.isNotEmpty()) {
                Row {
                    IconButton(onClick = { onSpeak(m.content) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.VolumeUp, "Speak", tint = Cyan) }
                    if (showRegenerate) IconButton(onClick = onRegenerate, modifier = Modifier.size(32.dp)) { Icon(Icons.Filled.Refresh, "Regenerate", tint = Cyan) }
                }
            }
        }
    }
}
