package com.nexus.ai.memory

/** Decides what may become a saved memory. Memories are only saved after user approval. */
object MemoryGuard {
    private val trigger = Regex("^(?:please\\s+)?(?:remember|yaad rakh(?:o|na)?)(?:\\s+that)?\\s+(.+)", RegexOption.IGNORE_CASE)
    private val sensitive = Regex(
        "(password|passcode|\\bpin\\b|\\botp\\b|token|api[ _-]?key|secret|\\bcvv\\b|card number|\\b\\d{12,19}\\b)",
        RegexOption.IGNORE_CASE
    )

    /** Returns the fact the user asked to remember, or null when the message isn't a "remember ..." request. */
    fun candidate(message: String): String? = trigger.find(message.trim())?.groupValues?.get(1)?.trim()

    fun isSensitive(text: String): Boolean = sensitive.containsMatchIn(text)
}
