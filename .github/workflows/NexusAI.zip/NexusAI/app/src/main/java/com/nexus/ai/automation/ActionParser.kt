package com.nexus.ai.automation

import org.json.JSONException
import org.json.JSONObject

/** Offline command parser for common phone actions, plus a safe parser for AI-produced JSON actions. */
object ActionParser {
    private val words = mapOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
        "eight" to 8, "nine" to 9, "ten" to 10, "fifteen" to 15, "twenty" to 20, "thirty" to 30, "sixty" to 60
    )
    private val I = RegexOption.IGNORE_CASE
    private val prefix = Regex("^(hey\\s+)?nexus[,:]?\\s*", I)
    private val timer = Regex("timer.*?\\b(\\d+|${words.keys.joinToString("|")})\\s*(seconds?|secs?|minutes?|mins?|hours?)\\b", I)
    private val search = Regex("^(?:search(?:\\s+the)?(?:\\s+web)?(?:\\s+for)?|google|look up)\\s+(.+)$", I)
    private val createFile = Regex("^create\\s+(?:a\\s+|an\\s+)?(?:text\\s+|txt\\s+)?file(?:\\s+called|\\s+named)?\\s+([\\w.\\-]+)$", I)
    private val openEn = Regex("^(?:open|launch|start)\\s+(.+)$", I)
    private val openHi = Regex("^(.+?)\\s+(?:kholo|khol do|open karo|chalu karo)$", I)
    private val domain = Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?$")

    private val research = Regex("^(?:research|investigate|latest news (?:about|on)|news (?:about|on))\\s+(.+)$", I)

    /** "research X" / "news about X" -> X, which triggers web-grounded answering. */
    fun researchQuery(raw: String): String? {
        val t = raw.trim().replace(prefix, "").trim().trimEnd('.', '!', '?', ' ')
        return research.find(t)?.groupValues?.get(1)?.trim()
    }

    fun parse(raw: String): ActionRequest? {
        val t = raw.trim().replace(prefix, "").trim().trimEnd('.', '!', '?', ' ')
        if (t.isEmpty()) return null

        timer.find(t)?.let { m ->
            val n = m.groupValues[1].toIntOrNull() ?: words[m.groupValues[1].lowercase()] ?: return null
            val unit = m.groupValues[2].lowercase()
            val secs = when {
                unit.startsWith("h") -> n * 3600
                unit.startsWith("m") -> n * 60
                else -> n
            }
            return ActionRequest("set_timer", mapOf("seconds" to secs.toString()))
        }

        if (t.contains("volume", ignoreCase = true)) {
            val up = Regex("increase|raise|\\bup\\b|louder|badha", I).containsMatchIn(t)
            val down = Regex("decrease|lower|\\bdown\\b|reduce|\\bkam\\b|halka", I).containsMatchIn(t)
            if (up != down) return ActionRequest("volume", mapOf("direction" to if (up) "up" else "down"))
            return null
        }

        if (t.length < 40 && Regex("\\bbattery\\b", I).containsMatchIn(t)) return ActionRequest("battery_status")

        search.find(t)?.let { return ActionRequest("web_search", mapOf("query" to it.groupValues[1].trim())) }
        createFile.find(t)?.let { return ActionRequest("create_file", mapOf("name" to it.groupValues[1])) }

        val target = (openEn.find(t) ?: openHi.find(t))?.groupValues?.get(1)?.trim()
            ?.removePrefix("the ")?.removeSuffix(" app")?.trim()
        if (!target.isNullOrEmpty() && target.split(" ").size <= 3) {
            val l = target.lowercase()
            return when {
                l.contains("wifi") || l.contains("wi-fi") -> ActionRequest("open_settings", mapOf("page" to "wifi"))
                l.contains("bluetooth") -> ActionRequest("open_settings", mapOf("page" to "bluetooth"))
                l.contains("display") -> ActionRequest("open_settings", mapOf("page" to "display"))
                l.contains("sound") -> ActionRequest("open_settings", mapOf("page" to "sound"))
                l == "settings" -> ActionRequest("open_settings", mapOf("page" to "main"))
                domain.matches(target) -> ActionRequest("open_url", mapOf("url" to target))
                else -> ActionRequest("open_app", mapOf("app" to target))
            }
        }
        return null
    }

    /** Parses a reply that is exactly a JSON object like {"action":"open_app","args":{"app":"YouTube"}}. */
    fun parseAiJson(text: String): ActionRequest? {
        val s = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        if (!s.startsWith("{") || !s.endsWith("}")) return null
        return try {
            val o = JSONObject(s)
            val name = o.optString("action")
            if (name.isBlank()) return null
            val a = o.optJSONObject("args")
            val m = mutableMapOf<String, String>()
            if (a != null) for (k in a.keys()) m[k] = a.optString(k)
            ActionRequest(name, m)
        } catch (e: JSONException) {
            null
        }
    }
}
