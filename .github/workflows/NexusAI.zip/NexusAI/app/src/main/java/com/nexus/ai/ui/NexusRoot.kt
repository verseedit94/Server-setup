package com.nexus.ai.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun NexusRoot() {
    val vm: NexusViewModel = viewModel()
    val nav = rememberNavController()
    LaunchedEffect(Unit) { vm.navEvents.collect { route -> nav.navigate(route) } }
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(vm, nav) }
        composable("history") { HistoryScreen(vm, nav) }
        composable("memory") { MemoryScreen(vm, nav) }
        composable("tools") { ToolsScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("camera") { CameraScreen(vm, nav) }
        composable("vision") { VisionScreen(vm, nav) }
        composable("preview") { PreviewScreen(vm, nav) }
    }
}
