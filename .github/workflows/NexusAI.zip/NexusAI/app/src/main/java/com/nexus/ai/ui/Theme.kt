package com.nexus.ai.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

val NexusBg = Color(0xFF050A14)
val NexusNavy = Color(0xFF0B1630)
val Cyan = Color(0xFF22D3EE)
val Blue = Color(0xFF3B82F6)
val Purple = Color(0xFF8B5CF6)
val Green = Color(0xFF34D399)
val Danger = Color(0xFFEF4444)

@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, secondary = Purple, tertiary = Blue,
            background = NexusBg, surface = NexusNavy,
            onPrimary = Color.Black, onBackground = Color(0xFFE6F1FF), onSurface = Color(0xFFE6F1FF),
            error = Danger
        ),
        content = content
    )
}

/** Glassmorphism: translucent fill + glowing hairline border. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(16.dp), glow: Color = Cyan): Modifier =
    this.clip(shape)
        .background(Color.White.copy(alpha = 0.05f))
        .border(1.dp, glow.copy(alpha = 0.35f), shape)
