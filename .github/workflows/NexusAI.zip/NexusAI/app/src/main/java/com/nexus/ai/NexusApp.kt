package com.nexus.ai

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.nexus.ai.automation.DefaultTools
import com.nexus.ai.automation.ToolRegistry
import com.nexus.ai.data.NexusDb
import com.nexus.ai.data.SettingsRepo
import com.nexus.ai.security.SecureStore

class AppContainer(ctx: Context) {
    val db: NexusDb = Room.databaseBuilder(ctx, NexusDb::class.java, "nexus.db").build()
    val settings = SettingsRepo(ctx)
    val secure = SecureStore(ctx)
    val tools = ToolRegistry(DefaultTools.all())
}

class NexusApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(applicationContext)
    }
}
