package com.nexus.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.nexus.ai.core.ActivityState
import com.nexus.ai.screenreader.ScreenCaptureService
import com.nexus.ai.voice.WakeWordBus
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility

@Composable
private fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.glass(RoundedCornerShape(50)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, label, tint = Cyan, modifier = Modifier.size(18.dp))
        Spacer(Modifier.size(6.dp))
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun HomeScreen(vm: NexusViewModel, nav: NavHostController) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val level by vm.voice.level.collectAsStateWithLifecycle()
    val wakeOn by WakeWordBus.running.collectAsStateWithLifecycle()
    val capOn by ScreenCaptureService.active.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val ctx = LocalContext.current
    val listState = rememberLazyListState()
    val effective = if (!ui.online && ui.activity == ActivityState.IDLE) ActivityState.OFFLINE else ui.activity

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleMic() else vm.showError("Microphone permission denied. Enable it to use voice.")
    }
    val voiceModeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.toggleVoiceMode() else vm.showError("Microphone permission denied. Enable it to use voice.")
    }
    fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    LaunchedEffect(msgs.size, msgs.lastOrNull()?.content?.length) {
        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex)
    }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(NexusBg, NexusNavy)))
            .statusBarsPadding().navigationBarsPadding().imePadding()
            .padding(horizontal = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusChip(effective)
            if (wakeOn) Text("  MIC: WAKE", fontSize = 11.sp, color = Green)
            if (capOn) Text("  SCREEN CAPTURE ON", fontSize = 11.sp, color = Danger)
            Spacer(Modifier.weight(1f))
            Text(if (ui.online) "ONLINE" else "OFFLINE", fontSize = 11.sp, color = if (ui.online) Green else Color.Gray)
            Spacer(Modifier.size(10.dp))
            Text(if (ui.battery >= 0) "BAT ${ui.battery}%" else "BAT --", fontSize = 11.sp, color = Cyan)
        }
        if (ui.detail.isNotBlank()) Text(ui.detail, fontSize = 11.sp, color = Color(0xFF94A3B8), modifier = Modifier.padding(top = 4.dp))

        Box(Modifier.fillMaxWidth().height(190.dp), contentAlignment = Alignment.Center) {
            NexusOrb(effective, level, settings.animations, Modifier.size(190.dp))
        }
        Waveform(level, effective, settings.animations, Modifier.fillMaxWidth().height(36.dp))
        if (ui.partial.isNotBlank()) Text(ui.partial, color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 8.dp), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (msgs.isEmpty()) item {
                Text(
                    "Say \"open YouTube\", \"set a timer for ten minutes\", or ask anything. Add an API key in Settings to chat.",
                    color = Color(0xFF94A3B8), fontSize = 13.sp
                )
            }
            items(msgs, key = { it.id }) { m ->
                MessageBubble(m, showRegenerate = m.id == msgs.lastOrNull()?.id, onSpeak = vm::speakMessage, onRegenerate = vm::regenerate, onPreview = vm::openPreview)
            }
        }

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuickAction(Icons.Filled.Add, "New") { vm.newConversation() }
            QuickAction(Icons.Filled.Hearing, if (ui.voiceMode) "Voice: ON" else "Voice mode") {
                if (ui.voiceMode || hasMic()) vm.toggleVoiceMode() else voiceModeLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            QuickAction(Icons.Filled.Stop, "Stop") { vm.cancelAll() }
            QuickAction(Icons.Filled.Search, if (ui.researchMode) "Web: ON" else "Web: OFF") { vm.toggleResearch() }
            QuickAction(Icons.Filled.PhotoCamera, "Camera") { nav.navigate("camera") }
            QuickAction(Icons.Filled.Visibility, "Read screen") { vm.captureScreenDelayed(5) }
            QuickAction(Icons.Filled.History, "History") { nav.navigate("history") }
            QuickAction(Icons.Filled.Memory, "Memory") { nav.navigate("memory") }
            QuickAction(Icons.Filled.Build, "Tools") { nav.navigate("tools") }
            QuickAction(Icons.Filled.Settings, "Settings") { nav.navigate("settings") }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                if (ui.activity == ActivityState.SPEAKING) vm.cancelAll()
                else vm.saveSettings(settings.copy(speakReplies = !settings.speakReplies))
            }) {
                Icon(if (settings.speakReplies) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, "Speak replies", tint = Cyan)
            }
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Type a message...") }, maxLines = 3
            )
            IconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank()) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = if (input.isNotBlank()) Cyan else Color.Gray)
            }
            FloatingActionButton(
                onClick = { if (hasMic()) vm.toggleMic() else micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                containerColor = if (ui.activity == ActivityState.LISTENING) Danger else Cyan,
                modifier = Modifier.size(52.dp)
            ) { Icon(Icons.Filled.Mic, "Microphone") }
        }
    }

    ui.pending?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.resolvePending(false) },
            title = { Text("Confirm action") },
            text = { Text(p.description) },
            confirmButton = { TextButton(onClick = { vm.resolvePending(true) }) { Text("Confirm") } },
            dismissButton = { TextButton(onClick = { vm.resolvePending(false) }) { Text("Cancel") } }
        )
    }
    ui.pendingMemory?.let { fact ->
        AlertDialog(
            onDismissRequest = { vm.approveMemory(false) },
            title = { Text("Save to memory?") },
            text = { Text(fact) },
            confirmButton = { TextButton(onClick = { vm.approveMemory(true) }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { vm.approveMemory(false) }) { Text("Don't save") } }
        )
    }
}
