package com.nexus.ai.ai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONException
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatMsg(val role: String, val content: String, val imageB64: String? = null) // role: "user" | "assistant"

data class Source(val title: String, val url: String)

class AiException(message: String) : Exception(message)

/** Implement this to add another model/provider. */
interface AiProvider {
    val id: String
    /**
     * research = true asks the provider to ground the answer with live web search.
     * onSources is called (possibly from a background thread) with any citations found.
     */
    fun stream(
        messages: List<ChatMsg>,
        system: String,
        research: Boolean = false,
        onSources: (List<Source>) -> Unit = {}
    ): Flow<String>
}

internal object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val MAX_ATTEMPTS = 3

    fun messageFor(code: Int): String = when {
        code == 401 || code == 403 -> "The provider rejected the API key (HTTP $code). Check your key in Settings."
        code == 404 -> "Model or endpoint not found (HTTP 404). Check the model name in Settings."
        code == 400 -> "The provider rejected the request (HTTP 400). Check the model name."
        code == 429 -> "Rate limited by the provider. Wait a moment and try again."
        code in 500..599 -> "The provider had a server error (HTTP $code). Try again shortly."
        else -> "Request failed (HTTP $code)."
    }

    /**
     * Streams a Server-Sent-Events response, emitting text extracted from each `data:` line.
     * Retries (with backoff) on network errors, HTTP 429 and 5xx before the first byte.
     * Cancelling the collecting coroutine cancels the HTTP call.
     */
    fun sseFlow(build: () -> Request, extract: (String) -> String?): Flow<String> = flow {
        val req = try {
            build()
        } catch (e: IllegalArgumentException) {
            throw AiException("Invalid endpoint URL. Check Settings.")
        }
        var attempt = 0
        while (true) {
            attempt++
            val call = client.newCall(req)
            val handle = currentCoroutineContext()[Job]?.invokeOnCompletion { call.cancel() }
            val resp: Response = try {
                call.execute()
            } catch (e: IOException) {
                handle?.dispose()
                currentCoroutineContext().ensureActive()
                if (attempt < MAX_ATTEMPTS) { delay(1000L * attempt); continue }
                throw AiException("Network error. Check your connection and try again.")
            }
            if (!resp.isSuccessful) {
                val code = resp.code
                resp.close()
                handle?.dispose()
                if ((code == 429 || code in 500..599) && attempt < MAX_ATTEMPTS) { delay(1500L * attempt); continue }
                throw AiException(messageFor(code))
            }
            var any = false
            try {
                val src = resp.body!!.source()
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.removePrefix("data:").trim()
                    if (data == "[DONE]") break
                    val text = try { extract(data) } catch (e: JSONException) { null }
                    if (!text.isNullOrEmpty()) { any = true; emit(text) }
                }
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                throw AiException("Connection lost while streaming the reply.")
            } finally {
                resp.close()
                handle?.dispose()
            }
            if (!any) throw AiException("The model returned an empty response (it may have been blocked).")
            return@flow
        }
    }.flowOn(Dispatchers.IO)
}
