package com.nexus.ai.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import androidx.core.app.ServiceCompat

object Notif {
    fun channel(ctx: Context, id: String, name: String, importance: Int = NotificationManager.IMPORTANCE_LOW) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) == null) nm.createNotificationChannel(NotificationChannel(id, name, importance))
    }

    /** Returns false if Android refused to start the foreground service (missing permission, background start...). */
    fun startForeground(service: Service, id: Int, n: Notification, type: Int): Boolean = try {
        ServiceCompat.startForeground(service, id, n, type)
        true
    } catch (e: Exception) {
        false
    }
}
