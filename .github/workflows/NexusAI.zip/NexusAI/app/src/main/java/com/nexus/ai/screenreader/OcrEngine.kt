package com.nexus.ai.screenreader

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** On-device OCR for Latin (English/Hinglish in Roman script) and Devanagari (Hindi). The image never leaves the phone. */
object OcrEngine {
    suspend fun recognize(image: InputImage): String {
        val latin = run(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS), image)
        val deva = try {
            run(TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build()), image)
        } catch (e: Exception) {
            ""
        }
        // If the Devanagari model found Hindi characters, prefer its result.
        return if (deva.any { it in '\u0900'..'\u097F' }) deva else latin
    }

    private suspend fun run(rec: TextRecognizer, image: InputImage): String = suspendCancellableCoroutine { cont ->
        rec.process(image)
            .addOnSuccessListener { rec.close(); if (cont.isActive) cont.resume(it.text) }
            .addOnFailureListener { rec.close(); if (cont.isActive) cont.resumeWithException(it) }
        cont.invokeOnCancellation { rec.close() }
    }
}
