package com.nexus.ai

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.nexus.ai.ui.NexusRoot
import com.nexus.ai.ui.NexusTheme
import com.nexus.ai.ui.NexusViewModel

class MainActivity : ComponentActivity() {
    private val vm: NexusViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NexusTheme { NexusRoot() } }
        if (savedInstanceState == null) handleWake(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWake(intent)
    }

    private fun handleWake(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_WAKE, false) == true) {
            i.removeExtra(EXTRA_WAKE)
            vm.wakeTriggered()
        }
    }

    companion object { const val EXTRA_WAKE = "nexus_wake" }
}
