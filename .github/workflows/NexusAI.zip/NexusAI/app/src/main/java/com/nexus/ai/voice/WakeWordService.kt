package com.nexus.ai.voice

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.nexus.ai.MainActivity
import com.nexus.ai.core.Notif
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

object WakeWordBus {
    val running = MutableStateFlow(false)
    /** The app sets this to true while it is using the microphone itself (listening/speaking/thinking). */
    val paused = MutableStateFlow(false)
    val events = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
}

/**
 * Wake-word listening in a microphone foreground service (visible ongoing notification).
 * Engine: Android SpeechRecognizer in a loop, matching your phrase in the transcript.
 * This is NOT a dedicated low-power wake-word engine: it uses more battery, may beep on some phones,
 * and speech services may send audio to Google unless an offline model is installed.
 */
class WakeWordService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var rec: SpeechRecognizer? = null
    private var phrase = "hey nexus"
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        phrase = norm(intent?.getStringExtra(EXTRA_PHRASE).orEmpty()).ifBlank { "hey nexus" }

        Notif.channel(this, CH_RUN, "Wake word listening")
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH_RUN)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Nexus is listening for \"$phrase\"")
            .setContentText("Microphone is active. Tap Stop to turn off.")
            .setOngoing(true)
            .setContentIntent(tap)
            .addAction(0, "Stop", stop)
            .build()
        if (!Notif.startForeground(this, 11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)) {
            stopSelf(); return START_NOT_STICKY
        }
        if (!started) {
            started = true
            WakeWordBus.running.value = true
            scope.launch { WakeWordBus.paused.collect { if (it) stopRecognizer() else startRecognizer() } }
        }
        return START_NOT_STICKY
    }

    private fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), "").trim()

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
            val quick = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            restart(if (quick) 400L else 2500L)
        }
        override fun onResults(results: Bundle?) { if (!heard(results)) restart(300L) }
        override fun onPartialResults(partialResults: Bundle?) { heard(partialResults) }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun heard(b: Bundle?): Boolean {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
        if (list.any { norm(it).contains(phrase) }) { onWake(); return true }
        return false
    }

    private fun onWake() {
        stopRecognizer()
        Notif.channel(this, CH_ALERT, "Wake word detected", NotificationManager.IMPORTANCE_HIGH)
        val open = PendingIntent.getActivity(
            this, 3,
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_WAKE, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Nexus heard you")
            .setContentText("Tap to talk")
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        getSystemService(NotificationManager::class.java).notify(13, n)
        // If the app is alive it starts listening itself; otherwise the notification above opens it.
        WakeWordBus.events.tryEmit(Unit)
        handler.postDelayed({ startRecognizer() }, 8000L)
    }

    private fun restart(delayMs: Long) {
        stopRecognizer()
        handler.postDelayed({ startRecognizer() }, delayMs)
    }

    private fun startRecognizer() {
        if (!started || rec != null || WakeWordBus.paused.value) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        rec = r
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        )
    }

    private fun stopRecognizer() {
        rec?.cancel()
        rec?.destroy()
        rec = null
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopRecognizer()
        scope.cancel()
        WakeWordBus.running.value = false
        super.onDestroy()
    }

    companion object {
        private const val CH_RUN = "nexus_wake_run"
        private const val CH_ALERT = "nexus_wake_alert"
        private const val ACTION_STOP = "com.nexus.ai.STOP_WAKE"
        private const val EXTRA_PHRASE = "phrase"

        fun start(ctx: Context, phrase: String) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java).putExtra(EXTRA_PHRASE, phrase))
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, WakeWordService::class.java)) }
    }
}
